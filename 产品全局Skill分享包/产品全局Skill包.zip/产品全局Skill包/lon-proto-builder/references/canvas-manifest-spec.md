# Canvas Manifest 契约（v1.0）

本文件定义 lon-proto-builder（生成端）与 lon-proto-canvas（消费端）之间的元数据契约。生成原型时必须按本规范输出。

## 用途

下游 lon-proto-canvas 要把多状态 + 浮层平铺成画布。生成端写显式 manifest 标注每个 state / overlay，消费端直接 JSON.parse 取数据、不猜 DOM 结构。

## DOM 锚点约定

每个 state / overlay 的根节点必须带 `data-frame="<key>"`。**对于 `kind: "state"` 的 frame，wrapper 必须包含该状态展示时的所有可见 chrome**（如 APP 的 iOS 状态栏 / 顶部导航栏 / 底部 Tab 栏 / Home Indicator，中台的顶部栏 / 侧栏等）——下游 lon-proto-canvas 按 selector 取 wrapper 节点的 outerHTML，chrome 落在 wrapper 外面就会被丢掉：

```html
<!-- ✓ 正确：state wrapper 包含完整 chrome -->
<div data-frame="list-normal" class="h-full flex flex-col">
  <div class="...">状态栏</div>
  <header>导航栏</header>
  <main class="flex-1 overflow-y-auto">列表内容</main>
  <nav>Tab 栏</nav>
</div>
<div data-frame="list-empty" class="h-full flex flex-col hidden">
  ... 复制完整 chrome + 空态 main ...
</div>

<!-- ✗ 错误：data-frame 仅在 <main> 上，外层 chrome 被丢出去 -->
<body>
  <div class="...">状态栏</div>
  <header>导航栏</header>
  <main data-frame="list-normal">列表内容</main>
  <nav>Tab 栏</nav>
</body>

<!-- 浮层（fixed 定位，独立元素，与 state wrapper 并列，无 chrome 问题） -->
<div id="modal-delete" data-frame="modal-delete" class="modal-mask hidden">
  <div class="modal">确定删除？</div>
</div>
<div id="bottom-sheet" data-frame="sheet-filter" class="fixed bottom-0 ...">...</div>
```

规则：
- `data-frame` 的值在单个 HTML 内全局唯一
- 与 manifest.frames[].key 严格相等
- 可与原有 id / data-variant 共存，互不冲突
- **state wrapper 内含 chrome**（重要）；多状态时复制 wrapper，仅默认态可见，其他态根节点加 `hidden`
- 浮层是独立 fixed 元素，无 chrome 问题，原样写即可

## Manifest 块

每个 HTML 在 `</body>` 之前嵌入一段 `<script type="application/canvas-manifest" data-version="1.0">`，内容是 JSON：

```html
<script type="application/canvas-manifest" data-version="1.0">
{
  "version": "1.0",
  "page": { "name": "我的预警", "order": 4 },
  "frames": [
    {
      "key": "list-normal",
      "kind": "state",
      "label": "列表态",
      "tag": "3 条监控中",
      "selector": "[data-frame=\"list-normal\"]"
    },
    {
      "key": "list-empty",
      "kind": "state",
      "label": "空态",
      "tag": "无预警",
      "selector": "[data-frame=\"list-empty\"]"
    },
    {
      "key": "modal-delete",
      "kind": "overlay",
      "overlayType": "modal",
      "label": "删除确认",
      "selector": "[data-frame=\"modal-delete\"]",
      "triggers": [
        { "fromStateKey": "list-normal", "action": "点击 删除 按钮" }
      ]
    }
  ]
}
</script>
```

## 字段规则

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `version` | string | 是 | 固定 `"1.0"` |
| `page.name` | string | 是 | 页面中文名，作为画布左菜单显示文本 |
| `page.order` | number | 否 | 排序权重，画布左菜单按此排序 |
| `page.viewport` | string \| object | 否 | 视口档位，决定该页在画布上按多宽渲染。**一般不用写**——lon-proto-canvas 会嗅探本页 `<meta name="viewport">`，APP 骨架的 `width=device-width` 落到 375×812、中台骨架的 `width=1280` 落到 1280×800，两边都对。只有当 meta 与画布期望不一致时才显式声明 `"mobile"` / `"desktop"` 或 `{width, height}`，字段定义见 `lon-proto-canvas/references/input-manifest-spec.md` |
| `frames[]` | array | 是 | 至少 1 项 |
| `frames[].key` | string | 是 | 单 HTML 内唯一，等于对应节点的 `data-frame` |
| `frames[].kind` | string | 是 | `state` 或 `overlay` 二选一 |
| `frames[].label` | string | 是 | frame 在画布上的显示名 |
| `frames[].tag` | string | 否 | 状态副标签（如「默认」「异常」「3 条监控中」） |
| `frames[].selector` | string | 是 | CSS 选择器，推荐 `[data-frame="<key>"]` |
| `frames[].overlayType` | string | 仅 overlay | `modal` / `sheet` / `drawer` / `popup`（**toast 不进 manifest**，见下） |
| `frames[].triggers` | array | 仅 overlay，可选 | 触发关系数组 |
| `frames[].triggers[].fromStateKey` | string | 是 | 触发它的来源 state 的 key（必须存在于本 manifest 的 state frames 中） |
| `frames[].triggers[].action` | string \| string[] | 是 | 触发动作描述（如「点击 删除 按钮」）；多源同向触发可写为数组（如 `["点击「看长理由」按钮 ×3", "点击备选行 ×5"]`） |

**多触发源处理**：当同一浮层有多个触发入口时（如 P06 长理由 sheet 由 3 张核心股卡 + 5 行备选共 8 处触发），有两种合法写法：

```json
// 写法 A：单 trigger 对象 + action 数组（推荐，简洁）
"triggers": [
  { "fromStateKey": "main", "action": ["核心卡「看长理由」×3", "备选行 ×5"] }
]

// 写法 B：多个 trigger 对象共享同一 fromStateKey
"triggers": [
  { "fromStateKey": "main", "action": "核心卡「看长理由」按钮" },
  { "fromStateKey": "main", "action": "备选行" }
]
```

如果不同触发源来自**不同** state（如从 state-list 和 state-detail 都能弹同一个 modal），必须用写法 B，每个 fromStateKey 单独成对象。

## Toast 不进 manifest

Toast 是瞬时反馈（操作成功/失败提示等），自起自消、不依赖用户触发关闭，**不在画布上单独占一帧**。规则：

- 页面里的 toast UI 元素**不写** `data-frame` 属性
- manifest.frames[] 里**不登记** toast
- 实现上 toast 走自己的代码路径（如 `setTimeout` 自动隐藏），不走 `toggleOverlay`
- 如果误写为 `overlayType: "toast"`，下游 lon-proto-canvas 扫描时会兜底跳过 + 不产出 warning

只有 modal / sheet / drawer / popup 这类需要用户主动关闭的浮层才登记到 manifest。

## 渲染顺序

`frames[]` 数组顺序即画布展示顺序。约定：

1. 主状态按业务流自然顺序（列表 → 详情 → 编辑等）
2. 浮层紧跟它的 `fromStateKey` 状态之后
3. 无触发关系的浮层放最后

下游画布会按此顺序横向铺开（state 主屏 → 紧随的浮层 → 下一个 state ...）。

## 完整实例（带 1 state + 2 overlay）

```html
<body class="h-screen flex flex-col overflow-hidden">
  <!-- state wrapper：含完整 chrome（状态栏 + 导航 + main + Tab） -->
  <div data-frame="main" class="h-full flex flex-col">
    <div class="h-11 shrink-0">iOS 状态栏</div>
    <header class="h-11 shrink-0">导航栏</header>
    <main class="flex-1 overflow-y-auto">
      <button onclick="openSheet()">筛选</button>
      <button onclick="openModal()">删除</button>
    </main>
    <nav class="shrink-0">Tab 栏</nav>
  </div>

  <!-- 浮层：独立 fixed 元素，与 wrapper 并列 -->
  <div id="bottom-sheet" data-frame="sheet-filter" class="fixed bottom-0 hidden">
    <h3>筛选条件</h3>
    ...
  </div>

  <div id="modal-delete" data-frame="modal-delete" class="modal-mask hidden">
    <div class="modal">
      <p>确认删除？</p>
      <button>取消</button>
      <button>确定</button>
    </div>
  </div>

  <script type="application/canvas-manifest" data-version="1.0">
  {
    "version": "1.0",
    "page": { "name": "首页", "order": 1 },
    "frames": [
      { "key": "main", "kind": "state", "label": "正常态",
        "selector": "[data-frame=\"main\"]" },
      { "key": "sheet-filter", "kind": "overlay", "overlayType": "sheet",
        "label": "筛选面板", "selector": "[data-frame=\"sheet-filter\"]",
        "triggers": [{ "fromStateKey": "main", "action": "点击 筛选 按钮" }] },
      { "key": "modal-delete", "kind": "overlay", "overlayType": "modal",
        "label": "删除确认", "selector": "[data-frame=\"modal-delete\"]",
        "triggers": [{ "fromStateKey": "main", "action": "点击 删除 按钮" }] }
    ]
  }
  </script>
</body>
```

## 消费端的解析规则

消费端解析逻辑定义在 `../lon-proto-canvas/references/scan-rules.md`：

1. grep `<script type="application/canvas-manifest">` 块
2. `JSON.parse` innerHTML
3. 按 `frames[]` 构造 page 对象（kind=state 进 mainStates、kind=overlay 进 overlays、triggers 平铺到顶层）
4. 画布通过 iframe 直接加载原 HTML（不抠 DOM outerHTML），视觉还原由 iframe 完成

iframe 协议下 manifest 必须存在；缺失或解析失败 → 画布静默跳过该页 + warning。画布只认 manifest，无正则 fallback。

## 不写或写错的后果

- 不写 manifest：lon-proto-canvas 跳过整页 + warning 让用户补 manifest
- selector / bodySelector 字段对 iframe 协议**无影响**，扫描器不读；写不写都可以
- triggers.fromStateKey 引用不存在的 state：画布渲染时浮层归到「未关联浮层」区；iframe 内 bootstrap 找不到 fromStateKey 时，浮层仍可直接 toggleOverlay，只是失去触发上下文
- state 的 `data-frame` 建议挂含 chrome 的最外层 wrapper（不是内层 `<main>`）：iframe 整页加载时 chrome 不会丢，挂外层是为了整屏切换、多态结构一致

## Canvas iframe 协议（v1.0）

iframe 协议是 lon-proto-canvas 加载原型 HTML 的标准方式。原 HTML 要做画布消费方，**必须**带 canvasMode bootstrap（lon-proto-builder 起手骨架已内置；存量 HTML 由 `lon-proto-canvas/scripts/patch_prototype.py` 幂等注入）。

### URL 契约

```
<sourceFile>?canvasMode=1#<frameKey>
```

- `?canvasMode=1`：触发 bootstrap（必填）
- `#<frameKey>`：要激活的 frame key，跟 manifest.frames[].key 一致
- 兼容写法：`#frame=<frameKey>` 等价

未带 `?canvasMode=1` 时 bootstrap 直接 return，原 HTML 行为不变（独立打开仍是手机原型）。

### bootstrap 行为

1. 解析 URL hash → frameKey
2. 读自身 manifest，按 frameKey 找 target frame：
   - `kind === 'state'` → 调 `window.switchFrame(frameKey, [...同组 state key])`
   - `kind === 'overlay'` → 先按 `triggers[0].fromStateKey` 切到对应 state，再调 `window.toggleOverlay(frameKey, true)`
3. 设置 `<html data-canvas-mode="1">`，激活 patch CSS：`html, body { height: auto !important; min-height: 100vh; overflow: visible !important; }`、`body { display: block !important }`，让依赖手机壳 viewport 的布局自然撑开
4. capture-phase 监听 `click`（拦截 `a[href]` 跳转）和 `submit`（拦截表单），禁止原型功能性交互；hover / 选中文本 / DevTools 选元素仍可用
5. 多次 reportHeight（DOMContentLoaded / 250ms / 1200ms / window.load / fonts.ready）：`parent.postMessage({type:'canvas-frame-ready', frameKey, height}, '*')`

### 父画布的 postMessage 协议

```js
{
  type: 'canvas-frame-ready',
  frameKey: '<key>',
  height: <内容自然高度>  // Math.max(scrollHeight, 812)
}
```

父画布通过 `iframe.contentWindow === e.source` 找到对应 iframe，回填 `iframe.style.height = Math.max(height, 812) + 'px'`。

### bootstrap 注入位置（lon-proto-builder 起手骨架）

- patch CSS：`</style>` 块之前（独立 `<style data-canvas-mode-bootstrap="1">` 块）
- bootstrap JS：`<script type="application/canvas-manifest">` 块之前（独立 `<script data-canvas-mode-bootstrap="1">` 块）
- 标记 `data-canvas-mode-bootstrap="1"` 用于幂等检测：patch_prototype.py 见此标记直接跳过
