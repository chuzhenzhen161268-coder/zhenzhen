# 中台模式 HTML 骨架模板

生成中台/后台管理原型时，以此为基础结构。蓝色主题 + Tailwind CSS + FontAwesome 图标 + 侧边栏跨页导航。

**使用方式**：复制以下骨架，替换 `[占位符]` 内容，填充具体页面模块。

---

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=1280">
  <title>[系统名称] - [页面名称]</title>
  <!-- FontAwesome 6 Free（图标） -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          primary: { DEFAULT: '#1677ff', hover: '#4096ff', active: '#0958d9', light: '#e6f4ff' },
          success: '#52c41a',
          warning: '#faad14',
          error:   '#ff4d4f',
          info:    '#1677ff',
          gray: {
            text:           '#1d2129',
            'text-sec':     '#4e5969',
            'text-dis':     '#c9cdd4',
            border:         '#e5e6eb',
            'border-light': '#f2f3f5',
            bg:             '#f5f6f7',
            'bg-hover':     '#f2f3f5',
          },
          sidebar: { bg: '#001529' },
        },
        fontFamily: {
          base: ['-apple-system', 'BlinkMacSystemFont', '"PingFang SC"', '"Hiragino Sans GB"', '"Microsoft YaHei"', 'sans-serif'],
        },
        fontSize: { '2xs': '13px' },
        width: { sidebar: '220px' },
        spacing: { sidebar: '220px' },
      }
    }
  }
  </script>
  <style>
    /* 仅放 Tailwind 无法表达的内容 */
    @keyframes shimmer {
      0%   { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
    .skeleton {
      background: linear-gradient(90deg, #f0f0f0 25%, #e8e8e8 50%, #f0f0f0 75%);
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
      border-radius: 4px;
    }
    @keyframes toastIn {
      from { opacity: 0; transform: translateX(-50%) translateY(-8px); }
      to   { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
    .toast-anim { animation: toastIn 0.2s ease; }
    /* 侧边栏自定义滚动条 */
    .sidebar-scroll::-webkit-scrollbar { width: 4px; }
    .sidebar-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
  </style>
</head>
<body class="font-base text-sm text-gray-text bg-gray-bg min-h-screen">
  <div class="flex min-h-screen">

    <!-- ════════════════════════════════════
         侧边栏（固定，220px）
         重要：所有页面必须使用完全相同的侧边栏结构
         当前页菜单项加 active 类（见下方 .menu-item.active 示例）
    ════════════════════════════════════ -->
    <aside class="w-[220px] bg-sidebar-bg fixed inset-y-0 left-0 overflow-y-auto z-[100] flex flex-col sidebar-scroll">
      <!-- Logo 区 -->
      <div class="h-12 flex items-center px-4 border-b border-white/[0.06] shrink-0">
        <div class="w-7 h-7 bg-primary rounded-md flex items-center justify-center mr-2 text-white text-sm">
          <i class="fa-solid fa-layer-group" aria-hidden="true"></i>
        </div>
        <span class="text-base font-semibold text-white">[系统名称]</span>
      </div>

      <!-- 菜单 -->
      <nav class="py-2 flex-1">
        <!--
          根据页面 PRD 中的导航结构生成菜单
          href 指向对应 HTML 文件
          当前页加 !bg-primary !text-white 覆盖默认样式
        -->
        <a href="01-概览.html" class="flex items-center gap-3 h-10 px-4 mx-2 rounded text-white/75 text-sm hover:bg-white/[0.08] hover:text-white !bg-primary !text-white">
          <i class="fa-solid fa-chart-pie w-4 text-center text-sm" aria-hidden="true"></i>
          <span>概览</span>
        </a>
        <a href="02-列表页.html" class="flex items-center gap-3 h-10 px-4 mx-2 rounded text-white/75 text-sm hover:bg-white/[0.08] hover:text-white">
          <i class="fa-solid fa-list w-4 text-center text-sm" aria-hidden="true"></i>
          <span>数据列表</span>
        </a>
        <a href="03-配置.html" class="flex items-center gap-3 h-10 px-4 mx-2 rounded text-white/75 text-sm hover:bg-white/[0.08] hover:text-white">
          <i class="fa-solid fa-sliders w-4 text-center text-sm" aria-hidden="true"></i>
          <span>配置管理</span>
        </a>
        <!-- 有未读消息时在末尾加角标 -->
        <a href="04-消息.html" class="flex items-center gap-3 h-10 px-4 mx-2 rounded text-white/75 text-sm hover:bg-white/[0.08] hover:text-white">
          <i class="fa-solid fa-bell w-4 text-center text-sm" aria-hidden="true"></i>
          <span class="flex-1">消息中心</span>
          <span class="bg-error text-white text-[11px] font-semibold px-1.5 py-0.5 rounded-full leading-none">3</span>
        </a>
        <a href="05-用户.html" class="flex items-center gap-3 h-10 px-4 mx-2 rounded text-white/75 text-sm hover:bg-white/[0.08] hover:text-white">
          <i class="fa-solid fa-users w-4 text-center text-sm" aria-hidden="true"></i>
          <span>用户管理</span>
        </a>
      </nav>
    </aside>

    <!-- ════════════════════════════════════
         主内容区
    ════════════════════════════════════ -->
    <div class="ml-[220px] flex-1 flex flex-col min-h-screen">

      <!-- 顶部栏（sticky，48px） -->
      <header class="h-12 bg-white border-b border-gray-border flex items-center px-6 gap-4 sticky top-0 z-[90]">
        <!-- 面包屑 -->
        <nav class="flex items-center gap-1 text-2xs text-gray-text-sec flex-1" aria-label="面包屑">
          <a href="[真实首页文件，如 01-工作台.html]" class="hover:text-primary">首页</a>
          <span class="text-gray-text-dis mx-0.5">/</span>
          <span class="text-gray-text">[当前页面]</span>
        </nav>
        <!-- 搜索 -->
        <div class="flex items-center bg-gray-bg rounded h-8 px-3 gap-2 text-gray-text-dis">
          <i class="fa-solid fa-magnifying-glass text-xs" aria-hidden="true"></i>
          <input type="text" placeholder="搜索..." class="bg-transparent border-none text-2xs font-base text-gray-text w-[180px] outline-none placeholder:text-gray-text-dis">
        </div>
        <!-- 顶部操作 -->
        <div class="flex items-center gap-4 text-gray-text-sec">
          <div class="relative w-8 h-8 flex items-center justify-center rounded hover:bg-gray-bg-hover cursor-pointer text-base" title="通知">
            <i class="fa-solid fa-bell" aria-label="通知"></i>
            <span class="absolute top-[3px] right-[3px] w-2 h-2 bg-error rounded-full border-2 border-white" aria-label="有未读通知"></span>
          </div>
          <div class="flex items-center gap-2 cursor-pointer px-2 py-1 rounded hover:bg-gray-bg-hover">
            <div class="w-7 h-7 rounded-full bg-primary text-white text-xs flex items-center justify-center font-semibold" aria-hidden="true">王</div>
            <span class="text-2xs text-gray-text">王磊</span>
            <i class="fa-solid fa-chevron-down text-[11px] text-gray-text-dis" aria-hidden="true"></i>
          </div>
        </div>
      </header>

      <!-- 页面内容 -->
      <div class="p-6 flex-1">
        <div class="flex items-center justify-between mb-5">
          <h1 class="text-xl font-semibold text-gray-text">[页面标题]</h1>
          <div class="flex gap-2">
            <!-- 操作按钮 -->
          </div>
        </div>

        <!-- ✂ 在此填充具体页面内容 ✂ -->
        <!-- 参考 prd/pages/{XX}-{页面名}.md 的「元素详单」和「线框图」 -->

      </div>
    </div>

  </div>

  <!-- Modal（按需使用，默认 hidden） -->
  <!--
  <div id="modal" class="hidden fixed inset-0 bg-black/45 flex items-center justify-center z-[1000]">
    <div class="bg-white rounded-lg shadow-lg w-[480px] max-w-[90vw]">
      <div class="flex items-center justify-between px-6 py-4 border-b border-gray-border-light text-base font-semibold">
        <span>弹窗标题</span>
        <i class="fa-solid fa-xmark cursor-pointer text-gray-text-dis hover:text-gray-text-sec text-base" aria-label="关闭" onclick="closeModal('modal')"></i>
      </div>
      <div class="p-6">内容区域</div>
      <div class="flex items-center justify-end gap-2 px-6 py-3 border-t border-gray-border-light">
        <button class="h-8 px-4 border border-gray-border rounded text-sm hover:border-primary hover:text-primary" onclick="closeModal('modal')">取消</button>
        <button class="h-8 px-4 bg-primary text-white rounded text-sm hover:bg-primary-hover">确认</button>
      </div>
    </div>
  </div>
  -->

  <script>
    // Toast 工具函数
    function showToast(msg, type = 'info') {
      const existing = document.querySelector('.toast-popup');
      if (existing) existing.remove();
      const configs = {
        success: { bg: 'bg-[#f6ffed]', border: 'border-[#b7eb8f]', text: 'text-[#389e0d]', icon: 'fa-circle-check' },
        error:   { bg: 'bg-[#fff2f0]', border: 'border-[#ffccc7]', text: 'text-error',      icon: 'fa-circle-xmark' },
        info:    { bg: 'bg-primary-light', border: 'border-[#91caff]', text: 'text-primary-active', icon: 'fa-circle-info' },
      };
      const c = configs[type] || configs.info;
      const toast = document.createElement('div');
      toast.className = `toast-popup toast-anim fixed top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-5 py-2.5 rounded border ${c.bg} ${c.border} ${c.text} text-2xs z-[9999] pointer-events-none shadow-md`;
      toast.innerHTML = `<i class="fa-solid ${c.icon}" aria-hidden="true"></i>${msg}`;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 2500);
    }

    // Modal 控制
    function openModal(id) { document.getElementById(id).classList.remove('hidden'); document.getElementById(id).classList.add('flex'); }
    function closeModal(id) { document.getElementById(id || 'modal').classList.add('hidden'); document.getElementById(id || 'modal').classList.remove('flex'); }

    // 按需添加页面交互逻辑
  </script>
</body>
</html>
```

---

## 常用组件 Tailwind 配方

### 内容卡片

```html
<div class="bg-white rounded-lg shadow-sm p-6 mb-4">
  <div class="flex items-center justify-between mb-5">
    <h2 class="text-base font-semibold">[卡片标题]</h2>
    <div class="flex gap-2"><!-- 操作按钮 --></div>
  </div>
  <!-- 内容 -->
</div>
```

### 按钮

```html
<!-- 主按钮 -->
<button class="inline-flex items-center gap-1 h-8 px-4 bg-primary text-white border border-primary rounded text-sm hover:bg-primary-hover active:bg-primary-active">
  <i class="fa-solid fa-plus text-[13px]" aria-hidden="true"></i> 新建
</button>

<!-- 默认按钮 -->
<button class="inline-flex items-center h-8 px-4 bg-white text-gray-text border border-gray-border rounded text-sm hover:border-primary hover:text-primary">
  导出
</button>

<!-- 危险按钮 -->
<button class="inline-flex items-center h-8 px-4 bg-error text-white border border-error rounded text-sm hover:opacity-90">
  删除
</button>

<!-- 文字按钮（表格操作） -->
<button class="text-primary text-sm hover:text-primary-hover bg-none border-none p-0 cursor-pointer font-base">编辑</button>
<span class="text-gray-border select-none">|</span>
<button class="text-error text-sm hover:opacity-75 bg-none border-none p-0 cursor-pointer font-base">删除</button>
```

### 数据表格

```html
<table class="w-full border-collapse">
  <thead>
    <tr>
      <th class="bg-[#fafafa] font-medium text-gray-text-sec text-2xs text-left px-4 h-10 border-b border-gray-border-light whitespace-nowrap">列名</th>
      <th class="bg-[#fafafa] font-medium text-gray-text-sec text-2xs text-left px-4 h-10 border-b border-gray-border-light whitespace-nowrap">操作</th>
    </tr>
  </thead>
  <tbody>
    <tr class="hover:[&>td]:bg-gray-bg">
      <td class="px-4 h-12 text-sm border-b border-gray-border-light align-middle">数据内容</td>
      <td class="px-4 h-12 text-sm border-b border-gray-border-light align-middle">
        <div class="flex gap-3">
          <button class="text-primary text-sm hover:text-primary-hover bg-none border-none p-0 cursor-pointer font-base">编辑</button>
          <span class="text-gray-border select-none">|</span>
          <button class="text-error text-sm hover:opacity-75 bg-none border-none p-0 cursor-pointer font-base">删除</button>
        </div>
      </td>
    </tr>
  </tbody>
</table>
```

### 状态 Tag

```html
<!-- 进行中（蓝） -->
<span class="inline-flex items-center gap-1 h-[22px] px-2 rounded text-xs bg-primary-light text-primary-active">
  <span class="w-1.5 h-1.5 rounded-full bg-primary"></span> 进行中
</span>

<!-- 成功（绿） -->
<span class="inline-flex items-center gap-1 h-[22px] px-2 rounded text-xs bg-[#f6ffed] text-[#389e0d]">
  <span class="w-1.5 h-1.5 rounded-full bg-success"></span> 已完成
</span>

<!-- 警告（橙） -->
<span class="inline-flex items-center gap-1 h-[22px] px-2 rounded text-xs bg-[#fffbe6] text-[#d48806]">
  <span class="w-1.5 h-1.5 rounded-full bg-warning"></span> 待审核
</span>

<!-- 失败（红） -->
<span class="inline-flex items-center gap-1 h-[22px] px-2 rounded text-xs bg-[#fff2f0] text-[#cf1322]">
  <span class="w-1.5 h-1.5 rounded-full bg-error"></span> 已失败
</span>

<!-- 默认（灰） -->
<span class="inline-flex items-center gap-1 h-[22px] px-2 rounded text-xs bg-gray-bg text-gray-text-sec">
  <span class="w-1.5 h-1.5 rounded-full bg-gray-text-dis"></span> 已禁用
</span>
```

### 表单

```html
<div class="flex items-start mb-5">
  <label class="w-[100px] text-right pr-3 pt-[5px] text-sm shrink-0 leading-normal">
    <span class="text-error mr-0.5">*</span>字段名
  </label>
  <div class="flex-1">
    <input class="w-full h-8 border border-gray-border rounded px-3 text-sm font-base text-gray-text bg-white outline-none focus:border-primary focus:ring-2 focus:ring-primary-light placeholder:text-gray-text-dis" placeholder="请输入">
    <!-- 错误态 -->
    <!-- <input class="w-full h-8 border border-error rounded px-3 text-sm ring-2 ring-error/15 outline-none"> -->
    <!-- <p class="mt-1 text-xs text-error">请填写此字段</p> -->
  </div>
</div>
```

### 指标卡片（Dashboard）

```html
<div class="bg-white rounded-lg shadow-sm p-6">
  <div class="text-2xs text-gray-text-sec mb-3">指标名称</div>
  <div class="text-[32px] font-semibold text-gray-text leading-none mb-2">12,847</div>
  <div class="flex items-center gap-1 text-2xs">
    <span class="text-success flex items-center gap-0.5">
      <i class="fa-solid fa-caret-up" aria-hidden="true"></i> 12.5%
    </span>
    <span class="text-gray-text-sec">较上月</span>
  </div>
</div>
```

### 筛选栏

```html
<div class="flex items-center gap-3 flex-wrap p-4 bg-white rounded-t-lg border-b border-gray-border-light">
  <div class="flex items-center gap-2">
    <span class="text-2xs text-gray-text-sec whitespace-nowrap">状态</span>
    <select class="h-8 border border-gray-border rounded px-3 text-sm font-base text-gray-text bg-white outline-none focus:border-primary appearance-none pr-8 cursor-pointer">
      <option>全部</option>
      <option>进行中</option>
      <option>已完成</option>
    </select>
  </div>
  <button class="h-8 px-4 bg-primary text-white rounded text-sm hover:bg-primary-hover">查询</button>
  <button class="h-8 px-4 bg-white text-gray-text border border-gray-border rounded text-sm hover:border-primary hover:text-primary">重置</button>
</div>
```

### 分页

```html
<div class="flex items-center justify-end gap-1 px-6 py-4 border-t border-gray-border-light bg-white">
  <span class="text-2xs text-gray-text-sec mr-3">共 238 条</span>
  <button class="min-w-[32px] h-8 px-2 border border-gray-border rounded bg-white text-sm hover:border-primary hover:text-primary disabled:text-gray-text-dis disabled:cursor-not-allowed">
    <i class="fa-solid fa-chevron-left text-xs" aria-hidden="true"></i>
  </button>
  <button class="min-w-[32px] h-8 px-2 border border-primary bg-primary text-white rounded text-sm">1</button>
  <button class="min-w-[32px] h-8 px-2 border border-gray-border rounded bg-white text-sm hover:border-primary hover:text-primary">2</button>
  <button class="min-w-[32px] h-8 px-2 border border-gray-border rounded bg-white text-sm hover:border-primary hover:text-primary">3</button>
  <button class="min-w-[32px] h-8 px-2 border border-gray-border rounded bg-white text-sm hover:border-primary hover:text-primary">
    <i class="fa-solid fa-chevron-right text-xs" aria-hidden="true"></i>
  </button>
</div>
```

### 骨架屏

```html
<div class="p-6 space-y-4">
  <div class="flex gap-4">
    <div class="skeleton h-4 w-24"></div>
    <div class="skeleton h-4 w-36"></div>
    <div class="skeleton h-4 w-28"></div>
  </div>
  <div class="skeleton h-4 w-full"></div>
  <div class="skeleton h-4 w-4/5"></div>
</div>
```

### 空态

```html
<div class="flex flex-col items-center justify-center py-12 text-center">
  <i class="fa-solid fa-folder-open fa-2x text-gray-text-dis mb-4" aria-hidden="true"></i>
  <p class="text-base font-medium text-gray-text-sec mb-2">暂无数据</p>
  <p class="text-2xs text-gray-text-dis mb-5">还没有任何记录，点击新建按钮添加</p>
  <button class="inline-flex items-center gap-1 h-8 px-4 bg-primary text-white rounded text-sm hover:bg-primary-hover">
    <i class="fa-solid fa-plus text-[13px]" aria-hidden="true"></i> 新建
  </button>
</div>
```

---

## Canvas Manifest 块（每个 HTML 必填）

每个 state / overlay 根节点必须带 `data-frame="<key>"`：

```html
<!-- 主区域内的多状态：列表态 / 空态 / 加载态 -->
<div data-frame="table-normal" class="content-card">...</div>
<div data-frame="table-empty"  class="content-card hidden">...</div>

<!-- 浮层：Modal / Drawer -->
<div id="modal-edit" data-frame="modal-edit" class="fixed inset-0 bg-overlay z-[80] hidden">...</div>
<div id="drawer-detail" data-frame="drawer-detail" class="fixed right-0 top-0 h-full w-[480px] hidden">...</div>
```

在 `</body>` 之前嵌入 manifest 块：

```html
<script type="application/canvas-manifest" data-version="1.0">
{
  "version": "1.0",
  "page": { "name": "页面名（中文）", "order": 1 },
  "frames": [
    { "key": "table-normal", "kind": "state",   "label": "列表态",  "selector": "[data-frame=\"table-normal\"]" },
    { "key": "table-empty",  "kind": "state",   "label": "空态",    "tag": "无数据", "selector": "[data-frame=\"table-empty\"]" },
    { "key": "modal-edit",   "kind": "overlay", "overlayType": "modal",  "label": "编辑弹窗",
      "selector": "[data-frame=\"modal-edit\"]",
      "triggers": [{ "fromStateKey": "table-normal", "action": "点击表格行 编辑 按钮" }] },
    { "key": "drawer-detail","kind": "overlay", "overlayType": "drawer", "label": "详情抽屉",
      "selector": "[data-frame=\"drawer-detail\"]",
      "triggers": [{ "fromStateKey": "table-normal", "action": "点击表格行 查看 按钮" }] }
  ]
}
</script>
```

字段规则与完整 schema 见 `references/canvas-manifest-spec.md`。
