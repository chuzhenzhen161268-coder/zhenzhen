#!/usr/bin/env python3
"""
vendor_icons.py — lon-proto-builder 的图标本地化脚本

扫描 prototypes/pages/ 下所有 .html，按需从 unpkg.com/lucide-static 下载 <i data-lucide>
用到的 SVG 到 prototypes/assets/icons/，inline 进 HTML，并移除：
  - <script src="https://unpkg.com/lucide..."></script>
  - lucide.createIcons() 调用

跑完后 prototypes/pages/ 下每个 HTML 都是离线完整品，单独打开 / 局域网投屏 / 邮件发包都不依赖网络。

CLI:
  python3 vendor_icons.py --input <prototypes 目录绝对路径>

  --input 指 prototypes/ 站点根（不是 pages/ 子目录）；脚本内部自动定位 pages/ 与 assets/icons/。

输出：JSON 摘要到 stdout，供 SKILL Step 5.5 直接读取并向用户复述。
"""

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

# ============================================================
# 复用自 lon-proto-canvas/scripts/build_canvas.py
# ============================================================

_LUCIDE_CDN = "https://unpkg.com/lucide-static@latest/icons/{name}.svg"
_LUCIDE_TIMEOUT_SEC = 10
# 网络抖动类失败的重试间隔(秒)。HTTPError 是服务端明确错误(如 404 拼写错),不重试。
# 实测 unpkg.com CDN 偶发 URLError,3 次重试可覆盖绝大多数瞬时失败。
_LUCIDE_RETRY_DELAYS = (0.5, 1.5, 3.5)

_LUCIDE_TAG_RE = re.compile(
    r'<i\b(?P<attrs>[^>]*\bdata-lucide\s*=\s*["\'](?P<name>[^"\']+)["\'][^>]*?)\s*/?>(?:\s*</i>)?',
    flags=re.IGNORECASE,
)
_PRESERVE_ATTR_RE = re.compile(
    r'\b(width|height|class|style|id|role|fill|stroke|stroke-width|aria-[\w-]+)\s*=\s*["\']([^"\']*)["\']',
    flags=re.IGNORECASE,
)


def collect_lucide_names(html):
    if not html:
        return set()
    return set(re.findall(r'data-lucide\s*=\s*["\']([^"\']+)["\']', html, flags=re.IGNORECASE))


def download_lucide_icon(name, dest_dir, timeout=_LUCIDE_TIMEOUT_SEC):
    safe = re.sub(r'[^a-z0-9-]', '', name.lower())
    if not safe:
        return None, 'failed:invalid-name'
    dest = dest_dir / f"{safe}.svg"
    if dest.exists() and dest.stat().st_size > 0:
        return dest, 'cached'
    url = _LUCIDE_CDN.format(name=safe)
    req = urllib.request.Request(url, headers={'User-Agent': 'lon-proto-builder/1.0'})
    # 尝试 1 次 + 重试 N 次。HTTPError 不重试(服务端明确错误);
    # URLError / TimeoutError / OSError 是网络抖动,按 _LUCIDE_RETRY_DELAYS 退避。
    last_error_class = None
    attempts = [0.0] + list(_LUCIDE_RETRY_DELAYS)
    for delay in attempts:
        if delay > 0:
            time.sleep(delay)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status != 200:
                    return None, f'failed:http-{resp.status}'
                data = resp.read()
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            return dest, 'downloaded'
        except urllib.error.HTTPError as e:
            return None, f'failed:http-{e.code}'
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            last_error_class = e.__class__.__name__
            continue
    return None, f'failed:{last_error_class}-after-{len(attempts)}-attempts'


def _merge_svg_attrs(svg_attrs_str, override):
    merged = {}
    for m in re.finditer(r'\b([\w:-]+)\s*=\s*["\']([^"\']*)["\']', svg_attrs_str):
        merged[m.group(1).lower()] = (m.group(1), m.group(2))
    for k, v in override.items():
        kl = k.lower()
        if kl == 'class' and 'class' in merged:
            # class 取并集去重(保留源 svg 的 lucide/lucide-<name> 基类 + <i> 的档位
            # modifier);覆盖会丢掉 lucide 基类 -> 离线后 CSS .lucide 描边/对齐失效
            existing = merged['class'][1].split()
            seen = set(existing)
            for tok in v.split():
                if tok not in seen:
                    existing.append(tok)
                    seen.add(tok)
            merged['class'] = (merged['class'][0], ' '.join(existing))
        else:
            merged[kl] = (k, v)
    return ' '.join(f'{name}="{val}"' for name, val in merged.values())


def inline_lucide_svgs(html, svg_map):
    if not html:
        return html

    def repl(m):
        name = m.group('name')
        svg_text = svg_map.get(name)
        if not svg_text:
            return m.group(0)
        attrs_str = m.group('attrs')
        override = {}
        for am in _PRESERVE_ATTR_RE.finditer(attrs_str):
            override[am.group(1)] = am.group(2)
        # 保证离线后 svg 一定带 .lucide 基类钩子:源 svg 自带,但 <i> 若用 class 覆盖,
        # 或源 svg 来自不带 class 的旧缓存时,这里补回 lucide,再由 _merge 与源 svg
        # class 并集 -> CSS .lucide 规格(描边 1.5/默认尺寸/对齐)稳定命中
        _cls = override.get('class', '')
        if 'lucide' not in _cls.split():
            override['class'] = ('lucide ' + _cls).strip()
        open_m = re.search(r'<svg\b([^>]*)>', svg_text, flags=re.IGNORECASE)
        if not open_m:
            return m.group(0)
        new_open = f'<svg {_merge_svg_attrs(open_m.group(1), override)}>'
        return new_open + svg_text[open_m.end():]

    return _LUCIDE_TAG_RE.sub(repl, html)


# ============================================================
# 本脚本特有：清理 lucide CDN 引用与 createIcons 调用
# ============================================================

# <script src="https://unpkg.com/lucide..."></script>（含两侧空白与换行）
_LUCIDE_CDN_SCRIPT_RE = re.compile(
    r'[ \t]*<script\b[^>]*\bsrc\s*=\s*["\'][^"\']*\blucide\b[^"\']*["\'][^>]*>\s*</script>[ \t]*\r?\n?',
    flags=re.IGNORECASE,
)

# lucide.createIcons() / lucide.createIcons(); 调用（独占一行，前导空白可选）
_LUCIDE_CREATE_ICONS_RE = re.compile(
    r'^[ \t]*lucide\.createIcons\s*\(\s*\)\s*;?[ \t]*\r?\n?',
    flags=re.MULTILINE | re.IGNORECASE,
)

DEFAULT_PAGES_SUBDIR = 'pages'
DEFAULT_ICONS_SUBDIR = 'assets/icons'


def vendor_directory(site_root: Path,
                     pages_subdir=DEFAULT_PAGES_SUBDIR,
                     icons_subdir=DEFAULT_ICONS_SUBDIR):
    """site_root 是 prototypes/ 站点根。扫 site_root/pages/ 下所有 .html，按需下载并
    inline lucide SVG，图标缓存到 site_root/assets/icons/。返回摘要 dict。"""
    summary = {
        'filesScanned': 0,
        'filesProcessed': 0,
        'filesSkipped': 0,
        'iconsUnique': 0,
        'iconsDownloaded': 0,
        'iconsCached': 0,
        'iconsFailed': 0,
        'lucideScriptsRemoved': 0,
        'createIconsCallsRemoved': 0,
    }
    warnings = []

    if not site_root.is_dir():
        warnings.append(f"输入路径不是目录或不存在：{site_root}")
        return summary, warnings

    pages_dir = site_root / pages_subdir
    if not pages_dir.is_dir():
        warnings.append(f"未找到 pages 子目录：{pages_dir}（确认已按新结构生成原型到 prototypes/pages/）")
        return summary, warnings

    html_files = sorted(pages_dir.glob('*.html'))
    summary['filesScanned'] = len(html_files)

    if not html_files:
        return summary, warnings

    # 1. 跨文件收集所有 unique data-lucide 名字
    file_contents = {}
    all_names = set()
    for f in html_files:
        try:
            txt = f.read_text(encoding='utf-8')
        except Exception as e:
            warnings.append(f"{f.name}: 读取失败 {e.__class__.__name__}，跳过")
            continue
        file_contents[f] = txt
        all_names |= collect_lucide_names(txt)
    summary['iconsUnique'] = len(all_names)

    # 2. 一次性下载所有缺失的 SVG，已存在的走缓存命中
    icons_dir = site_root / icons_subdir
    svg_map = {}
    for name in sorted(all_names):
        path, status = download_lucide_icon(name, icons_dir)
        if status == 'downloaded':
            summary['iconsDownloaded'] += 1
        elif status == 'cached':
            summary['iconsCached'] += 1
        else:
            summary['iconsFailed'] += 1
            warnings.append(f"lucide '{name}': {status}（i 标签将原样保留，icon 不会显示，请检查名字拼写）")
            continue
        try:
            svg_map[name] = path.read_text(encoding='utf-8')
        except Exception as e:
            summary['iconsFailed'] += 1
            warnings.append(f"lucide '{name}': 读取本地 SVG 失败 {e}")

    # 3. 逐文件改写：inline + 清理 CDN script + 清理 createIcons 调用
    for f, original in file_contents.items():
        new_text = original
        if svg_map:
            new_text = inline_lucide_svgs(new_text, svg_map)
        new_text, n_scripts = _LUCIDE_CDN_SCRIPT_RE.subn('', new_text)
        new_text, n_calls = _LUCIDE_CREATE_ICONS_RE.subn('', new_text)
        summary['lucideScriptsRemoved'] += n_scripts
        summary['createIconsCallsRemoved'] += n_calls
        if new_text != original:
            try:
                f.write_text(new_text, encoding='utf-8')
                summary['filesProcessed'] += 1
            except Exception as e:
                warnings.append(f"{f.name}: 写回失败 {e.__class__.__name__}")

    return summary, warnings


def main():
    ap = argparse.ArgumentParser(description='lucide 图标本地化（lon-proto-builder Step 5.5）')
    ap.add_argument('--input', required=True, help='prototypes 站点根目录绝对路径（内部自动扫 pages/ + 下载到 assets/icons/）')
    args = ap.parse_args()

    site_root = Path(args.input).resolve()
    summary, warnings = vendor_directory(site_root)

    out = {
        'inputDir': str(site_root),
        'pagesDir': str(site_root / DEFAULT_PAGES_SUBDIR),
        'iconsDir': str(site_root / DEFAULT_ICONS_SUBDIR),
        'summary': summary,
        'warnings': warnings,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
