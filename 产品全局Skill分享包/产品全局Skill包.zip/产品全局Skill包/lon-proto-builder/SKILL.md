---
name: lon-proto-builder
description: 用户说「做个原型 / 设计一个界面 / 把这页 PRD 做成原型 / 做个管理后台 / 按这个 Spec 改原型 / 需要可点击的演示 / 想看到界面效果」，或拿着页面 PRD 想看到能点的界面、即使没明说「原型」时触发。
---

# Prototype Builder

## Overview

根据页面 PRD 生成可浏览器运行的独立 HTML 原型。按信息层级组织内容（不是把 PRD 章节翻译成组件）。

**核心原则**：视觉与布局分离——布局权威来自线框图，视觉权威来自设计规范。

**两种模式**：
- **APP 模式** — 移动端，按 `references/design.md` 视觉契约执行
- **中台模式** — 管理后台，按 `references/admin-template.md` 骨架执行

## When to Use

**触发场景**：
- 有页面 PRD（`docs/prd/pages/*.md`），需要生成可点击的 HTML 原型
- 有 Spec 文件点名的原型修改清单，需要迭代更新原型
- 需要可投屏 / 评审 / 浏览器打开的演示页面

**前置条件**：
- 已有主 PRD（`docs/prd/PRD.md`）+ 页面 PRD（`docs/prd/pages/*.md`）
- 页面 PRD 第 4 章已选定线框图方案（首次生成时）
- 或有 Spec 文件（`docs/specs/*-spec.md`）驱动迭代

## When NOT to Use

- 只有自然语言需求，还没有页面 PRD → 先完成需求分析与页面 PRD 细化，再回本 skill
- 需要高保真设计稿（Figma/Sketch）→ 本 skill 只生成 HTML 原型
- 需要后端 API 集成 → 本 skill 生成静态 HTML，不含后端逻辑

## Quick Reference

| 输入 | 输出 | 模式判定 |
|------|------|---------|
| 主 PRD + 页面 PRD 目录 | `prototypes/pages/*.html` + `prototypes/demo/demo.html` | 关键词：APP/移动端 → APP 模式；中台/后台/admin → 中台模式 |
| Spec 文件 + 旧原型 | 基线锚定式重生成（只改 Spec 点名部分） | 迭代模式 |

## 模式识别

按主 PRD 关键词判定，命中即定，都不命中才问用户：
- 含 `APP / 移动端 / 手机 / iOS / Android` → **APP 模式**
- 含 `中台 / 后台 / admin / dashboard` → **中台模式**
- 都不含 → 询问用户（下方话术）

| 模式 | 规范源 | 引入方式 |
|------|--------|---------|
| APP 模式 | `references/design.md`（移动端视觉规范，含证券领域包，生成前通读判断层、token 按需查） | 原生 CSS + `references/colors_and_type.css`（Token）+ Lucide CDN |
| 中台模式 | AntD 风格（在骨架模板内描述） | Tailwind CDN + `references/admin-template.md`（骨架）|

询问用户时问："这是移动端 APP 页面，还是中台管理系统页面？"

**APP 模式先认品类**（design.md 的视觉内核通用，证券特有部分按品类取舍）：证券 / 资讯 / 理财类 → design.md 全文含【证券领域包】适用；其他品类（社区 / 工具 / 电商 / 内容 / SaaS 等）→ 只用视觉内核，跳过涨跌色 / 证券样例池 / 金融图表，按品类映射色彩语义与真实数据。品类不明显时一并问清。详见 design.md「品类适配」。

---

## 通用设计原则（跨模式）

**克制专业（按基调档）**：默认基调是克制——每个元素都有功能用途，不加装饰性大插画或 Hero 区域。基调分两档（详见 design.md「基调分档」）：**工具 / 数据页**走克制档；**情绪页**（引导 / 会员 / 活动 / 成就 / 品牌首屏）走表现档，允许更大字阶差、更主动留白、品牌色更敢用、可有一个克制的视觉记忆点。表现档仍守 token 体系与自检，不放飞、不引入 AI cliché。页面直接全屏展示——APP 无手机框或设备外壳，中台无额外包装。

**真实感数据**：全中文（含菜单、按钮文案），金额 / 日期用真实感数字、不用 999.99、2024-01-01 这类占位值；用户头像用 CSS 纯色圆形 + 文字缩写。真实人名 / 标的 / 数字格式样例池见 design.md §8.1（APP 证券场景）；中台等其他场景就近取同等真实感的业务用词。

**嵌入式 widget 形态**（如券商 APP 内的功能卡片、宿主 APP 工具入口）：**不画宿主 chrome**（不画宿主 APP 的状态栏 / 导航栏 / 自选股列表等占位内容），widget 本身作为独立全屏页面渲染——即整个 viewport 就是 widget 自己。理由：宿主 chrome 是部署环境的事，原型只承载 widget 内部交互；画了反而抢占视觉注意力、并诱导生成 PRD 未要求的占位元素。

**依赖白名单**：
- APP 模式（开发期）：`colors_and_type.css`（本地 link）+ Lucide CDN（`https://unpkg.com/lucide@latest`）+ `canvas-bootstrap.js`（本地，Step 2 复制到 assets/）
- APP 模式（最终产物，Step 5.5 跑后）：仅 `colors_and_type.css` + `canvas-bootstrap.js` + `assets/icons/*.svg`，**0 网络依赖**
- 中台模式：Tailwind CDN + FontAwesome 6 CDN

两套体系互不混用。不使用 picsum / unsplash / placeholder 等占位图服务——原型需要离线可用。

**图标来源**：APP 模式用 Lucide（`<i data-lucide="home"></i>` 写法，场景图标名现场定、不前置堆映射表；Step 5.5 由 vendor_icons.py inline 为本地 SVG 并清 CDN，最终原型 0 网络依赖）；中台模式用 FontAwesome 6。线性描边 / 尺寸规格、以及「图标与中文同现时不用纯图标替代文字」见 `design.md §9`。纯装饰图标加 `aria-hidden="true"`、功能性图标加 `aria-label`（两模式通用）。

**收敛到决策**：遇到模板 / 反查表未覆盖的情况，选一个合理方案做到底，之后按用户反馈再调，不反复纠结。

**避免过度设计**：仅生成 PRD 明确要求的页面与元素——不补 PRD 未列出的辅助页面（404 / Loading / 引导页）、不加未要求的功能（搜索建议、智能联想、动效彩蛋）、不为「假设的可扩展性」预留无用占位结构。正确的复杂度是当前页 PRD 所需的最小值。唯一例外见下方「演示辅助按钮」。

---

## APP 模式

**规范源**：`references/design.md`（移动端视觉规范，含证券领域包，按「品类适配」取舍）—— 生成 APP 页面前**通读第一部分视觉判断**（定主角 / 节奏 / 数据分量），**第二部分 token 字典按需定点查、不前置背全文**。它是视觉契约权威源。

**Token 文件**：`references/colors_and_type.css`（含两层 token：raw + ui semantic，由 `<html data-tone>` 切换主题；已预置 `.num` / `.up` / `.down` / `.flat` / `.module` / `.card` / `.surface-inset` 数据/模块类 + `.ios-statusbar` / `.ios-navbar` / `.ios-tabbar` / `.ios-home-indicator` iOS chrome 类，原型直接复用，不再自定义）。

**色彩基调**：由项目根 `./prototypes/design_spec.md` 控制（brand=design.md 默认 / monotone=灰阶基调）。首建时由 Step 1.5 gate 与用户确认后落档，每页 HTML `<html data-tone="...">` 标记本档；迭代继承不重弹。css 主题接缝层在 colors_and_type.css 内集中定义，使用方一律取 `--ui-*` 语义 token、不直引 raw 色彩 token（详见 design.md §2.0）。

**起手骨架**：`references/app-template.html`（与中台 `references/admin-template.md` 对称）。

### 两输入源权重（顺序即优先级）

1. **页面 PRD「3. 元素详单」**——元素权威，元素 ID / 名称 / 内容 / 交互 / 状态全靠它
2. **页面 PRD「4. 线框图（首版选定）」**——**布局权威**，必须 Codex file read 一遍（路径 `./docs/wireframes/{XX}-{页面名}/v{N}.html`）：忠实还原其分块骨架、节奏与空间分配（按布局结构高保真重建，非逐 DOM 复用灰阶）。线框是通栏列表就还原成通栏列表，不在高保真阶段重新分块或改包成卡堆（见 design.md §0）。正文「2.2 页面布局图」是模块级结构概览，可辅助理解层级与相对位置

经 design.md §0 忠实还原线框骨架后填 `<main>`，token 与组件细节查 §5 反查表 / §6 组件契约。

### Canvas DOM 契约

每页 HTML 既是下游评审画布平铺的静态快照，也是浏览器直接打开就能点的可演示原型。下列约束高频被破坏、且破坏后下游画布解析失败或浮层错位——使用模板时逐条守住（对应代码位置见 `app-template.html` 内部注释，完整 manifest schema 见 `references/canvas-manifest-spec.md`）：

1. **state / overlay 根节点带 `data-frame="<key>"`**，与 manifest.frames[].key 一一对应。state wrapper 必须包住**完整 chrome**（状态栏 + 导航 + main + Tab + Home Indicator），`data-frame` 挂最外层 wrapper、不能挂内层 `<main>`（每个 state 是含 chrome 的整屏快照，挂外层才能整屏切换、多态结构一致；挂内层则 chrome 落在切换范围外）。多状态时复制整段 wrapper，仅默认态可见、其余态根节点加 HTML `hidden` 属性。
2. **`<style>` 内必含 `[hidden] { display: none !important; }` 兜底**，不可删——否则 `.modal-mask` / `.page-frame` / `.sheet` 上的 `display:flex|block` 会覆盖 HTML `hidden`，导致默认弹窗强显或多 frame 叠加。
3. **浮层写成「fixed 全屏遮罩层 + 主体」两层结构**（主体作为遮罩层的子元素），遮罩层自带半透明背景。画布通过 iframe 整页加载后靠这层结构把浮层还原成浮层视觉（遮罩 + 模糊底层 + 主体）。app-template 用 `bg-overlay` / `modal-mask` 命名，class 名本身不参与画布解析——画布只认 `data-frame` + manifest。
4. **frame 切换只走 `switchFrame` / `toggleOverlay`**（同页 state 互斥切换、浮层开合）。**跨页跳转**用 `<a href="XX-页面名.html">` 或 `location.href='XX-页面名.html'`（跨文件加载，不属于 frame 切换，允许）。**禁用**（仅针对同页 frame 切换）：`location.href='#xxx'` 锚点 / `element.style.display=...` / `element.classList.toggle('hidden')`——它们要么不真切换、要么破坏 `[hidden]!important` 兜底。
5. **`</body>` 前嵌 `<script type="application/canvas-manifest" data-version="1.0">{...}</script>`**，`frames[]` 顺序即下游画布渲染顺序（state → 触发的 overlay → 下一个 state）。画布只认这段 manifest（无正则 fallback）：漏写或 JSON 损坏时下游跳过整页 + 产出 warning，该页不进画布。
6. **canvasMode bootstrap 共享单一源** `../assets/canvas-bootstrap.js`（Step 2 与 `colors_and_type.css` 一同复制到 `prototypes/assets/`），版本号以 `references/canvas-bootstrap.js` 的 `data-canvas-mode-bootstrap` 标记为准，必须与 `app-template.html`、`<skill-dir>/scripts/patch_prototype.py` 的 `PATCH_CSS / BOOTSTRAP_JS` 同版本。升级时同步这三个文件即可，SKILL.md 内不复述具体数字。（app-template.html 仍 inline 一段短的首屏关键 PATCH_CSS，JS 走外部引用。）

**示例与骨架**：完整起手骨架见 `references/app-template.html`（已含 `[hidden]` 兜底、`switchFrame` / `toggleOverlay` 定义、多 state 与浮层片段、manifest 占位、bootstrap 外部引用）；正反 DOM 示例与 manifest 完整实例见 `references/canvas-manifest-spec.md`；违反上述契约的高频错误逐条见下方「Common Mistakes」。

### 本页交互绑定

`switchFrame` / `toggleOverlay` 已在起手骨架的 `<script>` 区预置，按下表挂 `onclick`（来回拨 `hidden` 属性，不破坏上方契约 #4）：

| 场景 | 触发器写法 |
|------|-----------|
| 同页互斥状态切换（Tab、折叠↔展开、月报↔季报） | `onclick="switchFrame('target-key', ['key-a','key-b'])"` |
| 浮层弹出（按钮 → modal / sheet 显示） | `onclick="toggleOverlay('modal-xxx', true)"` |
| 浮层关闭按钮（×、取消、确认完成后） | `onclick="toggleOverlay('modal-xxx', false)"` |
| 浮层点遮罩关闭 | 浮层根节点上 `onclick="if(event.target===this) toggleOverlay('modal-xxx', false)"` |
| 跨页面跳转 | `<a href="XX-页面名.html">` 或 `onclick="window.location.href='XX-页面名.html'"` |

自检：manifest 中每个 `kind:"overlay"` frame 至少一处 `toggleOverlay(key,true)` 触发器 + 浮层根节点和关闭按钮都有 `toggleOverlay(...,false)`；每个 `kind:"state"` frame 若存在同组其他 state（同一区域的 Tab / 收起↔展开 / 空态↔列表态），切换入口走 `switchFrame`，否则浏览器单独打开时切不动。

### 多 state chrome 注入模式（可选优化）

契约 #1 要求每个 state wrapper 都包住完整 chrome。一页有 ≥ 3 个 state 时 chrome 重复多份、单文件可能膨胀 30%+。**默认直接 copy-paste**（可读性好，约 80% 场景接受）；**多 state 时**可把 chrome 放进 `<template id="chrome-tpl">`，各 wrapper 内留 `<div data-chrome-slot></div>` 占位，body 末尾 inline 一段 JS 在 DOMContentLoaded 时 clone 进各 slot：`document.querySelectorAll('[data-chrome-slot]').forEach(s => s.replaceWith(tpl.content.cloneNode(true)))`。

约束：只在 iframe 协议下生效（评审画布通过 iframe 加载，JS 注入后 chrome 在 hydrated DOM 中，安全）；若不同 state 的 chrome 文案不同（"返回"vs"取消"）退回默认 copy-paste；Home Indicator 只一行、省字节有限，保持 inline 即可。

### 演示辅助按钮（允许的过度设计例外）

某些浮层在自然流程中难以触发（如"异步兜底"浮层只在审核超时才弹）。canvas 模式可通过 manifest 定位，但浏览器单独打开时点不到。**允许**加一个 demo 触发入口，必须满足：

- 文案前缀强制 `[模拟]` 或 `[演示]`，如 `[模拟] 触发人工 review →`
- 弱样式：`color: var(--ct4)`、`font-size: var(--fs-label)`、`background: transparent`、`border: 0`（演示按钮不带强调色，跨档保持中性灰）
- 位置远离主操作流，通常放页面底部辅助区
- 不在 manifest 中登记（它是演示桥梁，不是真实业务态）

### Tab 栏渲染判定

**两条都满足才渲染 Tab 栏**：① 主 PRD 定义了底部 Tab 导航集合（如"首页/分类/购物车/我的"）；② 当前页在该集合内。

- **两者皆是** → 渲染 Tab，所有含 Tab 页面 Tab 结构完全一致，当前 Tab `color: var(--ui-accent)` + 其他 `color: var(--ct4)`
- **任一不满足** → 删除 app-template.html 中整段 `<nav class="ios-tabbar">…</nav>`，不留空 `<nav>`

**常见误判**：嵌入式工具（宿主 APP 有 Tab、嵌入工具本身没有自己的 Tab，所有页都不渲染）；单一任务流（注册 / 引导 / 表单，流程内每页是子页，不渲染）；Hub 主页（单一 Hub 不构成 Tab 集合，除非 PRD 明列 Tab 平级页）。

### 跨页导航 SOP

- Tab 栏（如渲染）：各项 `<a href="XX-页面名.html">`，当前 Tab `color: var(--ui-accent)`、其他 `color: var(--ct4)`
- 返回按钮：`<a href="上级页面.html">`，文字/图标 `color: var(--ui-accent)`
- 页面内跳转：依据 PRD「交互逻辑 - 页面跳转表」

---

## 中台模式

**骨架**：`references/admin-template.md`（HTML 结构 + `tailwind.config` + 组件配方）

布局结构：
- 侧边栏：`w-[220px] bg-sidebar-bg fixed inset-y-0 left-0`
- 顶部栏：`h-12 bg-white border-b sticky top-0 z-[90]`，含面包屑和搜索
- 内容区：`ml-[220px] p-6 flex-1`
- 内容卡片：`bg-white rounded-lg shadow-sm p-6 mb-4`

跨页导航：所有页面侧边栏 HTML 结构完全相同，当前页菜单项用 `!bg-primary !text-white` 覆盖；面包屑 `首页 / [当前页面]`，首页链接指向真实首页文件（如 `01-工作台.html`）；表格操作（查看 / 编辑）链接到对应详情 / 编辑页。

`pages/` 下只放 `{XX}-{页面名}.html`，不产出 `index.html` 入口页——演示入口是 Step 7 生成的 `demo/demo.html`，与 APP 模式同路径。目录里若存在 `index.html`，删除它，并确认各页面包屑首页链接指的是真实首页文件。

---

## Common Mistakes

### 1. Canvas 契约违规（现象 → 回查契约条款）

以下四类都是 Canvas DOM 契约被破坏的表现，按「违反哪条」回上文契约节修，不在此复述细节：

| 现象 | 违反 |
|------|------|
| 画布中页面缺状态栏/导航/Tab 栏 | 契约 #1：`data-frame` 误挂 `<main>`，应挂含完整 chrome 的最外层 wrapper |
| 打开页面时浮层/多 state 全部可见 | 契约 #2：缺 `[hidden]{display:none!important}` 兜底，被 `.modal-mask{display:flex}` 覆盖 |
| 某页在评审画布里完全不出现 | 契约 #5：`</body>` 前缺 canvas-manifest 块或其 JSON 解析失败 |
| 点触发器后画布无反应 | 契约 #4：误用 `style.display` / `classList.toggle('hidden')`，同页切换须走 `switchFrame`/`toggleOverlay` |

### 2. 迭代时未点名部分漂移
**问题**：只想改 A 模块，但 B/C 模块的文案、间距也变了  
**原因**：没有以旧 HTML 为基线，从零重写了整页  
**修复**：迭代模式必须 Codex file read 旧 HTML，只改 Spec 3.3 点名部分，未点名部分保持原样

### 3. Tab 栏渲染错误
**问题**：嵌入式 widget 或单任务流页面错误渲染了 Tab 栏  
**原因**：没有判断"主 PRD 定义 Tab 集合"且"当前页在集合内"两个条件  
**修复**：参考"Tab 栏渲染判定"一节，两条件都满足才渲染

### 4. 图标离线化失败
**问题**：Step 5.5 后仍有网络依赖，离线打开图标不显示  
**原因**：`vendor_icons.py` 脚本未成功运行或图标名拼写错误  
**修复**：检查 stdout JSON 摘要中的 `iconsFailed`，修正拼写后 rerun

### 5. 视觉决策卡缺失
**问题**：整页元素都合规，但没有视觉重点  
**原因**：跳过了 Step 4"本页视觉决策卡"前置产物  
**修复**：每页动手前必须先写决策卡（主角/配角/数据分量/疏密节奏），写在 HTML 顶部注释

### 6. 布局与线框图不符
**问题**：线框是通栏列表，生成的是多张独立卡片  
**原因**：没有 Codex file read 线框图 HTML，自行重新设计了布局  
**修复**：Codex file read `docs/wireframes/{XX}-{页面名}/v{N}.html`，忠实还原其分块骨架

### 7. 硬编码占位数据
**问题**：金额显示"999.99"、日期"2024-01-01"  
**原因**：未使用真实感数据  
**修复**：参考 `design.md §8.1` 真实人名/标的/数字格式样例池

---

## 执行流程

### 输入

开始前检查项目根 `product-manifest.json`。存在时，产品名称、正式版本、页面清单、术语和已确认决策以该文件为准；原型内部修订不得自动升级正式版本。新增、删除、改名页面或确认跨页规则时，在本阶段落盘结束前同步清单。规范见同级 `pm-workflow/references/product-manifest.md`。

按是否带 Spec 文件分流：**带 Spec → 迭代模式**；**否则 → 全量 / 指定页模式**。两种入参形态：
- **全量 / 指定页**：主 PRD（`PRD.md`：产品名、平台类型、导航模式）+ 页面 PRD 目录（`prd/pages/{XX}-{页面名}.md`），或单独指定某个页面 PRD。
- **迭代（带 Spec 文件）**：`./docs/specs/{...}-spec.md` 作**驱动指针**——3.2「原型文件清单」点名本次改 / 增哪些 HTML（work-list），3.3「各受影响页的功能变化」给每页改动边界。**本次改动的权威 = Spec 3.3**，旧 HTML 作为基线，页面 PRD（新旧均可）作为「既有内容 / 未改部分」的上下文。被点名页按操作类型分流（新建页全新生成、修改既有页基线锚定式重生成），**未点名页不碰**；动手前先过 work-list gate。详见下「迭代分支」。

### 迭代分支（带 Spec 文件时）

迭代不是把 Step 1–8 重跑一遍——生成前多一道范围确认、对修改既有页改用基线锚定，避免微调被整页推倒重写、避免未点名部分漂移。**完整操作细节见 `references/iteration-guide.md`，动手前必读。**

核心三步：
1. **启动前读 design_spec.md（APP 模式）**：Codex file read `./prototypes/design_spec.md` 拿色彩基调档，本会话沿用，不重弹 Step 1.5 gate。
2. **work-list gate（动手前必过）**：读完 Spec 3.2 + 3.3，列确认表（原型文件 / 操作类型 / 改动点）给用户过目，确认后才生成。
3. **按操作类型分流**：新建页全新生成；修改既有页基线锚定式重生成（Codex file read 旧 HTML 作基线，只改 3.3 点名模块，self-diff 核对）；废弃页删除并从 demo.html 移除；未点名页不碰。

### 生成步骤

**Step 1 — 读取 PRD + 对应规范**
- 主 PRD：产品名、平台类型（APP/中台）、导航模式
- 页面 PRD：页面名称、定位（入口/出口）、模块结构、元素详单
- APP 模式额外读：`references/design.md` **第一部分视觉判断（通读）** + `references/colors_and_type.css`；design.md 第二部分 token 字典生成时按需查，不前置全读
- 中台模式额外读：`references/admin-template.md`

**Step 1.5 — 视觉基调 gate（仅 APP 模式）**

色彩基调（brand / monotone）是项目级一次性决策，避免 AI 自作主张在两种风格之间游移。判定与执行：

1. **判定**：
   - `./prototypes/design_spec.md` **已存在** → Codex file read 它拿基调档，跳过 gate，直接进 Step 2
   - **不存在** → 触发 gate
2. **gate**（用 Codex confirmation 二选一，会话内仅一次）：

   | 选项 | 视觉表现 |
   |---|---|
   | A. 品牌基调（brand，默认） | 主 CTA 用品牌色、涨跌红绿、状态色完整（design.md 全规则） |
   | B. 灰阶基调（monotone） | chrome 全灰、主 CTA 深灰底白字、涨跌用 +/− 符号 + `.num` 字体（颜色统一深灰）、状态色让步为灰（靠 lucide 图标 + 文案传达） |

3. **边界 case（旧项目首次跑）**：若 `prototypes/pages/` 已有 HTML 但无 `design_spec.md`，先快速扫一页 HTML——出现 `class="up\|down\|flat"` 或 `var(--cp0|--cs1|--cs2)` 等 → 给推荐选项 A；否则给推荐选项 B；用户确认后落档。
4. **落档**：确认后 Write `./prototypes/design_spec.md`（3 行）：

   ```markdown
   # 视觉契约

   基调档：monotone（灰阶基调）  # 或 brand（品牌基调）
   决策时间：YYYY-MM-DD
   ```

5. **对下游的影响**：此决策通过每页 `<html data-tone="brand|monotone">` 一处级联全站 CTA / 涨跌 / 状态 / 强调色（colors_and_type.css 已含 `[data-tone="monotone"]` 覆盖块，使用方一律取 `--ui-*` 语义 token，见 design.md §2.0 / §2.7）；落地写法见 Step 4，grep 校验见 Step 6

**Step 2 — 复制本地资源到 prototypes/assets/（仅 APP 模式）**

主 agent 一次性把两份共享资源从 skill references 复制到本项目 `./prototypes/assets/`：
1. `references/colors_and_type.css` → `./prototypes/assets/colors_and_type.css`
2. `references/canvas-bootstrap.js` → `./prototypes/assets/canvas-bootstrap.js`

后续每个原型 HTML（落 `./prototypes/pages/`）通过相对路径引用：
- `<link rel="stylesheet" href="../assets/colors_and_type.css">`
- `<script src="../assets/canvas-bootstrap.js" data-canvas-mode-bootstrap="…"></script>`（版本号属性由 `app-template.html` 预置，复制骨架时原样带入）

这让 `prototypes/` 成为自包含的评审站点根（lan-launcher 直接服务，画布消费不丢样式 / bootstrap）。中台模式跳过此步。

**Step 3 — 构建页面导航图**
- 基于页面入口来源和出口去向，建立页面间链接关系
- 确定共享导航组件：APP → Tab 栏集合（按「Tab 栏渲染判定」决定是否渲染）；中台 → 侧边栏菜单列表

**Step 4 — 逐页生成 HTML**

- **每页动手前先落「本页视觉决策卡」（强制前置产物，APP 模式必做）**：写 HTML 前先明确并写进该页 HTML 顶部注释——⓪ 色彩基调档：{brand / monotone}（取自 `prototypes/design_spec.md`，决定本页 CTA / 涨跌 / 状态 / 强调色策略）；① 本页信息密度基调档（克制 / 表现）；② 主角是谁、用什么手段让它跳出来；③ 配角是谁、怎么压低；④ 数据类页型：哪个数字放大、哪些压成参考值；⑤ 疏密节奏怎么排。这步把 design.md 第一部分的判断变成可检查的产物；不写决策卡不许进入填色——跳过它就会退回「机械填色」（每个元素都合规、整屏却没有重点）
- **每页 `<html>` 标签必须带 `data-tone="brand|monotone"`**（值取自 design_spec.md），起手骨架 `app-template.html` 已预设默认值 `brand`，monotone 项目生成时改成 `monotone`。css 主题切换由此属性一处控制、自动级联，使用方写视觉时一律取 `--ui-*` 语义 token（CTA / 涨跌 / 状态 / 强调）；中性 chrome 文字 / 背景 / 边框（`--ct*/--cb*/--cl*`）继续直引 raw token，跨档相同（design.md §2.0）
- **迭代「修改既有页」不在此从零重写**：按上文「迭代分支」基线锚定——以旧 HTML 为基线，只改 Spec 3.3 点名模块，未点名部分保持原样
- 页面数 ≥ 5 时用 TaskCreate 跟踪：每页一条 task，开始前 in_progress、写完后 completed，让用户看到进度
- 按页面 PRD 序号顺序：APP 模式 Codex file read `references/app-template.html` 作起手骨架 + Codex file read 页面 PRD 第 4 章线框图指定的 wireframe HTML 作布局参考；中台模式 Codex file read `references/admin-template.md`
- 三源融合按上文「三输入源权重」，APP 模式严格按 design.md §5 反查表选 Token、§6 组件契约约束视觉
- **元素详单含图表元素时**（走势 / K 线 / 分时 / 净值 / 占比 / 配置 / 排行 / 资金流 / 成交量 / 评分 / 仓位 / 多维评分 / 能力画像 等），先读 `references/chart_design.md`：按「模块 → 图表类型映射」选型、按「要素清单」手绘专业 SVG 图表（吃 token、零图表库），禁止画无坐标系 / 无标注 / 数据点稀疏的敷衍线条
- 插入跨页导航链接（基于 Step 3 导航图），同级 `<a href="XX-页面名.html">`（都在 pages/ 下，相对路径不带前缀）
- 文件名：`prototypes/pages/{XX}-{页面名}.html`
- APP 模式逐项守住上文「Canvas DOM 契约」

**Step 5 — 写 canvas-manifest 块**
- 按「Canvas DOM 契约」#5 嵌入 manifest，schema 见 `references/canvas-manifest-spec.md`
- 浮层 `triggers[]` 记录「来自哪个 state、由什么按钮触发」；多触发源写法见 spec（action 数组 或 多 trigger 对象共享 fromStateKey）
- **toast 不进 manifest**：toast 是瞬时反馈、自起自消、不在画布单独占帧；不写 `data-frame`、不走 `toggleOverlay`，由 setTimeout 自动隐藏。只登记 modal / sheet / drawer / popup 这类需用户主动关闭的浮层

**Step 5.5 — 图标本地化（仅 APP 模式）**

主 agent 跑：
```bash
python3 <skill-dir>/scripts/vendor_icons.py --input <prototypes 绝对路径>
```

脚本以 `prototypes/` 为根，扫 `prototypes/pages/` 下所有 .html，按需从 `unpkg.com/lucide-static` 下载用到的 SVG 到 `prototypes/assets/icons/`，inline 进每个 `<i data-lucide>`，并无条件删除 lucide CDN script 与 `createIcons()` 调用（强制离线化）。读 stdout JSON 摘要（`filesProcessed` / `iconsUnique` / `iconsDownloaded` / `iconsCached` / `iconsFailed` / `lucideScriptsRemoved` / `createIconsCallsRemoved` / `warnings`）向用户复述。

脚本对网络抖动内置重试，一般一次拿全。若摘要仍 `iconsFailed > 0`，rerun 同命令会用缓存跳过已成功的、再重试失败的；单个 SVG 最终仍失败时 warning 列出 icon 名、对应 `<i>` 保留（让用户看到拼写错误位置），CDN script 与 createIcons 仍删（部分缺图也比假装能用更诚实）。中台模式跳过。

**Step 6 — 全局自检**（checklist 式核对，每项的 why 见对应规范节）

通用（两模式）：
- [ ] 所有页面间 `<a href>` 指向已生成文件
- [ ] 中文真实感内容，无 Lorem Ipsum / 英文占位
- [ ] 图标有 aria 属性（功能性 `aria-label`、装饰性 `aria-hidden`）
- [ ] 无大面积花哨全页渐变背景、无 picsum / unsplash 占位图
- [ ] head 依赖白名单干净：APP 只引 `../assets/colors_and_type.css` + `../assets/canvas-bootstrap.js`，无 Tailwind / Lucide CDN 残留；中台只引 Tailwind + FontAwesome
- [ ] Step 2 资源齐全：`prototypes/assets/` 下 colors_and_type.css + canvas-bootstrap.js 存在，每个 pages/*.html 都引用

APP 模式 — Step 5.5 已跑的证据：
- [ ] `grep -c '<script src=.*lucide' prototypes/pages/*.html` 与 `grep -c 'lucide\.createIcons' prototypes/pages/*.html` 全为 0，且 `prototypes/assets/icons/` 下有相应数量 SVG

APP 模式 — Canvas DOM 契约（逐条回引上文同名节，此处只核对结果）：
- [ ] 每个 state / overlay 根有 `data-frame`，与 manifest key 一一对应（契约 #1）
- [ ] state wrapper 含完整 chrome、`data-frame` 挂最外层不挂 `<main>`（契约 #1）
- [ ] 多状态用 `hidden` 属性 + `<style>` 含 `[hidden]{display:none!important}` 兜底（契约 #2）
- [ ] 浮层是 fixed 全屏遮罩层包住主体、能自渲染为浮层视觉（契约 #3）
- [ ] frame 切换走 `switchFrame`/`toggleOverlay`，跨页走 `<a href>`；overlay 有开 + 关入口、同组 state 切换走 `switchFrame`（契约 #4 + 本页交互绑定）
- [ ] `</body>` 前有 canvas-manifest 块，frames[] 顺序 = 渲染顺序（契约 #5）

APP 模式 — 视觉契约维度：
- [ ] 全部对照 `references/design.md` §10 输出前自检清单（颜色 Token / `.num` / 涨跌色 / 错误色 / 字重封顶 / 触控规范 / 内容真实感 / 一屏一 primary）
- [ ] chrome 用 `.ios-statusbar`/`.ios-navbar`/`.ios-tabbar`/`.ios-home-indicator` utility class，不回退 inline style
- [ ] Tab 栏遵守「Tab 栏渲染判定」（不该渲染时整段删除）；嵌入式 widget 不画宿主 chrome
- [ ] 忠实还原布局：按线框图还原分块，不重新分组、不把通栏列表改包成多张独立卡（design.md §0）；视觉层精修（视觉轻重 / 间距节奏 / 对齐）已做到位
- [ ] 已用 `references/design-review.md` 五维自检卡过一遍（视觉层级 / 信息节奏 / 数据分量 / 细节执行 / 一致性与克制），含眯眼测试 + 删除测试，任一维度「不合格」就地修后再交付

APP 模式 — 主题切换维度（Step 1.5 落档的后置校验）：
- [ ] 每页 `<html>` 标签带 `data-tone="brand|monotone"` 属性，值与 `prototypes/design_spec.md` 标定一致：`grep -L 'data-tone="\(brand\|monotone\)"' prototypes/pages/*.html` 应为空（输出未带该属性的文件列表）
- [ ] 色彩用 `--ui-*` 语义 token，未直引 raw 色彩 token：`grep -nE 'var\(--(cp[0-9]|cp0-wash|cp-warm|cs[0-9]|cf[0-9]|shadow-brand|grad-ai)\)' prototypes/pages/*.html` 应为 0 命中（中性 chrome `--ct*/--cb*/--cl*` 不在禁列，例外）

中台模式：
- [ ] 所有页面侧边栏 HTML 结构完全一致，当前页菜单项加 `!bg-primary !text-white`

迭代模式（带 Spec 文件）：
- [ ] work-list gate 已确认后才动手；修改既有页已对照旧 HTML self-diff，改动只落在 Spec 3.3 点名范围、未点名模块零漂移

### Step 6.5：全页交互巡检（交付用户确认前必过）

生成或迭代完成后，以实际 HTML 为对象做一次全页巡检，并输出“通过 / 未通过 / 不适用”清单：

- 所有带下拉图标或下拉语义的控件都有可打开的选项层、选中回显和关闭方式；
- 搜索、查询、重置、时间、组织、状态、排序与分页不是仅弹 toast 的静态占位，除非页面 PRD 明确为演示占位；
- 组织树、层级表格、Tab、弹窗、抽屉均有打开和关闭路径，父子状态同步；
- 每个页面内链目标真实存在，改名页面同步更新导航、演示入口和所有引用；
- 加载中、空态、错误、无权限和业务特有状态已实现或在研发澄清待补清单中明确；
- 在设计基准宽度以及更宽一级桌面视口检查内容区，没有固定窄容器造成大面积无意义空白；
- 扫描产品名称、页面名称、模型名称和禁用旧术语，发现漂移必须在确认前修复；
- 核心指标提供计算口径和数据更新时间入口（需求明确不适用的实时页除外）。

不要把“HTML 可打开”视为交互巡检通过。发现缺失时先修复原型，再邀请用户确认。
- [ ] 废弃页已删除并从 demo.html 的 PAGES 数组移除

**Step 7 — 生成 demo.html 演示页**
- 按模式 Codex file read 模板（两者占位符与 PAGES 数组契约完全一致；HTML-escape / JSON 序列化 / iframe sandbox 取舍等替换规则详见各自顶部注释块，生成前必读）：
  - APP 模式 → `references/demo.template.html`（左侧页面列表 + 居中手机框）
  - 中台模式 → `references/demo-admin.template.html`（页面索引页，点卡片全屏打开真实页面，不套设备框）
- 扫 `prototypes/pages/` 下所有 `XX-页面名.html`，按文件名序号升序构造 PAGES 数组，元素 `{ file: "../pages/XX-页面名.html", label: 去 XX- 序号前缀和 .html 后缀的中文页面名 }`
- 替换两个占位符后 Write 到 `prototypes/demo/demo.html`
- 自检：`grep '__PRODUCT_NAME__\|__PAGES_ARRAY__' prototypes/demo/demo.html` 无命中，否则视为失败、重做

**Step 8 — 建议下一步**

完成自检与 demo.html 后主动提示：
```
原型生成完成：prototypes/pages/ 下共 N 个 HTML 文件
附带：prototypes/demo/demo.html（演示页：APP 为无刘海手机框，中台为页面索引；双击打开即可投屏 / 评审用）

建议下一步：用户确认后可运行 /lon-proto-canvas 生成画布预览
    PRD 目录    = {prd 路径}
    原型页面目录 = {prototypes/pages 绝对路径}      ← proto-canvas --input 传这个
    站点根目录   = {prototypes 绝对路径}            ← proto-canvas --output 传这个（评审画布会落在站点根）
```

## 交付演示约束

- APP / H5 原型的对外“可点击演示”入口一律指向 `prototypes/demo/demo.html`，由手机壳 iframe 承载 `375 × 812` 级视口；不要把交付中心或分享链接直接指向 `pages/*.html`，以免桌面浏览器拉宽移动端界面。
- `pages/*.html` 仍是原型源页和画布输入，可直接打开用于编辑调试；演示壳才是业务、合规和研发走查入口。
- 对外整理交付包时，将这三项交给 `lon-product-delivery`：交付中心、文档预渲染、相对链接与移动后的可用性校验。

---

## 参考文件

| 文件 | 内容 | 何时读取 |
|------|------|---------|
| `references/design.md` | 移动端视觉规范（APP 模式权威源，含证券领域包）：品类适配 / 基调分档 / §0 忠实还原 + 视觉精修 / 视觉判断 / Token 反查表 / 组件契约 / 文案 / 图标 / 自检 | 第一部分判断层生成前通读；第二部分 token 字典按需查（Step 1/4） |
| `references/design-review.md` | 生成后视觉自检卡：五维合格线 + 眯眼/删除测试 + AI 味十宗罪（反例→正例）+ 输出模板 | Step 6 自检时（仅 APP 模式） |
| `references/colors_and_type.css` | 完整 CSS Token + 预置 utility class（数据/卡片类 + iOS chrome 类） | Step 2 复制时；查 Token 名时 |
| `references/canvas-bootstrap.js` | canvasMode bootstrap 单一源（IIFE，~150 行）：解析 URL → activate frame → 拦截交互 → postMessage 上报高度 | Step 2 复制时 |
| `references/app-template.html` | APP 起手骨架（iOS chrome + bootstrap src 引用 + switchFrame/toggleOverlay + manifest 占位 + 多状态&浮层注释片段） | Step 4 生成 APP 页面时 |
| `references/admin-template.md` | 中台 HTML 骨架 + `tailwind.config` + 组件配方（表格 / 表单 / 指标卡 / 状态 Tag / 分页 / 筛选栏 / Modal） | Step 4 生成中台页面时 |
| `references/chart_design.md` | 图表设计：模块 → 图表类型映射 + 各图表要素清单 + 手绘 SVG 规范 | Step 4 元素详单含图表元素时 |
| `references/canvas-manifest-spec.md` | 与评审画布的元数据契约：data-frame DOM 标记 + manifest schema + 1 浮层多触发源写法 | Step 5 写 manifest 前 |
| `references/iteration-guide.md` | 迭代分支详细操作指南：work-list gate + 基线锚定式重生成 + self-diff + 常见陷阱 | 带 Spec 文件迭代时（动手前必读） |
| `references/demo.template.html` | APP 手机框演示页模板（含 `__PRODUCT_NAME__` 与 `__PAGES_ARRAY__` 占位符） | Step 7 生成 demo.html 时（APP 模式） |
| `references/demo-admin.template.html` | 中台页面索引演示页模板（占位符与 PAGES 契约同上） | Step 7 生成 demo.html 时（中台模式） |
| `scripts/vendor_icons.py` | 图标本地化：扫 HTML 中 `<i data-lucide>` 按需下载 SVG 并 inline，移除 lucide CDN；内置网络重试 | Step 5.5 跑（仅 APP 模式） |
