#!/usr/bin/env python3
"""画布 layout.json 几何自检：连线穿越非端点节点、节点重叠。

用法: python3 check_layout.py <layout.json 路径> [id前缀]
  id前缀  只检查 id 含此前缀的图形（如 -flow）；缺省检查全部 flow/arrow 图形
出口码: 0 = 零 finding，1 = 有问题
"""
import json, sys

def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "./prototypes/layout.json"
    prefix = sys.argv[2] if len(sys.argv) > 2 else ""
    d = json.load(open(path))
    keep = lambda s: (not prefix) or prefix in s.get("id", "")
    shapes = {s["id"]: s for s in d["shapes"]}
    nodes = [s for s in d["shapes"] if s.get("kind") in ("flow", "rect") and keep(s)]
    arrows = [s for s in d["shapes"] if s.get("kind") == "arrow" and keep(s)]

    def box(s): return (s["x"], s["y"], s.get("w", 0), s.get("h", 0))

    def anchor_pt(s, a):
        x, y, w, h = box(s)
        return {"top": (x + w / 2, y), "bottom": (x + w / 2, y + h),
                "left": (x, y + h / 2), "right": (x + w, y + h / 2)}[a]

    # 复现 canvas.js arrowPoints：elbow 同轴 Z 型 / 异轴 L 型，straight 两点
    def arrow_pts(e):
        def resolve(end):
            if end.get("shapeId") in shapes:
                return anchor_pt(shapes[end["shapeId"]], end["anchor"])
            return (end.get("x", 0), end.get("y", 0))
        p1, p2 = resolve(e["from"]), resolve(e["to"])
        if e.get("route") != "elbow":
            return [p1, p2]
        mid = min(0.95, max(0.05, e.get("mid", 0.5)))
        def axis(end, self_pt, other):
            if "anchor" in end:
                return "v" if end["anchor"] in ("top", "bottom") else "h"
            return "h" if abs(other[0] - self_pt[0]) >= abs(other[1] - self_pt[1]) else "v"
        a1, a2 = axis(e["from"], p1, p2), axis(e["to"], p2, p1)
        if a1 == "h" and a2 == "h":
            xm = p1[0] + (p2[0] - p1[0]) * mid
            return [p1, (xm, p1[1]), (xm, p2[1]), p2]
        if a1 == "v" and a2 == "v":
            ym = p1[1] + (p2[1] - p1[1]) * mid
            return [p1, (p1[0], ym), (p2[0], ym), p2]
        return [p1, (p2[0], p1[1]), p2] if a1 == "h" else [p1, (p1[0], p2[1]), p2]

    # 轴对齐线段 vs 节点包围盒（留 4px 余量，贴边不算穿越）
    def seg_hits_box(p, q, b, pad=4):
        x1, y1, x2, y2 = b[0] + pad, b[1] + pad, b[0] + b[2] - pad, b[1] + b[3] - pad
        if p[0] == q[0]:
            if not (x1 < p[0] < x2): return False
            lo, hi = sorted([p[1], q[1]]); return lo < y2 and hi > y1
        if p[1] == q[1]:
            if not (y1 < p[1] < y2): return False
            lo, hi = sorted([p[0], q[0]]); return lo < x2 and hi > x1
        return False  # 非轴对齐段（straight 斜线）不做穿越判定

    issues = []
    for e in arrows:
        pts = arrow_pts(e)
        ends = {e["from"].get("shapeId"), e["to"].get("shapeId")}
        for i in range(len(pts) - 1):
            for n in nodes:
                if n["id"] in ends: continue
                if seg_hits_box(pts[i], pts[i + 1], box(n)):
                    issues.append(f'{e["id"]} 段{i} {pts[i]}->{pts[i+1]} 穿过 {n["id"]}「{n.get("text","")[:16]}」')
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            a, b = box(nodes[i]), box(nodes[j])
            if a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]:
                issues.append(f'节点重叠: {nodes[i]["id"]} / {nodes[j]["id"]}')

    print(f"节点 {len(nodes)} 连线 {len(arrows)} 问题 {len(issues)}")
    for s in issues: print(" ", s)
    sys.exit(1 if issues else 0)

main()
