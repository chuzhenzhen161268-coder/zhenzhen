# 画布图形数据 Schema 速查

数据源：`./prototypes/layout.json` 的 `shapes[]`。字段权威以 `./prototypes/assets/canvas.js` 为准（`SHAPE_DEFS` / `createLinkedNode` / 箭头工具落笔 / 连线标签段），本表是速查，冲突时以源码为准。

## 节点（流程符号）

```json
{
  "id": "sh-flow-01",
  "kind": "flow",
  "variant": "process",
  "x": 6240, "y": -770,
  "w": 160, "h": 56,
  "text": "节点文字"
}
```

- `variant` 取 `SHAPE_DEFS` 的 key。流程组（`F` 面板）：`start` 起止胶囊 / `process` 圆角矩形 / `decision` 菱形 / `io` 平行四边形 / `data` 圆柱 / `doc` 文档 / `connector` 连接点圆 / `predefined` 预定义处理（双线框）/ `manualOp` / `manualInput` / `delay` / `prep` 六边形 / `display` / `multidoc` / `offpage` 页外连接
- 几何组（`R` 面板）额外有：`square` 矩形 / `triangle` / `triangleDown` / `trapezoid` / `pentagon` / `star` / `cross` / `arrowRight` 块箭头 / `cloud` 云形；`kind: "rect"` 是普通方框（不属于 flow）
- 锚点四边中点：`top` `(x+w/2, y)`、`bottom` `(x+w/2, y+h)`、`left` `(x, y+h/2)`、`right` `(x+w, y+h/2)`
- 菱形（decision）内部可用宽度约为盒宽一半，文字要短，长文案放连线标签

## 连线（箭头）

```json
{
  "id": "sh-arw-01",
  "kind": "arrow",
  "from": { "shapeId": "sh-flow-01", "anchor": "bottom" },
  "to":   { "shapeId": "sh-flow-02", "anchor": "top" },
  "route": "elbow",
  "mid": 0.5,
  "label": "分支标签"
}
```

- 端点两种形态：吸附 `{shapeId, anchor}`（跟随节点移动）或自由点 `{x, y}`；也可吸附 frame 卡片 `{frameId, anchor}`
- `route`：`"elbow"` 折线（缺省/非法值按 `"straight"` 直线处理）；直线忽略 mid
- elbow 路由：两端主轴相同 → Z 型四点，`mid`（clamp 0.05–0.95）控制中段位置；主轴不同 → L 型三点，角点固定不可调。主轴：top/bottom 锚点 = 纵轴，left/right = 横轴；自由端按两端位移主方向推断
- `label` 可选，渲染在线路几何中点；缺省或空串不建 DOM
- 同一锚点允许多条边共挂

## 文字与其他

```json
{ "id": "sh-txt-01", "kind": "text", "x": 1360, "y": -750, "text": "注释文字" }
{ "id": "sh-img-01", "kind": "image", "x": 1360, "y": -722, "w": 800, "h": 292, "src": "assets/canvas-images/xxx.png" }
```

- text 图形随内容撑开，无稳定包围盒，不能当连线端点宿主
- 便签 `kind: "note"` 带颜色语义（yellow/pink/blue/green），画流程图不用

## 顶层结构与镜像

```json
{ "version": "2", "frames": [...], "shapes": [...], "updatedAt": "ISO8601" }
```

- `layout.js` 是 `file://` 下的镜像，格式固定两行：

```
window.__CANVAS_DATA__ = window.__CANVAS_DATA__ || {};
window.__CANVAS_DATA__["layout"] = <与 layout.json 逐字一致的 JSON>;
```

- 画布读路径是静态 GET `layout.json`（`file://` 读 `layout.js`）；两个文件必须同步双写
- id 只需全局唯一；建议单图统一 id 前缀（如 `-flow01`），便于幂等清除重写
