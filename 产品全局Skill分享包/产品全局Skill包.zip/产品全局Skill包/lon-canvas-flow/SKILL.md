---
name: lon-canvas-flow
description: Use when 用户要在评审画布上画流程图、状态机、流转图、关系图，或说「把流程/状态机画到画布上 / 在画布上画出来 / 加一张图到画布」；节点与连线较多、UI 手绘低效，需要批量精确落图时触发
---

# 画布流程图数据直写

## Overview

评审画布的图形（流程符号 / 箭头 / 文字 / 便签）全部持久化在 `./prototypes/layout.json` 的 `shapes[]` 里。按 schema 批量直写，等价于在画布 UI 里用 `R` / `F` 面板手绘，但精确、可复算、可幂等重写。落盘后图形即原生对象：可拖拽、可改字、可重连，与手绘无差别。

核心原则：**schema 以 `./prototypes/assets/canvas.js` 源码为准（读代码，不猜字段）；落盘后必须几何自检 + 截图目检两道验证。**

## When to Use

- 用户要求在画布上画流程图 / 状态机 / 数据流图，且节点边数较多（≥5 节点）
- 需要把 PRD / Spec 里的 mermaid 流程图落成画布原生图形（可标注、可随画布分享）

**不适用：**
- 只要一张静态图文档 → 直接写 mermaid 进 md，不动画布
- 只加两三个框一条线 → 让用户在画布 UI 手绘更快（`F` 键出流程面板）
- 画布尚未生成（`./prototypes/layout.json` 不存在）→ 先生成画布

## Workflow

### Step 0：定口径 + ASCII 确认

1. 从权威文档（PRD 业务流程图 / 状态枚举、Spec 分支口径）提取节点与边清单，**先列全边再排版**——漏边事后补代价大
2. 用 ASCII 画出布局给用户确认后再动手（图形化表达先确认的通用规则在此同样适用）

### Step 1：读 schema

字段规则读 `./prototypes/assets/canvas.js` 三处：`SHAPE_DEFS`（轮廓清单与默认尺寸）、`createLinkedNode`（flow 节点字段）、箭头落笔处（arrow 字段）与连线标签段。速查表见 [references/shapes-schema.md](references/shapes-schema.md)。

### Step 2：车道布局 + 逐边路由推演

1. **分车道**：主轴一条纵向车道（脊柱），分支各踞左右车道，车道间距 ≥400px；枢纽节点（出入边最多的）放脊柱或紧邻脊柱
2. **逐边推演路由**，每条边确定：起止锚点（top/bottom/left/right 四边中点）、route、mid。推演规则见下节「路由铁律」，**每条边都要过一遍，不允许「先写上去再看」**
3. 出入边超过 4 条的枢纽节点，按方向分配锚点：上进、下出、左右进/出，同向多边共锚点允许但同 y 段会重叠，用不同 mid 错开

### Step 3：幂等写入

Python 脚本完成：备份 → 按 id 前缀清除本图旧图形 → 追加 → 双写 `layout.json` 与 `layout.js` 镜像 → 刷新 `updatedAt`。

```python
import json, datetime, shutil
p = "./prototypes/layout.json"
shutil.copy(p, p + ".bak.before-flow")
d = json.load(open(p))
PREFIX = "-flow"                      # 本图所有 id 的统一后缀，幂等重写靠它清除旧图形
d["shapes"] = [s for s in d["shapes"] if PREFIX not in s.get("id", "")]
d["shapes"].extend(nodes + edges + texts)   # 见 shapes-schema.md 的字段模板
d["updatedAt"] = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
open("./prototypes/layout.js", "w").write(
    'window.__CANVAS_DATA__ = window.__CANVAS_DATA__ || {};\n'
    'window.__CANVAS_DATA__["layout"] = ' + json.dumps(d, ensure_ascii=False) + ';\n')
```

### Step 4：几何自检（必跑）

```bash
python3 <skill-dir>/scripts/check_layout.py ./prototypes/layout.json <id前缀>
```

复现画布 elbow 路由算法，检测两类问题：**连线穿过非端点节点包围盒**、**节点互相重叠**。零 finding 才进下一步。

### Step 5：截图目检（必做）

几何无碰撞不代表可读（标签位置、边平行间距、视觉歧义只有截图能发现）：

1. 探测服务端口：`curl -s http://localhost:<port>/layout.json | grep -c "<id前缀>"`，返回 0 的端口是旧服务，换端口或重启
2. playwright 截图（node 脚本，画布视口变换 = `scale(zoom)` + 滚动容器；**内容点滚动坐标 = CANVAS_PAD + 本地坐标 × zoom**，CANVAS_PAD 默认 2000）：

```js
const { chromium } = require('playwright');
const page = await (await chromium.launch()).newPage({ viewport: { width: 1920, height: 1080 } });
await page.goto('http://localhost:<port>/', { waitUntil: 'networkidle' });
await page.waitForTimeout(2500);
await page.evaluate(() => {
  const z = 0.55;   // 按图形包围盒换算：z = min(视口宽/图宽, 视口高/图高)
  document.getElementById('canvasStage').style.transform = `scale(${z})`;
  const s = document.getElementById('canvasScroll');
  s.scrollLeft = 2000 + minX * z - (1920 - 图宽 * z) / 2;
  s.scrollTop  = 2000 + minY * z - (1080 - 图高 * z) / 2;
});
await page.screenshot({ path: 'flow-check.png' });
```

3. Codex image viewer 读回截图，逐边核对走向与标签无歧义；有问题改坐标重跑 Step 3–5

## 路由铁律（逐边推演必读）

画布 elbow 路由：两端主轴相同 → Z 型四点（`mid` 控制中段位置，clamp 0.05–0.95）；不同 → L 型三点（角点固定为 `(p2.x, p1.y)` 或 `(p1.x, p2.y)`，**不可调**）。主轴由锚点决定：top/bottom = 纵轴，left/right = 横轴。

- **侧锚点只能水平进出**：从上方/下方走近 left/right 锚点，线段必穿过节点盒——这是几何必然，换锚点解决，不要侥幸
- **Z 型中段只能在两锚点坐标之间**（mid clamp）：两锚点 x 接近时，竖段无法甩出该区间绕开中间障碍——此路不通就换锚点组合
- **底锚点必须从下方接近、顶锚点从上方接近**：反向接近 = 穿过节点盒内部
- **双向边（A⇄B）同通道必重叠**：两条反向 L/Z 走同一对锚点会完全重合且不可见，必须拆到不同锚点 + 不同 mid，拉开 ≥30px 平行间距
- **left/right 锚点出发、目标在反侧**：第一段水平线会先穿过自身节点盒，禁止
- 连线标签渲染在线路几何中点，选 mid 时顺带考虑标签落点别压着节点

## Common Mistakes

| 错误 | 症状 | 修复 |
|------|------|------|
| 凭印象写字段不读 canvas.js | 图形不渲染或样式错乱 | schema 单一源是 canvas.js 源码，references 只是速查 |
| 只写 layout.json 漏 layout.js | `file://` 打开画布看不到图 | 双写镜像，内容逐字一致 |
| 写完不自检 | 连线穿节点、双向边重叠 | Step 4/5 两道验证不可省 |
| 截图连到旧服务端口 | 画布上找不到新图 | 先 grep 探测哪个端口服务的是最新 layout.json |
| 重跑不清旧图形 | 同一图画两遍互相压盖 | id 统一前缀 + 写入前按前缀清除 |
| 在写服务模式画布打开时改文件 | 客户端内存态覆盖回写 | 写入后让用户刷新页面，客户端状态以文件为准重新加载 |

## 下一步

图画完并目检通过后，建议用户在画布上拖动微调、双击改文字定稿；随画布分享前用画布自带的导出静态包流程发布。
