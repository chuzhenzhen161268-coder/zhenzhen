---
name: lon-prd-craft
description: 用户需求分析已完成且需要新建或迭代主 PRD 文档时使用；入口是已批准 Spec 文件（./docs/specs/*-spec.md）；Spec 缺失、未批准、有阻塞未决项时停止并回上游修订；`/lon-prd-craft` 命令应触发。
---

# Lon PRD Craft

## 概述

把已批准的 Spec 翻译成可落地的主 PRD：产品结构骨架 → 业务流程图 → 写出 `./docs/prd/PRD.md`。融合 Product Discovery 四维视角（价值 / 可用性 / 可行性 / 商业可行性）复核产品路线。

## 触发场景

**使用条件：**
- 需求分析已完成，有已批准 Spec 文件
- 需要新建或迭代主 PRD 文档
- Spec 显式列出「改的范围」和「不改的范围」

**迭代分流：**

本 skill 只处理**涉及产品结构 / 流程变化的大改**——业务流程图、产品结构骨架、页面索引变更。若本次迭代**只改页面内元素、交互细节、视觉样式、主 PRD 不动**，则无需经过主 PRD 阶段，可跳过本 skill 直接进入原型迭代。

**触发信号：**
- 用户说「按这份 Spec 写主 PRD」
- 用户说「把这个 Spec 做完整产品设计」
- 用户说「补主 PRD 的业务流程图」
- 用户传入 `./docs/specs/*-spec.md` 路径

**停止信号（回上游或分流）：**
- 入参是自然语言想法 / 截图 / 未批准需求 → `/lon-req-discovery`
- Spec 有阻塞未决项 / 范围不闭合 / 缺 PRD 文件清单 → 回上游修订 Spec
- Spec 缺竞品差异 / AI 能力边界 / 目标用户画像 → 回上游修订 Spec
- **迭代且只改页面内元素、不涉及产品结构/流程** → 建议走捷径 `/lon-proto-builder --spec [spec路径]`

## 快速参考

### Phase 0：模式检测

```dot
digraph phase0 {
    rankdir=TB;
    node [shape=box, style=rounded];
    
    start [label="入参类型?", shape=diamond];
    read_spec [label="读 Spec"];
    check_mode [label="Spec 模式字段?", shape=diamond];
    greenfield [label="greenfield\n写首版主 PRD"];
    iterate [label="iterate\n改点名章节"];
    brownfield [label="brownfield\n补建最小主 PRD"];
    stop_no_spec [label="停：需要已批准 Spec\n建议补传或回上游"];
    stop_invalid [label="停：回上游修订 Spec"];
    
    start -> read_spec [label="spec.md"];
    start -> stop_no_spec [label="PRD.md / pages/*.md\n或自然语言"];
    read_spec -> check_mode;
    check_mode -> greenfield [label="greenfield"];
    check_mode -> iterate [label="iterate"];
    check_mode -> brownfield [label="brownfield"];
    check_mode -> stop_invalid [label="有阻塞未决项\n或范围不闭合"];
}
```

### 统一主干工序

三种模式都走这条主干，但 Phase 1 动作按模式分化：

| Phase | 做什么 | 边界 | 规范位置 |
|---|---|---|---|
| **1** Spec 读取与复核 | greenfield：价值层级 + 假设审查 + 成功标准 + 四维风险；iterate / brownfield：基线读取 + 章节映射 + 漏项复核 | 缺口阻塞回上游 | 各模式 reference Phase 1 |
| **2** 主 PRD 结构骨架 | greenfield：功能清单 + 页面列表 + 全局导航；iterate：旧 PRD 基线引用 + 涉及页面映射表 | 只含静态结构，不画 mermaid | 各模式 reference Phase 2 |
| **3** 业务流程设计 | 默认单版 mermaid 在对话中确认；用户要求或 Spec「流程设计要求」点名多版时才发散 v{N}.md + compare.md 落盘选型 | 设计「完成核心 Job 的操作路径」，不是 UI 线框；变更不改用户操作路径时整步跳过 | `flow_design.md` |
| **4** 主 PRD 写入方案 | 基于 Spec + Phase 3 选定流程，展示主 PRD 章节写入方案 + 下一步建议，并做 self-review | 不调用下游 | 各模式 reference Phase 4 |
| **4→5** 启动门 | 展示写入方案 + 受影响文件清单，显式批准才进 Phase 5 | 唯一的**启动**批准门（Phase 5 内另有每章节内容确认门） | — |
| **5** 执行落地 | 只写 / 改 `./docs/prd/PRD.md` 点名章节（每章节写入前还有一道内容确认门）并维护 changelog | 不自动调用下游 | 各模式 reference Phase 5 |

**完成后只给下一步建议，不自动续跑下游。**

### Spec 模式字段

Spec 元信息的「模式」字段决定主 PRD 怎么写：

- **greenfield（新需求）**：写首版主 PRD
- **iterate（迭代）**：只改 Spec 点名的主 PRD 章节
- **brownfield（老项目无基线）**：补建最小主 PRD 或改点名章节

模式只认 Spec 元信息字段，**不看「目录里有没有 PRD.md」**。

## 实施细节

各模式 Phase 1-5 的完整展开见对应 mode reference；全模式通用的工作原则见 `references/principles.md`。此处只固定两条最高优先级、任何时候都不许突破的硬红线：

### 两条硬红线

- **只读 Spec、不写 Spec**：craft 全程只消费、不修改 Spec。发现 Spec 有缺口，停下回上游修订，不在 craft 内补写。
- **批准前不落字节**：主 PRD 写入要等 Phase 4→5 启动门显式批准；草稿、占位、「先写着等会改」一律不许提前动笔。

协作节奏与闸门（三拍循环 + 二段语义确认）、Spec 边界与回退、产出纪律（不过度设计 / 增量写入 / 版本追踪）的完整规则，见 `references/principles.md`。

## 常见错误

| 错误 | 后果 | 正确做法 |
|------|------|---------|
| 跳过 Phase 1 直接写 PRD | 价值层级缺失，后续流程图方向偏离核心 Job | 严格按 Phase 顺序，Phase 1 必做价值复核 |
| Spec 缺口时自行补写 | 需求边界漂移，下游按错误边界展开 | 停下，回上游修订 Spec；craft 全程只读 Spec |
| Phase 4→5 启动门前提前写 PRD | 方案未批准就落字节，浪费返工成本 | 等 Phase 4→5 启动门显式批准才进 Phase 5 |
| 多个 Phase 决策打包问 | 用户同时批准多个未对齐方案，偏差叠加放大 | 每个 Phase 单独确认，Phase 1 / 2 走二段语义确认 |
| 流程设计时发现 Spec 缺分支继续硬做 | 流程图基于错误边界，下游原型缺状态 / 缺页 | 暂停，向用户说明矛盾，回上游修订 Spec |
| 没人要求就做多版流程对比 | 选型仪式消耗用户时间，版本间常是伪差异 | 默认单版对话确认；只在用户要求或 Spec 点名时发散，版本数按真实路径数走（见 `flow_design.md`） |
| 主 PRD 阶段写技术选型 / 数据库字段 | 越界进入技术设计，与下游页面设计职责重叠 | 主 PRD 只聚焦产品定位、结构、流程、页面索引 |
| 入参是自然语言想法直接开始 craft | 无 Spec 边界，craft 越权定义需求范围 | 停，建议回上游 `/lon-req-discovery [需求描述]` |

## 资源

| 文件 | 关键用途 |
|------|---------|
| `references/principles.md` | 工作原则详解（协作节奏 / Spec 边界 / 产出纪律） |
| `references/mode_branching.md` | Phase 0 Spec 输入分流细则 + 输入校验清单 |
| `references/greenfield-mode.md` | greenfield 主 PRD 产品设计规范 |
| `references/iterate-mode.md` | iterate 主 PRD 产品设计规范 |
| `references/brownfield-mode.md` | brownfield 主 PRD 产品设计规范 |
| `references/flow_design.md` | Phase 3 业务流程契约（单版默认 / 多版触发条件、跳过条件、差异化维度、流入主 PRD、Codex confirmation 选项） |
| `../lon-req-discovery/references/spec_template.md` | 上游 Spec 结构参考（归 lon-req-discovery）；craft 只读校验，不写入 |
| `references/prd_template.md` | Phase 5 写主 PRD 时参照，章节结构以此为准 |
| `references/navigation_patterns.md` | Phase 2 选全局导航时按平台类型查阅 |
| `references/changelog_format.md` | 每个被修改文件底部 changelog 表格式 |
