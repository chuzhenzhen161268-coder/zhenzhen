# 老项目无基线迭代模式 (brownfield) 详细规范

> craft 在 Spec 元信息「模式」字段为 brownfield 时进入。**本质：iterate 的冷启动变体。**
>
> 老项目没用 craft 建过 PRD，craft 读不到任何工程历史。缺的现状上下文（截图 / 线上页面 / 背景口述）已由上游在需求分析阶段重建成局部基线，连同本次变更范围一起写进 Spec——craft 读 Spec 即可，不重复访谈。
>
> 与 iterate 唯一的差异在 **Phase 5**：涉及的 PRD 文件多半还不存在，需按需补建最小主 PRD。其余 Phase 全部复用 `iterate-mode.md`，本文只写差异。

---

## 核心心智模型

**brownfield = 老项目无 craft 基线 + Spec 已由 discovery 从现状重建并定义 + craft 按 iterate 处理、Phase 5 按需补建**

老项目是真实在跑的产品，但没有用 craft 建过 PRD，craft 读不到任何工程历史。缺的现状上下文（截图 / 现有页面 / 背景）由 `lon-req-discovery` 在需求分析阶段主动访谈 + 重建局部基线，连同本次变更范围一起落进 Spec。craft 拿到的就是这份已含重建基线的 Spec——和 iterate 一样信任 Spec、不重新采集，唯一不同是涉及的 PRD 文件多半还不存在，需在 Phase 5 按需补建。

**关键原则：按需补建，不补全。** 不借这次迭代把整个老产品的 PRD 补全——那是另一件事。只把本次变更涉及的页面 / 章节纳入 craft 体系，碰到哪补哪。

| 维度 | iterate（体系内迭代） | brownfield（老项目无基线） |
|---|---|---|
| 基线来源 | 读 `./docs/prd/PRD.md` + `pages/*.md` | 读 Spec（discovery 已从现状重建局部基线写入其中） |
| 涉及页面的 PRD | 已存在，直接改 | 多半不存在 → Phase 5 按需补建 |
| 其余流程 | —— | 全部复用 iterate |

---

## 模式判定规则

由 SKILL.md Phase 0 读 Spec 元信息「模式」字段判定（brownfield）。craft 不重判、不从截图或自然语言反推——现状重建是 `lon-req-discovery` 的职责，craft 入参统一是已批准 Spec 文件。

---

## Phase 1 / 2 / 3 / 4 / 启动 gate

全部复用 `iterate-mode.md` 对应章节。基线读取直接读 Spec（含 discovery 重建的局部基线），不再自行访谈重建。Spec 的「改/写的范围」里，把"按需补建的页面"标为「新建」、已 craft 化的页标「修改」，页面 PRD 产出者统一标 **lon-page-design**。craft 不碰 `pages/*.md`，只在收尾给下一步建议。涉及页的现状细节由 lon-page-design 在细化页 PRD 时按 Spec 定位 + 用户截图处理，不在 craft 主 PRD 层展开。

---

## Phase 5：执行落地

复用 `iterate-mode.md § Phase 5`，差异在「涉及文件不存在时按需补建」：

1. **主 PRD 不存在** → 先创建一个**最小主 PRD** `./docs/prd/PRD.md`（参照 `prd_template.md`，只填本次涉及的部分：元信息 + 涉及功能 + 涉及页面索引 + 选定流程；不为没碰的老功能补内容）。
2. **涉及页面无 PRD 文件** → 在总结里建议下一步交给 `lon-page-design` 新建页面 PRD。
3. **涉及页面已 craft 化** → 在总结里建议下一步交给 `lon-page-design` 迭代更新既有页。
4. changelog / 索引更新 / 下一步建议：同 iterate。

> 执行完成后，本次碰到的部分就纳入了 craft 体系，下次再迭代这些页就走迭代模式了。

---

## 与其他文档的关系

> **同步契约**：本文档对 `iterate-mode.md` 全面「复用」。若改动 `iterate-mode.md` 的 Phase 1-5，必须手动检查本文档是否需要同步，以免行为漂移。

| 文档 | 关系 |
|---|---|
| `iterate-mode.md` | Phase 1 / 2 / 3 / 4 / 5 全面复用，本文只写 Phase 5 按需补建这一处差异 |
| `../../lon-req-discovery/references/spec_template.md` | 输入 Spec 结构参考（归 lon-req-discovery）；craft 只读和校验。brownfield 的局部基线重建由 discovery 完成并写入 Spec |
| `prd_template.md` | Phase 5 创建最小主 PRD 时参照 |
| `changelog_format.md` | Phase 5 追加 changelog 时参照 |
