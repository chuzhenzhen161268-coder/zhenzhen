# 模式分流规则

> craft 的 Phase 0 只接受已批准 Spec。Spec 由 `lon-req-discovery` 产出；craft 不从自然语言、PRD.md 或页面 PRD 直接起草需求。

## 三种模式中英对照

| Spec 模式 | reference 文件 | craft 处理 |
|---|---|---|
| 新需求 / greenfield | `greenfield-mode.md` | 基于 Spec 写首版主 PRD，并建议下一步进入页面 PRD |
| 迭代 / iterate | `iterate-mode.md` | 基于 Spec 改主 PRD 点名章节，并建议下一步进入页面 PRD / 原型 |
| 老项目无基线 / brownfield | `brownfield-mode.md` | 基于 Spec 补建最小主 PRD 或改主 PRD 点名章节 |

## 判定优先级

1. **入参是 `./docs/specs/*-spec.md` 且文件存在**
   - 读取 Spec 元信息中的「模式」字段。
   - 模式是新需求 / greenfield → 使用 `greenfield-mode.md`。
   - 模式是迭代 / iterate → 使用 `iterate-mode.md`。
   - 模式是老项目无基线 / brownfield → 使用 `brownfield-mode.md`。
   - 模式缺失或无法识别 → 停止，建议下一步回 `lon-req-discovery` 修订 Spec。

2. **入参是自然语言、截图、产品想法、变更请求**
   - craft 不处理。
   - 建议下一步：`/lon-req-discovery [需求描述]`。

3. **入参是 `PRD.md` 或 `pages/*.md`**
   - craft 不直接从 PRD 文档反推需求范围。
   - 若用户已有 Spec，要求补传 Spec 路径。
   - 若没有 Spec，建议下一步：`/lon-req-discovery [需求描述或 PRD 路径]`。

## Spec 输入校验

进入任一模式前，Spec 必须具备：

- 需求背景：目标用户、要解决的问题、竞品差异 / 品类惯例、AI 能力边界（后两项不适用时须写明「不适用」及原因）。
- 逻辑补齐摘要：主路径、关键分支、状态/异常、跨页影响。
- PRD 文件清单：主 PRD 与页面 PRD 的操作类型、产出者、章节范围。
- 原型文件清单：后续 proto-builder work-list。
- 不在本次范围内：相邻但不动的页面、模块、章节、原型。
- 验收标准：能判断本期是否完成。

缺任一项时，不在 craft 内补写 Spec；停止并建议回 `lon-req-discovery` 修订。

## 模式下的 Phase 5 差异

| 操作 | 新需求 | 迭代 | 老项目无基线 |
|---|---|---|---|
| 主 PRD | 新建 `./docs/prd/PRD.md` | 只改 Spec 点名章节 | 无主 PRD 时建最小主 PRD |
| 页面 PRD | 不写，只建议 `/lon-page-design ./docs/prd/PRD.md` | 不写，只建议 `/lon-page-design ./docs/specs/{...}-spec.md` | 不写，只建议下一步交给 `lon-page-design` |
| 原型 | 不生成，只建议页面 PRD 完成后进入 `lon-proto-builder` | 不生成，只建议页面 PRD 完成后进入 `lon-proto-builder` | 同迭代 |
| changelog | craft 维护主 PRD 初始记录 | craft 只维护主 PRD 本次记录 | craft 只维护主 PRD 本次记录 |

正文写入方式：直接覆盖写新内容，不打 `<!-- +v -->` / `<!-- -v -->` 类内联版本标记；行级 diff 交 git。
