# 产品全局 Skill 包

## 使用方式

1. 解压本压缩包。
2. 将 8 个 Skill 文件夹复制到个人 Codex Skills 目录。
3. 新开对话后，优先输入：`使用 pm-workflow，帮我判断这个需求该从哪里开始。`

## 包含的 Skill

- `pm-workflow`：产品工作流总入口。
- `lon-req-discovery`：需求分析与 Spec。
- `lon-prd-craft`：主 PRD。
- `lon-page-design`：页面 PRD 与线框。
- `lon-proto-builder`：可点击 HTML 原型。
- `lon-proto-canvas`：原型评审画布。
- `lon-req-clarify`：研发澄清 PRD、验收与埋点。
- `lon-product-delivery`：可分享交付包与交付中心。

## 埋点规则

- 事件名称：`ismp页面浏览`、`ismp功能点击`、`ismp页面曝光`。
- `event_name`：`ismp_view`、`ismp_click`、`ismp_show`。
- 每条事件均携带 `platform`，按实际平台上报。
- 使用“页面 > 模块 > 按钮”层级的标准埋点明细表。
