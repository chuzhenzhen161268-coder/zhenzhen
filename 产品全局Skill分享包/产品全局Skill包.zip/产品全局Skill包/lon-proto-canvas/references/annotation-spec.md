# 标注交互 + 持久化规范

本文档定义画布上"自由位置打标 + 富文本备注 + 数字编号"的行为契约，是 `canvas-template.html` 中标注相关 JS 的真理源；修改这些交互时同步此文。

## 1. 数据模型

### 1.1 单条标注

```json
{
  "id": "ann-{YYYYMMDD}-{HHMMSS}-{6位随机}",
  "number": 1,
  "createdAt": "ISO8601",
  "updatedAt": "ISO8601",
  "anchor": {
    "kind": "frame" | "canvas",
    "instanceId": "fi-a3k9x2",
    "pageId": "01-music-detail",
    "frameKind": "state" | "overlay",
    "frameKey": "upcoming-unbooked",
    "x": 0.42,
    "y": 0.65
  },
  "html": "..."
}
```

- `kind: "frame"` → `instanceId` 是渲染宿主，定位画布上具体哪一个 frame 实例（同一 frameKey 可以有多个实例，各自独立打标）；`pageId` / `frameKind` / `frameKey` 冗余保留，供孤儿重新挂载时筛选候选实例；`x/y` 是 frame 内归一化坐标（0-1）
- `kind: "canvas"` → 只填 `x/y`（画布绝对像素，基于 100% 缩放），不受任何 frame 变动影响
- 缺 `instanceId` 的标注：渲染时退回按 `pageId + frameKind + frameKey` 查找画布上第一个匹配的 frame；`build_canvas.py` 每次构建都会尝试按 `pageId + frameKey` 匹配 `layout.json` 里第一个同 key 实例补齐 `instanceId`，匹配不到的转入孤儿判定（详见 `references/output-contract.md`「标注宿主绑定」）
- `html` → 标注正文，白名单富文本 HTML（经 `sanitizeAnnotationHtml` 消毒），非 markdown

### 1.2 文件结构

```json
{
  "version": "1",
  "annotations": [...],
  "orphans": [...]
}
```

`orphans[]` 每条额外含 `lostReason` + `lostAt`。

## 2. 编号规则

- 全局递增，按 `createdAt` 顺序
- 删除某条 **不重排**
- 新增标注的 `number` = `max(所有 annotations + orphans 的 number) + 1`
- 孤儿标注保留原 `number`，重新挂载后不变

## 3. 模式与工具状态机

画布同时维护两套正交状态：`state.mode` 是标注子系统专用（打标 / 重新挂载），`state.tool` 是画布工具（指针 / 平移 / 图形）。二者互不覆盖，但切换任一方都会先退出另一方与 picker，保持画布任意时刻只有一种「点画布」语义生效。

### 3.1 `state.mode`（标注子系统，3 个互斥值）

| 模式 | 触发 | 光标 | 点击行为 |
|------|------|------|---------|
| 浏览（默认） | 默认 | 默认 | 点图钉 → 展开卡片 |
| 打标 | 工具栏「注释」 | 气泡图标（`--accent` 色） | 点画布 → 新建标注 |
| 重新挂载 | 孤儿抽屉点 `[重新挂载]` | 十字 | 点画布 → 给目标孤儿生成新 anchor |

### 3.2 `state.tool`（画布工具，与 mode 正交）

| 工具 | 快捷键 | 说明 |
|------|--------|------|
| 选择（默认） | V | 拖 frame 实例改坐标、选中 |
| 平移 | H / 空格 | 拖动画布视口（Figma 手型） |
| 方框 / 箭头 / 便签 / 文字 | R / A / N / T | 互斥单选，画完自动回选择工具；图形对象存 `layout.json` 的 `shapes[]` |
| 流程图 | F | 流程图节点，形状由面板选择 |

字母快捷键经 `isTyping()` 守卫：焦点在输入框 / `contenteditable` 时不触发。`isTyping()` 对任意 `contenteditable` 元素返回 true，标注编辑卡的 `.ann-body` 打开即自动聚焦也在此列——这正是下面 ESC 优先级链要把「打开的标注卡片」单独判定、不能用 `isTyping()` 兜底的原因。

另有「选元素」(picker) iframe 内取元素工具，是独立于 mode / tool 之外的第三套开关：点工具栏「选元素」按钮切换，开启时与打标模式互斥（开启 picker 会关掉打标模式，并把 `tool` 归位到选择，避免点卡片进 iframe 拾元素、点空白却画出一个图形）；切 `tool` 或进入打标 / 重新挂载模式会反向关掉 picker。picker 不在下方 ESC 优先级链内，关闭它靠再次点按钮或触发其他互斥项。

### 3.3 ESC 优先级链

ESC 优先级链，自上而下命中即停：

1. 正在编辑的图形文本 — 提交内容并退出编辑，保持当前工具
2. mark / remount 模式 — 退出该模式回浏览
3. 打开的标注卡片 — 关闭卡片
4. 添加面板 / 孤儿抽屉 — 关闭
5. 非选择工具 — 回 select

第 1 级的判定条件是 `state.editingShapeId` 这个图形文本编辑态的专有标志，不使用 `isTyping()`：后者对任意 `contenteditable` 返回 true，而标注编辑卡的 `.ann-body` 正是 contenteditable 且打开即自动聚焦，用它作条件会让编辑标注时的 ESC 停在第 1 级，吃掉第 3 级「按 ESC 丢弃并关闭编辑卡」这条契约。

### 3.4 撤销 / 重做

撤销的对象是内容：`frames` / `shapes` / `annotations` / `orphans` 四个数组。缩放、主题、锁定、分屏宽度是视图偏好，不入栈。

实现挂在 `writeLayout()` / `writeAnnotations()` 两个 writer 上（不挂传输层 `persist`）：每次 writer 调用后经微任务取一份快照，快照是四条 JSON 串（`f / s / a / o`），恢复时 `JSON.parse` 出新对象，栈里的历史不会被后续原地修改污染。同一同步调用栈里的多次写合并成一步，与用户的一次操作对应。快照与当前 `present` 全同则不占一步。新建标注时先落盘的空钉不入栈（`withoutHistory`），编辑卡关闭时同步入栈，一条标注从新建到写完正文是一步。上限 100 步或 8MB，超出丢最旧。

撤销 / 重做的执行序固定：`settleEditing()`（提交进行中的图形文本 / 箭头标签 / 标注编辑卡，退出打标 / 重挂模式）→ 同步 `historyFlush()`（把刚提交的那笔压栈）→ 出入栈 → `restoreSnapshot()`。恢复按四条串与恢复前的差异分层重渲染，frame 只是挪了位置时原地改坐标、不重建卡片；顺序固定 frames → shapes → pins。恢复后不跑孤儿归位：快照四数组是同一时刻拍的，彼此自洽。

快捷键：`Cmd/Ctrl+Z` 撤销，`Cmd/Ctrl+Shift+Z` 与 `Ctrl+Y` 重做。字母由 `shortcutLetter()` 判定：键帽是拉丁字母时按 `e.key`（AZERTY 上 Z 键的 `e.code` 是 KeyW），否则退回 `e.code` 物理键位（西里尔等布局）。`isTyping()` 为真时不拦截，交给浏览器原生文本撤销；`state.locked` 为真或有拖拽手势进行中时不动作。焦点在原型 iframe 内时 keydown 不冒泡到画布文档，快捷键无效，与其它画布快捷键同一限制。

## 4. 光标实现

进入打标模式时，把 `document.body` 的光标换成模板里硬编码的 `COMMENT_SVG` 自定义光标（实心评论气泡，填色取主题强调色 `--accent`）。光标 SVG 字符串与挂载时机以 `canvas-template.html` 的 `COMMENT_SVG` 常量 + `enterMarkMode()` 为准，本文不复刻具体取值以免漂移。

## 5. 落点判定

点击事件处理：

```
1. 拿到 e.clientX / e.clientY
2. 减去画布平移量、除以缩放因子 → 画布坐标 (cx, cy)
3. 遍历所有渲染中的 frame DOM，用 getBoundingClientRect 转画布坐标系
4. 检查 (cx, cy) 是否落在某个 frame box 内：
   - 是 → anchor.kind="frame"，记录 frame 信息（含 instanceId，即命中的具体 frame 实例）+ (x/w, y/h) 归一化
   - 否 → anchor.kind="canvas"，记录 (cx, cy)
```

## 6. 图钉渲染

每个标注在 `pinLayer` 内渲染为一个绝对定位的小气泡（DOM 结构 `.pin > .pin-bubble`，气泡内是编号数字）。外观（尺寸 / 背景 / 字号）由模板 `.pin` / `.pin-bubble` CSS 决定，背景取主题强调色 `--accent`；具体结构以 `refreshPins()` 为准，本文不复刻视觉值以免漂移。

定位（稳定契约）：

- frame 标注优先按 `anchor.instanceId` 精确匹配同一 frameKey 下的具体实例；缺失 instanceId 的标注退回按 `pageId + frameKind + frameKey` 匹配画布上第一个渲染中的实例
- frame 标注的 left/top = `frame.left + x * frame.width`，`frame.top + y * frame.height`
- canvas 标注的 left/top = `x`, `y`（画布坐标系，画布容器是 position:relative）
- 缩放/平移画布时，所有 pin 跟着画布走（pin 是画布容器的子节点）

## 7. 编辑卡片

新建 / 编辑标注时弹出卡片，结构：

```
┌─────────────────────────┐
│ #1                  [×] │
├─────────────────────────┤
│ 自制工具栏（见下）      │
├─────────────────────────┤
│ <contenteditable 编辑区>│
│                         │
├─────────────────────────┤
│      [取消]  [确认]     │
└─────────────────────────┘
```

- 编辑器：一个 `contenteditable` 富文本区 `.ann-body` + `document.execCommand`，零第三方依赖
- 工具栏按钮（`.ann-toolbar`）：
  - 加粗 / 斜体 / 下划线 → `execCommand('bold' | 'italic' | 'underline')`
  - H1 / H2 / H3 / 正文¶ → `execCommand('formatBlock', false, 'H1' | 'H2' | 'H3' | 'P')`
  - 有序 / 无序列表 → `execCommand('insertOrderedList' | 'insertUnorderedList')`
  - 文字颜色 → 六色调色板（黑 / 灰 / 红 / 橙 / 绿 / 蓝），`execCommand('foreColor', false, <hex>)`
- 选区保存：工具栏 `mousedown` 时 `preventDefault`（防编辑区失焦丢选区）；`keyup` / `mouseup` 存 `savedRange`，点按钮前 `restoreRange()` 复位，`execCommand` 才作用在原选区
- active 态：`queryCommandState(cmd)` 回填按钮 `aria-pressed`
- 粘贴清洗：拦 `paste`，统一 `execCommand('insertText', 纯文本)` 降级，丢弃外站富文本的 inline style / 外链
- 数据契约：读 `ann.html` 灌进 `body.innerHTML`；存 `body.innerHTML` → `sanitizeAnnotationHtml()` → `ann.html`。标注正文是 HTML 字符串，非 markdown
- 空文本提交 = 删除该标注（不留空钉）；`_commitEdit` 用 `committed` 标志防重入，「确认」与点卡片外空白共用
- 卡片定位：`positionCardNearPin()` 紧贴气泡右下，超视口边缘反向（左上）
- 查看卡（`openAnnotationViewCard`，含 lock 只读态）：直接把 `sanitizeAnnotationHtml(ann.html)` 注入 `.ann-preview-body`，不起编辑实例；lock 态隐藏编辑 / 删除按钮

### 7.1 HTML 消毒（sanitizeAnnotationHtml）

写入（`_commitEdit`）与读取（初始填充、查看卡预览）都过一遍，防止粘贴 / 导入的 HTML 夹带可执行片段：

- 允许标签：`B STRONG I EM U OL UL LI FONT SPAN BR P DIV H1 H2 H3`
- 危险标签直接删：`SCRIPT STYLE IFRAME OBJECT EMBED LINK META BASE FORM INPUT TEXTAREA IMG SVG MATH A`
- 其余非白名单标签：拆掉外壳、保留文本与子节点
- 属性一律清除，仅放行 `FONT` 的 `color`（`foreColor` 产物）与 `SPAN` 的 `style` 中 `color` 一项

## 8. 持久化

文件是唯一真理：`annotations.json`（标注）与 `layout.json`（编排）是画布状态的全部；浏览器 localStorage 只存主题与分屏偏好，不承载任何标注或编排数据。

### 8.1 读路径

启动时 `loadDataFile(name)`：`http(s)` 下 `fetch(name + ".json", {cache: "no-store"})`；`file://` 或 fetch 失败时动态插入 `<script src="name.js">` 读 `window.__CANVAS_DATA__[name]`。镜像与 json 由服务端 / 生成器同一函数写出，内容一致。`pages` 加载失败整页显示致命错误；`annotations` / `layout` 失败按空处理。

### 8.2 写路径（服务模式）

启动时与数据加载并行 `POST /api/canvas/probe`：响应体自报 `ok: true` 才进服务模式，否则进静态模式；探测结束前不绑定交互。判据落在响应体而非 HTTP 状态，因为静态托管对未知路径也可能回 2xx（SPA 兜底 / 自定义错误页配 200 / 反代兜底）。

`persist(kind, payload)` 是唯一写入口，`kind` 为 `annotations` / `layout`：

- 每种只保留最新一份待发 payload，按种类串行 `PUT`，拖拽中的连续写自然合并且不会乱序
- `PUT /api/canvas/annotations` payload `{version, annotations, orphans}`；`PUT /api/canvas/layout` payload `{version, frames, shapes}`；`updatedAt` 由服务端盖
- 落盘成功的判据是响应体 `ok: true`，同 probe；5xx / 网络错误回填待发并 3 秒后重试，4xx 只回填不重试（同一份 payload 过不了校验，重发多少次都一样），等下一次编辑带着新 payload 触发
- 保存状态常驻工具栏（`#saveState`：已保存 / 保存中 / 保存失败重试中）
- 有待发或在途请求时 `beforeunload` 拦截一次

### 8.3 静态模式

无写 API（任意静态托管、`file://`、纯静态服务）时：顶部弹出「静态副本」横幅（可关闭，工具栏 `#saveState` 的「静态副本」是常驻提示），改动只在内存，导出徽标随 `dirty` 点亮，离开前拦截一次。贴图被拦下并提示。

### 8.4 导出 / 导入

「导出」产出 `canvas-state.json`：

```json
{ "version": "1", "generatedAt": "ISO8601", "annotations": [], "orphans": [], "frames": [], "shapes": [] }
```

「导入」读同格式文件，把四个数组整体替换掉，不做按 id 合并：导出文件是画布内容的整份快照，导入就是把画布换成那一份。

入口两条，都落到同一个导入弹窗（`#importModal`）：工具栏「导入」按钮，或把 `.json` 拖进画布空白处（画布的 `drop` 对任何 Files 一律 `preventDefault`，认不认得都不能让浏览器把它当导航目标打开）。弹窗内拖入或点选文件后：

- `analyzeImport(text, fileName)` 解析并清洗——每个数组滤掉非对象与缺 `id` 的条目，覆盖式没有第二道关口，脏数据进了 `state` 就直接落盘；四个键一个数组都没有则判为不是画布状态，报错留在弹窗里可重选，不弹 `alert`
- 同时与本站点 `pages` 对账：`deadInstanceIds(frames, pages)` 挑出 `findFrameMetaIn` 查不到、因而 `renderFrameInstance` 画不出来的实例；`danglingArrowEnds(shapes, frames)` 挑出端点宿主不在这份数据里的箭头
- 报告展示四类内容的「当前 → 导入后」条数、`generatedAt`、覆盖语义与可撤销提示，以及上面两项对账结果（为零则不渲染）；静态模式追加一行「只在内存、刷新即丢」
- 确认后 `applyImport()` 落地：整体替换 → 清图形选中 / 编辑态 → `repairDanglingArrows()`（有一端还活着就把悬空端贴着它放，两端都悬空的整条丢弃）→ 孤儿归位（第 9 节）→ 落盘

锁定态下 `applyImport()` 直接早退，按钮本身也带 `data-lock-disable`。误导入按 `Cmd/Ctrl+Z` 整体撤回：两个 writer 的快照在同一调用栈里合并成一步。

启动时 `rescueLegacyLocalStorage()` 扫一遍本机 localStorage 里前缀为 `proto-canvas:annotations:` / `proto-canvas:layout:` 的键：旧版画布在没有写 API 时把标注与编排存在这里，那些数据只在评审者自己的浏览器里。按键名后缀分组，凑齐上面的导出格式，确认后每组下载一个 `legacy-canvas-state-<后缀>.json` 并清除该组的键；取消则原样保留，下次打开再问。解析不了的键一律不删。拿到的文件走「导入」归位。

### 8.5 剪贴板

`Cmd/Ctrl+C` 把选中的卡片实例与图形写进剪贴板，`Cmd/Ctrl+V` 粘贴。载荷同时进内存（`state.clipboard`）与系统剪贴板：

```json
{ "__protoCanvas": "clip/1", "frames": [], "shapes": [], "origin": { "x": 0, "y": 0 } }
```

- `origin` 是复制时整组包围盒的中心。粘贴位移 = 落点 − `origin`，落点取鼠标在画布内的位置、不在则取视口中心；鼠标不动连粘几次时每份再让开一档，免得严丝合缝叠在一起
- 写系统剪贴板是尽力而为（`file://` 与非 secure context 下没有 `navigator.clipboard`），失败静默、内存那份兜底。`__protoCanvas` 签名用来把画布对象与用户从别处复制的普通文字区分开
- 标注不进剪贴板：它带全局编号、是评审意见，副本不该再带一份重复的
- `cloneCanvasObjects()` 换新 id（与画布现有 id 去重）并整组平移，非坐标字段整体深拷贝跟随。箭头端点按宿主在不在这组里分流：在组里就改挂副本，不在组里则就地求出画布坐标、降级成自由端（保留锚定会让副本牵回原件）
- 粘贴前用 `deadInstanceIds(frames, pages)` 与本站点 `pages` 对账，画不出来的卡片丢弃并提示条数
- `paste` 事件三级分流：剪贴板里的图片文件 → 带签名的 JSON（别的标签页复制走的）→ 内存那份
- 复制只读、锁定态照常可用；粘贴要写数据，锁定态早退。整次粘贴经一次 `writeLayout()` 合成一步撤销

## 9. 孤儿处理

### 9.1 触发时机

| 触发 | 处理 |
|------|------|
| 用户在添加面板点 `✕` 移除某个 frame 实例 | 该实例上的标注（按 `anchor.instanceId` 匹配）立即迁入 `orphans[]`，保留全局编号与内容（画布端 `removeFrameInstance()`） |
| `pages.json` 中 frameKey 消失（页面或状态被删，下次重跑 `build_canvas.py` 检测到） | 该 frameKey 在 `layout.json` 中的所有实例一并移除，其上标注全部迁入 `orphans[]`（`scripts/layout.py::orphan_by_missing_instance`，每次构建都会跑一遍；`update-page` / `merge` 模式下 `handle_orphans` 先在 pages.json 层面做同一件事） |
| 孤儿重新挂载 | 在孤儿抽屉点 `[重新挂载]` → 点画布任意位置生成新 anchor（含新 instanceId），移出 `orphans[]`（见 9.3） |

判定依据是 `pages.json`（扫描结果）与 `layout.json`（画布上还有哪些实例），与用户对画布做过的拖动等操作无关。每条孤儿加 `lostReason` + `lostAt`。

### 9.2 孤儿抽屉 UI

- 工具栏 `[孤儿(N)]` 按钮仅在 `orphans.length > 0` 时显示
- 点击展开侧抽屉，列出每条孤儿：编号 + 正文摘要（`ann.html` 取纯文本前 80 字）+ lostReason + `[重新挂载] [删除]`

### 9.3 重新挂载流程

1. 点 `[重新挂载]` → 切入"重新挂载模式"，记住目标孤儿 id
2. 用户点画布任意位置 → 按 Section 5 落点判定生成新 anchor
3. 覆盖孤儿的 anchor，从 `orphans[]` 移回 `annotations[]`，移除 lostReason / lostAt
4. ESC 或工具栏 `[取消]` 退出模式
