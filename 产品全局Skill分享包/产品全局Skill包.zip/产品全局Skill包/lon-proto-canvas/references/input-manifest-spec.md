# 输入 Manifest 规范

本文档定义 `build_canvas.py` 扫描器期望的 canvas-manifest 块结构。

## Manifest 块格式

每个原型 HTML 应嵌入 canvas-manifest 块（由 lon-proto-builder 生成时自动写入）：

```html
<script type="application/canvas-manifest" data-version="1.0">
{
  "version": "1.0",
  "page": { 
    "name": "登录页", 
    "order": 1, 
    "id": "login-page"
  },
  "frames": [
    { 
      "key": "main", 
      "kind": "state", 
      "label": "默认态", 
      "tag": "default" 
    },
    { 
      "key": "error", 
      "kind": "state", 
      "label": "错误态", 
      "tag": "error" 
    },
    { 
      "key": "modal-forgot", 
      "kind": "overlay", 
      "overlayType": "modal", 
      "label": "忘记密码弹窗",
      "triggers": [
        { 
          "fromStateKey": "main", 
          "action": "点击「忘记密码」链接" 
        }
      ]
    }
  ]
}
</script>
```

## 字段说明

### page 对象

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| name | string | ✓ | 页面中文名 |
| order | number | ✓ | 排序序号（决定画布中的显示顺序） |
| id | string | - | 稳定 ID（用于跨次生成锚定，可选） |
| viewport | string \| object | - | 视口档位，决定该页 frame 在画布上按多宽渲染；不写则自动嗅探（见下） |

#### page.viewport

iframe 宽度就是原型内部的 CSS 视口宽度，`<meta name="viewport">` 在 iframe 里不生效——中台这类宽屏原型必须让画布知道真实宽度，否则会被按手机断点重排。

两种写法：

```jsonc
"viewport": "desktop"                          // 档位名：mobile(375x812) / desktop(1280x800)
"viewport": { "width": 1440, "height": 900 }   // 显式尺寸
"viewport": { "profile": "desktop", "width": 1440 }  // 档位打底 + 覆盖单项
```

**通常不用写**：扫描器会嗅探源 HTML 的 `<meta name="viewport" content="width=1280">`，lon-proto-builder 中台模式产出的骨架自带这行。只有在 meta 与画布期望不一致时才显式声明。

`height` 是高度下限而非固定高：state frame 按 iframe 回报的真实内容高撑开，overlay frame 固定按此高展示。完整回退顺序见 `scan-rules.md` §1.1。

### frames 数组

每个 frame 对象：

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| key | string | ✓ | 唯一标识（同一页内不重复） |
| kind | string | ✓ | `"state"` 或 `"overlay"` |
| label | string | ✓ | 显示名称 |
| tag | string | - | 标签（如 `"default"` / `"error"` / `"loading"`） |
| overlayType | string | - | 浮层类型（`"modal"` / `"drawer"` / `"toast"` / `"dropdown"`），kind=overlay 时必需 |
| triggers | array | - | 触发关系数组，kind=overlay 时建议提供 |

### triggers 数组

每个 trigger 对象：

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| fromStateKey | string | ✓ | 从哪个状态触发 |
| action | string | ✓ | 触发操作描述（如"点击 X 按钮"） |

## 扫描器行为

扫描器只读 manifest 块的元数据：
- `key` / `label` / `kind` / `tag` / `triggers` / `overlayType`
- page 级另读 `name` / `order` / `id` / `viewport`
- **不读 DOM**：视觉还原 100% 由 iframe 负责（唯一例外是 `viewport` 缺省时嗅探 `<meta name="viewport">`，只取一个数字，不碰结构）

缺失或损坏的 manifest：
- 脚本输出 warning 并跳过该页
- 手工补 manifest 参见 `scan-rules.md`
