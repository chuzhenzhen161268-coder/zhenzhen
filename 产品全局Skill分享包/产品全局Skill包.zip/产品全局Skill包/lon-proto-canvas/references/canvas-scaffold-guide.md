# 画布产物装配指南

本文档定义 `build_canvas.py` 把扫描结果（pages）、标注（annotations）、编排（layout）装配成站点产物的步骤。

画布渲染由 iframe 自己负责（src 指向 `<sourceFile>?canvasMode=1#<frameKey>`）：壳不合并源样式、不做 fixed / sticky / vh 复位——视觉还原全部由 iframe 内的 canvasMode bootstrap + 原 HTML 自身的 CSS 完成。

## 1. 产物清单

| 文件 | 来源 | 说明 |
|---|---|---|
| `index.html` | `references/canvas-template.html` 原样拷贝 | 壳，零占位符 |
| `assets/canvas.css` / `assets/canvas.js` | `references/canvas.css` / `canvas.js` 拷贝，每次覆盖 | 画布样式与逻辑；skill 里的版本是唯一源 |
| `pages.json` + `pages.js` | 扫描结果 | 顶层含 `project`（站点父目录名）、`initialPage`（order 最小且非 missing 的 page id）、`demoEntry`（见 §1.1） |
| `annotations.json` + `annotations.js` | 合并 / 孤儿迁移后的标注 | 服务端 PUT 时也会重写 |
| `layout.json` + `layout.js` | `layout.py::build_layout` | 同上 |
| `canvas_server.py` | `scripts/canvas_server.py` 拷贝 | 本地写服务，启动器按相对路径引用；发布时由 `export_site.py` 剔除 |

`*.js` 镜像由 `canvas_server.write_json_with_mirror()` 与 json 同一函数写出，格式：

```js
window.__CANVAS_DATA__ = window.__CANVAS_DATA__ || {};
window.__CANVAS_DATA__["annotations"] = {...};
```

前端 http(s) 下 `fetch` json，`file://` 下改走 `<script src="*.js">`；两者内容一致。

### 1.1 `demoEntry` 的解析规则

| 输出目录里存在 | `demoEntry` | 前端渲染 |
|---|---|---|
| `demo/demo.html` | `"demo/demo.html"` | 切换条「演示」 |
| 没有 | `null` | 不渲染切换条 |

演示壳两种平台同路径（APP 是手机框壳，中台是页面索引页），解析只认这一条。演示链接 `target="_blank" rel="noopener"`：画布的缩放 / 滚动位置 / 未提交的标注草稿只活在当前标签页。

## 2. 装配步骤（`build_canvas.py::main`）

1. 读 `pages.json` / `annotations.json` / `hidden.json` / `layout.json`（`_load_json_or_die`：损坏则保留 `.corrupt.{stamp}` 副本并 exit 3，绝不用空值覆盖）
2. 扫描输入、合并页面、迁移孤儿、`layout.py` 生成或合并编排、标注宿主绑定
3. 给每个非 missing 的 page 注入 `sourceFile`（相对输出目录的相对路径）
4. `write_data_files`：三段数据各写 json + js 镜像
5. `write_canvas_shell` / `copy_canvas_assets` / `copy_server_script` / `vendor_assets.ensure_vendor`
6. `sweep_canvas_images` 按 layout 引用清理无人引用的贴图
7. `update_dev_prd_index.write_index` 刷新需求文档清单（+ js 镜像）与各篇 PRD 正文镜像

## 3. 备份

非首次构建时 `pages.json` / `annotations.json` / `layout.json` 先 `cp` 到 `.bak.{YYYYMMDD-HHmmss}` 再写新版；`index.html`、`assets/canvas.*`、`canvas_server.py` 是 skill 文件的拷贝，直接覆盖不备份。

`hidden.json` 是历史遗留的评审隐藏配置：首次构建时其内容被吸收进新生成的 `layout.json`，随后原文件改名归档为 `.retired.{stamp}`，不再参与后续 build。
