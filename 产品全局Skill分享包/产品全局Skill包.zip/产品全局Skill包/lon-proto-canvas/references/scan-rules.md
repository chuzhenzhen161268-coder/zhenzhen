# 源 HTML 扫描规则

本文档定义 `build_canvas.py` 扫描器（`scan_single_html`）的行为契约，SKILL.md workflow Phase 1 由脚本执行。

扫描器**只做 manifest 元数据读取**，不抠 DOM、不合并源样式 —— 画布通过 iframe 直接加载原 HTML，视觉还原 100% 由 iframe 完成。

## 文件夹扫描排除清单

文件夹模式（`new-folder` / `merge`）枚举 `*.html` 时，**强制跳过**以下文件名（不区分大小写）：

| 文件名 | 原因 |
|--------|------|
| `demo.html` | lon-proto-builder 生成的演示壳页，不是 PRD 业务页面 |
| `index.html` | 站点 / 目录的入口页，不是业务原型 |

实现入口：`scripts/build_canvas.py` 顶部常量 `FOLDER_SCAN_EXCLUDE`。新增排除项时统一改这里，不要散落在调用处。

## 0. 扫描流程概览

`scan_single_html(html_path, warnings)` 一次性完成：

1. **读 manifest**：`<script type="application/canvas-manifest">` 块 → JSON.parse；缺失或解析失败 → warning + 跳过该页。
2. **幂等补丁**：确认是原型页之后才调 `patch_prototype.patch_html(html_path)`，注入 canvasMode bootstrap + patch CSS（同版本则跳过）。注入失败 → warning 但继续扫描。
3. **构造 page**：按 manifest 字段映射，不读 DOM。

> 顺序不能反。先补丁再验 manifest，会把目录里的非原型文件也注入一遍 bootstrap——一个几百字节
> 的入口页 / 说明页没有 manifest、也不该进画布，却会被平白撑成 10KB 脏文件。

## 1. Manifest 字段映射

按 `manifest.frames[]` 顺序构造 page 对象（注意：iframe 协议下 frame 字段**不含 html 快照**）：

| manifest 字段 | pages.json 落点 |
|--------------|----------------|
| `frames[].kind === "state"` | 进 `mainStates[]`：`{key, label, tag}` |
| `frames[].kind === "overlay"` | 进 `overlays[]`：`{key, label, kind: overlayType}` |
| `frames[].triggers[]` | 平铺到顶层 `triggers[]`：`{stateKey: fromStateKey, overlayKey: 当前 frame.key, action}` |
| `page.id`（可选） | page.id；缺省时用 filename stem |
| `page.name` | page.name |
| `page.order` | page.order |
| `page.viewport`（可选） | page.viewport；缺省时按 §1.1 嗅探 |

`page.sourceHtml` 由扫描器自动填绝对路径；`page.sourceFile`（相对画布 index.html 的相对路径，给 iframe src 用）由 `build_canvas.py::main` 在写出 `pages.json` 前计算注入。

iframe URL 协议：`<sourceFile>?canvasMode=1#<frameKey>`。

> 扫描器只读 `key` / `label` / `kind` / `tag` / `triggers` / `overlayType`，manifest 里的其余字段一律忽略。

### 1.1 视口档位（page.viewport）

**iframe 的宽度就是原型内部的 CSS 视口宽度**——`<meta name="viewport">` 在 iframe 里不生效。所以画布必须知道每页按多宽渲染，否则 1280 的中台页被塞进 375 的手机壳，会按手机断点重排、固定侧栏吃掉大半宽度、表格横向溢出被 `overflow:hidden` 裁掉。

`resolve_viewport()` 三级回退：

| 优先级 | 来源 | 说明 |
|-------|------|------|
| 1 | manifest `page.viewport` | 档位名字符串（`"mobile"` / `"desktop"`），或 `{profile?, width?, height?}`；width 收敛到 240–4096，height 240–8192，越界或非数字视为未声明 |
| 2 | 源 HTML `<meta name="viewport" content="width=1280">` | 只认数字 width；`device-width` 之类非数字值不算宽屏。width ≥ 700 套 desktop 档高度，否则 mobile 档 |
| 3 | 默认 | `mobile` = 375×812 |

内置档位：`mobile` 375×812、`desktop` 1280×800。

**height 只是高度下限**，不是固定高：
- state frame 仍按 iframe 回报的真实 `scrollHeight` 撑开，下限取该页 `viewport.height`
- overlay frame 固定按 `viewport.height` 展示，不跟随底层 scene 被拉长

落到画布的 `.frame` 上是 inline 的 `--frame-w` / `--frame-h` 两个 CSS 变量 + `data-frame-h`（高度回填读它取下限）。CSS 侧缺省值仍是 375/812，所以 `viewport` 字段出现之前生成的旧 `pages.json` 不重跑也能正常渲染。

**首屏缩放**联动：画布打开时按最宽一页 fit，保证开局至少看得全一整页。APP 原型（375）在任何屏上算下来都 ≥ 1、被 clamp 成 1，行为与加视口档位之前完全一致；中台原型（1280+）在小屏上自动缩到看得全。

> **toast 浮层兜底**：`kind === "overlay"` 且 `overlayType === "toast"` 的 frame 被静默跳过（不进 overlays / 不产生 triggers / 不算 warning）。约定上 toast 不应写进 manifest（参见 `lon-proto-builder/references/canvas-manifest-spec.md` 的「Toast 不进 manifest」），扫描器只是兜底防御。

## 2. canvasMode bootstrap 行为（在 iframe 内执行）

bootstrap 是 `patch_prototype.py` 注入到每个原型 HTML 的「画布模式启动器」，新生成的原型由 lon-proto-builder 起手骨架直接带上。两路保持一致。

激活条件：URL `?canvasMode=1`。检测顺序：

1. 读 `location.hash`，按 `#frame=<key>` 或 `#<key>` 解析 frameKey
2. 读自身 manifest，找 `frames[].key === frameKey` 的 frame：
   - `kind === 'state'` → 调 `window.switchFrame(key, group)`（group = 同 page 所有 state key）
   - `kind === 'overlay'` → 先按 `triggers[0].fromStateKey` 切到对应 state，再调 `window.toggleOverlay(key, true)`
3. 注入 patch CSS（解开 height/overflow 约束）、capture 阶段拦截原生交互（click / submit / 触屏 / 键盘 / 右键等）、wheel 转发给父画布、多次 `postMessage` 回报内容高度（`canvas-frame-ready`）、注册「选元素 picker」桥接。这些行为的完整契约（事件清单、CSS 选择器、回报时机）以 `patch_prototype.py` 的 `BOOTSTRAP_JS` 为单一真理源，见 `pm-skills/CLAUDE.md`「画布 iframe 静态化协议」，本文不复刻细节以免漂移

### 2.1 平铺态冻结与 picker 的分工

画布上的 iframe 是**静态快照，不是可操作页面**，两层配合：

| 层 | 手段 | 拦住什么 |
|----|------|---------|
| 父画布 CSS | `.frame iframe { pointer-events: none }` | hover 高亮、`cursor:pointer`、输入框聚焦、拖拽——鼠标事件根本不进 iframe |
| iframe 内 bootstrap | capture 阶段 `swallow` | 键盘、以及 picker 开启（pointer-events 放行）时的 `<a>` 跳转 / form 提交 |

只靠 bootstrap 拦不够：事件被吞掉了，但视觉仍在响应。中台原型单页就有上百个 `cursor:pointer`
元素和 `hover:` 类，看着完全可点、点下去毫无反馈，是最差的交互组合，所以必须在父层就断掉。

代价是平铺态无法在 iframe 内拖选文字，取原型文案改用「选元素」（它带复制）。

**picker 桥接内置在 bootstrap 里，不由父画布注入**：`file://` 下每个文件是独立 origin，父画布拿到的
`iframe.contentDocument` 恒为 `null`（Chromium 静默失败，不抛错），注入路径必然无效——而评审画布的
常态就是本地双击打开。父画布的 `injectBridge` 保留作 `http://` 同源兜底，两边靠 `window.__pickerBridge`
去重。picker 开启时 inline 设 `pointer-events:auto` 覆盖冻结，关闭时清 inline 回到冻结。

未带 `?canvasMode=1` 时 bootstrap 直接 return，原 HTML 行为不变。

## 3. 浮层激活策略

浮层 frame **完整加载原 HTML + 通过 manifest.triggers 自动切到正确 state + 激活浮层**。视觉效果与原 HTML 在手机里点击触发后完全一致，包括：

- mask 背景（半透明黑层 + blur）
- 模糊的底层 scene 内容
- 浮层主体（modal / sheet / popup / drawer）

iframe 直接还原浮层在原页面里的视觉上下文，无需 `bodySelector` 等 DOM 提取字段。
