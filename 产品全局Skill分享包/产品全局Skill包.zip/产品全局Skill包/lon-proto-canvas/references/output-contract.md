# 输出契约

本文档定义 `build_canvas.py` 的 stdout JSON 结构和复述格式规范。

## stdout JSON Schema

脚本执行完成后，stdout 输出结构化 JSON：

```json
{
  "mode": "new-folder | new-single | merge | update-page | add-page",
  "outputDir": "...",
  "summary": {
    "totalPages": N, 
    "totalStates": M, 
    "totalOverlays": K, 
    "totalTriggers": T,
    "newPages": _, 
    "updatedPages": _, 
    "missingPages": _, 
    "keptPages": _,
    "orphansAdded": _, 
    "annotationsBoundToInstance": _,
    "hiddenPages": _,
    "hiddenFrames": _,
    "layoutFrames": _,
    "layoutShapes": _,
    "layoutCreated": _,
    "layoutRemoved": _,
    "layoutMigratedFromHidden": _
  },
  "initialPage": "...",
  "indexFile": "index.html 绝对路径",
  "dataFiles": ["六个数据文件绝对路径"],
  "canvasAssets": ["assets/canvas.css", "assets/canvas.js"],
  "serverScript": "canvas_server.py 绝对路径",
  "pageOverview": [
    { 
      "id": "...", 
      "order": N, 
      "name": "...", 
      "states": N, 
      "overlays": N, 
      "triggers": N, 
      "missing": false 
    }
  ],
  "warnings": [...],
  "backups": [".bak.* 文件路径列表"],
  "hiddenRetired": "hidden.json 迁移归档后的路径，没有可迁移的 hidden.json 时为 null",
  "vendor": [
    { 
      "dir": "...", 
      "version": "...", 
      "files": N, 
      "status": "downloaded|skipped|failed" 
    }
  ],
  "canvasImages": { 
    "dir": "assets/canvas-images 的绝对路径，目录不存在时为 null", 
    "kept": N, 
    "removed": ["本次清理掉的无引用图片文件名"] 
  },
  "devPrdIndex": { 
    "path": "...", 
    "fileCount": N, 
    "latest": "..." 
  },
  "refsIndex": { 
    "path": "...", 
    "fileCount": N 
  }
}
```

`summary` 中与画布编排相关的字段：

| 字段 | 含义 |
|------|------|
| `annotationsBoundToInstance` | 本次构建为缺 `instanceId` 的旧标注补齐宿主实例的条数 |
| `hiddenPages` / `hiddenFrames` | 本次构建读到的 `hidden.json` 中隐藏页面 / frame 数量；没有 `hidden.json` 或已完成迁移时恒为 0，仅用于核对迁移读数，不代表画布当前状态 |
| `layoutFrames` / `layoutShapes` | 本次构建后 `layout.json` 中的 frame 实例数 / 图形对象数 |
| `layoutCreated` | 首次生成 `layout.json` 时铺开的实例数；非首次（已有 `layout.json`）恒为 0 |
| `layoutRemoved` | 本次构建因 `pages.json` 中 frameKey 消失而清理掉的实例数 |
| `layoutMigratedFromHidden` | 首次生成时因命中 `hidden.json` 隐藏项而跳过、未生成实例的 frameKey 数 |
| `hiddenRetired`（顶层字段，非 `summary` 内） | `hidden.json` 迁移归档后的文件路径；不存在可迁移的 `hidden.json` 时为 `null` |

## `prototypes/pages.json` 的 `viewDefaults`

```json
"viewDefaults": { "theme": "light | dark", "locked": false }
```

站点默认视图偏好，由 `--theme` / `--locked` 写入，两者都不传时沿用上一次构建的值。前端取值：主题为「本机 localStorage > `viewDefaults.theme` > `light`」，锁定直接取 `viewDefaults.locked`（不记本机偏好，刷新回到站点默认）。

`locked` 还有第二个写入方：画布的锁定开关经 `PUT /api/canvas/view` 落盘。该接口只合并 `viewDefaults` 里的白名单字段（`canvas_server.py::VIEW_WRITABLE_KEYS`），同级的 `theme` 与整份 `pages` 扫描结果原样保留；`pages.json` 缺失或损坏时回 409 拒绝写入，不新建文件。

## `prototypes/layout.json` 文件结构

画布编排文件，与 `pages.json`（机器扫描结果：原型里有哪些页面/状态/浮层）分离——`layout.json` 记录人的编排意图：画布上放了哪些 frame 实例、摆在哪、画了哪些图形。是「画布上有什么」的唯一真相源。

```json
{
  "version": "2",
  "updatedAt": "2026-08-26T10:00:00.000Z",
  "frames": [
    { "id": "fi-a3k9x2", "pageId": "01-holdings", "frameKey": "default", "x": 60, "y": 60 },
    { "id": "fi-b7m4p1", "pageId": "01-holdings", "frameKey": "default", "x": 900, "y": 480 }
  ],
  "shapes": [
    { "id": "sh-rect-k2p9", "kind": "rect", "x": 20, "y": 20, "w": 860, "h": 940, "text": "首屏三态" },
    { "id": "sh-note-7d1a", "kind": "note", "x": 480, "y": 1000, "w": 200, "h": 120, "text": "空仓文案待确认", "color": "yellow" },
    { "id": "sh-text-m4x0", "kind": "text", "x": 60, "y": 1180, "text": "以下为异常态" },
    { "id": "sh-img-9f2c", "kind": "image", "x": 980, "y": 60, "w": 640, "h": 398, "src": "assets/canvas-images/d2bee41562e58724.png" },
    {
      "id": "sh-arw-b8q3", "kind": "arrow",
      "from": { "instanceId": "fi-a3k9x2", "anchor": "right" },
      "to": { "x": 1400, "y": 900 }
    }
  ]
}
```

**`frames` 是实例数组，不是 map**：同一个 `pageId#frameKey` 可以出现任意多次，各自独立 `id` 与坐标——这是「同一状态添加多个实例、各自独立打标注」的基础。画布上有什么完全由 `frames` 决定：`build_canvas.py` 重跑时只做减法（清理 `pages.json` 中已消失的 frameKey 对应实例），不自动新增；新扫到的 frameKey 只在添加面板打 NEW 徽标，不会自动铺开到画布上。

`shapes`：画布图形对象数组。`id` 生成规则为 `"sh-" + kind 缩写 + "-" + 4 位 base36`，缩写取 `rect` / `note` / `text` / `flow` / `arw` / `img`。

| kind | 必需字段 | 说明 |
|------|---------|------|
| `rect` | `x` `y` `w` `h` `text` | 左上角坐标 + 尺寸；`text` 为纯文本，可为空串 |
| `note` | `x` `y` `w` `h` `text` `color` | `color` 取 `yellow` / `pink` / `blue` / `green` |
| `text` | `x` `y` `text` | 无尺寸，随内容撑开；`text` 为空的对象不落盘 |
| `flow` | `x` `y` `w` `h` `text` `variant` | 流程节点，形状由 `variant` 决定，取值见下表；非法值按 `process` 渲染 |
| `image` | `x` `y` `w` `h` `src` | 粘贴 / 拖入的图片；`src` 是相对站点根的路径，指向 `assets/canvas-images/`。无文字层，缩放锁原始比例 |
| `arrow` | `from` `to` | 端点联合类型，见下；可选 `route`、`mid` 与 `label` |

`image` 的二进制不进 `layout.json`。图片经 `POST /api/canvas/image` 落到 `prototypes/assets/canvas-images/<sha256 前 16 位>.<ext>`，`src` 只留路径。这条分工是硬约束，三个理由：`PUT /api/canvas/layout` 有 4MB 上限，几张 base64 图片就会把整份编排顶过阈值，被拒的是这一轮全部 `frames` 与 `shapes`，不只是图片；图片按内容 sha256 命名，同一张重复粘贴天然去重；二进制落成独立文件才能随站点目录一起 git 提交、被别人 clone 到手里。没有写 API 的静态模式下画布直接禁用贴图，不做 base64 降级。

`flow` 的 `variant` 取自一张形状注册表，一个轮廓一个 key。分成两组只影响它出现在哪个面板里，落盘数据没有组的概念——同一轮廓在两种语境下叫法不同的（判定 / 菱形），仍是同一个 key：

| 组 | 面板 | variant |
|----|------|---------|
| 流程符号 | `F` | `start` `process` `decision` `io` `data` `doc` `connector` `predefined` `manualOp` `manualInput` `delay` `prep` `display` `multidoc` `offpage` |
| 基础几何 | `R` | `process` `decision` `io` `data` `connector` `prep`（与流程组共用轮廓）+ `square` `triangle` `triangleDown` `trapezoid` `pentagon` `star` `cross` `arrowRight` `cloud` |

`R` 面板首项「方框」落的是 `kind: "rect"`（内部让出指针的圈选框），不是 `flow` 节点。选中 `flow` / `rect` 时浮条上的形状切换器在这两者之间任意换，`x` / `y` / `w` / `h` / `text` 原样保留。

箭头端点三种形态可混用，一端绑宿主一端自由完全合法：

```
绑卡片：{ "instanceId": "fi-a3k9x2", "anchor": "right" }
绑图形：{ "shapeId": "sh-flow-k2p9", "anchor": "left" }
自由端：{ "x": 900, "y": 500 }
```

`anchor` 取 `top` / `right` / `bottom` / `left`。可作宿主的图形是 `rect` / `note` / `flow`；`text` 随内容撑开、没有稳定包围盒，`arrow` 自己也不能当宿主。

箭头路由由两个可选字段控制：

| 字段 | 取值 | 缺省 |
|------|------|------|
| `route` | `straight` / `elbow` | 缺失或非法值按 `straight` 渲染 |
| `mid` | 0.05 ~ 0.95 | 缺失按 0.5；只有两端出线主轴相同的 Z 型折线消费它，L 型忽略 |
| `label` | 纯文本 | 缺失即无标签；压在路径中段，双击线编辑，清空即删除该字段 |

出线主轴由端点的 `anchor` 决定（`left` / `right` 为横向，`top` / `bottom` 为纵向）；自由端没有宿主可问，按两端位移的主方向推断。

绑定端所引用的宿主被移除时（卡片从添加面板删除、`pages.json` 中该 frameKey 消失、图形被删），该端降级为移除瞬间的绝对坐标，箭头本身保留。构建期只处理卡片实例的删除，图形删除由前端处理。

`id` 生成规则（两条独立路径，互不影响，只需保证不撞车）：
- 添加面板手动添加实例（前端）：`"fi-" + Math.random().toString(36).slice(2, 8)`，随机 6 位
- 首次生成 `layout.json`（`scripts/layout.py::make_instance_id`）：`"fi-" + sha1(f"{pageId}#{frameKey}#{序号}").hexdigest()[:6]`，确定性哈希，保证同输入重跑结果一致，便于测试断言

**首次生成 / 老数据迁移**（output_dir 下不存在 `layout.json` 时触发）：
- 按 `pages.json` 现有页面顺序、每页 frame 排布顺序，为每个未被 `hidden.json` 标记隐藏的 frameKey 各生成 1 个实例，坐标按现有网格算法分配
- `hidden.json`（若存在）里 `pages` / `frames` 标记过的 frameKey 直接跳过，不生成实例，计入 `layoutMigratedFromHidden`
- 完成后若 `hidden.json` 存在，改名归档为 `hidden.json.retired.{时间戳}`（与其余文件 `.bak.{时间戳}` 备份同一套命名风格，仅后缀不同），归档路径回填到 stdout 顶层 `hiddenRetired` 字段
- 已有 `layout.json` 时不再触发上述流程，构建只清理消失的实例，坐标与 `shapes` 原样保留

**标注宿主绑定**（每次构建都会执行，不限首次）：
- `annotations.json` 中缺 `instanceId` 的标注，按 `pageId + frameKey` 匹配 `layout.frames` 里第一个同 key 的实例补齐（`scripts/layout.py::attach_instance_ids`，计入 `annotationsBoundToInstance`）
- 宿主实例不在 `layout.frames` 里的标注（含补不上宿主的）迁入 `orphans[]`（`scripts/layout.py::orphan_by_missing_instance`）；孤儿判定完整规则见 `references/annotation-spec.md` 第 9 节

## 强制自检

向用户复述前必须核对：

### warnings 处理

- `warnings` 非空 → 列入复述「提醒」块
- 常见原因：源 HTML 缺 manifest 块、selector 没命中、manifest JSON 解析失败
- 原样转述 warnings 字符串，不重新措辞、不猜测原因、不在脚本未提示问题时补建议

## 复述输出格式

复述结果严格按下面 4 段格式，字段直接映射自 JSON，不增不减、不预设结论：

```
画布已生成：{outputDir}/index.html
模式：{mode}（用中文同义词复述，如：增量合并，2 个页面更新 / 1 个新增 / 1 个标缺失）

页面摘要：
  [{order}] {name} — {states} 状态 / {overlays} 浮层 / {triggers} 触发
  ...

提醒（仅当 warnings 非空 或 orphansAdded > 0 才出现此块）：
  - {warning}
  - {orphansAdded} 条标注已迁到孤儿区

备份（仅当 backups 非空才出现此块）：{backups}

下一步：
  A. 双击打开 {outputDir}/index.html 可只读浏览（file:// 走 js 镜像）；要落盘标注请走 B
  B. 起 lon-lan-launcher 指 {outputDir}/（同时服务原型 + demo + 画布），投大屏 / 给手机看
  C. 继续追加 / 更新某页（再跑本技能）
```

## 模式复述映射

| mode 值 | 复述示例 |
|---------|---------|
| new-folder | 新建（目录全量） |
| new-single | 新建（单文件） |
| merge | 增量合并，N 个页面更新 / M 个新增 / K 个标缺失 |
| update-page | 单页更新 |
| add-page | 单页追加 |
