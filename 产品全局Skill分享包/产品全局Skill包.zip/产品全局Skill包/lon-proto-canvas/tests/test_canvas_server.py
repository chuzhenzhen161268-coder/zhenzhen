"""canvas_server.py 的路由契约测试。

路由表用不起真实 HTTP 服务的源码结构断言覆盖——服务端只有几十行，起服务的成本
远高于收益，而路由表漏一条就是画布静默进静态模式这种难查的问题。

_validate_layout_shape 是纯函数，直接 import 模块调用做行为测试，不涉及 socket/
线程，同样不需要起服务。
"""
import sys
from pathlib import Path

import pytest

SERVER = Path(__file__).resolve().parents[1] / "scripts" / "canvas_server.py"

sys.path.insert(0, str(SERVER.parent))
import canvas_server  # noqa: E402


@pytest.fixture(scope="module")
def src() -> str:
    return SERVER.read_text(encoding="utf-8")


def test_layout_route_registered(src):
    assert '"/api/canvas/layout"' in src


def test_layout_file_attribute_declared(src):
    assert "layout_file: Path" in src


def test_layout_file_bound_to_root(src):
    assert 'CanvasHTTPRequestHandler.layout_file = root_dir / "layout.json"' in src


def test_annotations_route_still_present(src):
    assert '"/api/canvas/annotations"' in src


def test_refs_route_registered(src):
    assert '"/api/canvas/refs"' in src


def test_refs_route_declares_site_root(src):
    assert "site_root: Path" in src
    assert "CanvasHTTPRequestHandler.site_root = root_dir" in src


def test_non_api_get_falls_through_to_static(src):
    """do_GET 只截 API 前缀，其余必须交回父类——吞掉静态文件等于整张画布打不开。"""
    body = src[src.index("def do_GET"):src.index("def do_POST")]
    assert "super().do_GET()" in body


def test_probe_route_still_present(src):
    assert '"/api/canvas/probe"' in src


def test_layout_route_wires_the_shape_validator(src):
    """PUT /api/canvas/layout 必须带校验器，否则畸形 body（如 {"frames": null}）
    会原样落盘，下次 build 在 layout.py 里炸出 TypeError。"""
    assert "validator=_validate_layout_shape" in src


@pytest.mark.parametrize(
    "payload,expect_error",
    [
        ({"frames": [], "shapes": []}, False),
        ({"frames": [{"id": "fi-1"}]}, False),
        ({}, False),           # 字段缺失不强制要求，只在字段存在时校验类型
        ({"frames": None}, True),
        ({"shapes": None}, True),
        ({"frames": "oops"}, True),
        ({"frames": {"not": "a list"}}, True),
        (["not", "a", "dict"], True),
        (None, True),
        ("just a string", True),
    ],
)
def test_validate_layout_shape(payload, expect_error):
    error = canvas_server._validate_layout_shape(payload)
    assert (error is not None) == expect_error


# ---------- 图片上传：POST /api/canvas/image ----------

def test_image_route_registered(src):
    assert '"/api/canvas/image"' in src


def test_image_dir_bound_under_assets(src):
    """落点必须是站点根下的 assets/canvas-images/，前端拿到的相对路径才解析得到。"""
    assert 'CanvasHTTPRequestHandler.image_dir = root_dir / "assets" / IMAGE_DIR_NAME' in src


def test_probe_advertises_image_capability(src):
    """canvas_server.py 会被拷进各站点目录分发，线上同时跑着多个版本。
    probe 不自报能力，画布就只能等撞上 404 才知道服务端是旧版。"""
    assert '"features": {"image": True, "view": True}' in src


def test_image_type_whitelist_is_closed():
    """Content-Type 白名单同时决定「收不收」与落盘扩展名。改成开放式映射
    （比如直接切 MIME 子类型当后缀）会让 image/svg+xml 这类可执行内容
    落进站点目录，再被同源加载。"""
    assert set(canvas_server.IMAGE_TYPES) == {
        "image/webp", "image/png", "image/jpeg", "image/gif"
    }
    assert all(ext.startswith(".") for ext in canvas_server.IMAGE_TYPES.values())


def test_image_filename_comes_from_content_hash(src):
    """文件名由服务端按内容哈希生成，不读客户端传来的任何名字——路径穿越从根上断掉，
    同一张图重复粘贴也只落一个文件。"""
    assert "hashlib.sha256(body).hexdigest()[:16] + ext" in src


def test_image_size_cap_declared():
    assert canvas_server.IMAGE_MAX_BYTES == 8 * 1024 * 1024


def test_image_rejects_unlisted_type(src):
    """未命中白名单回 415，不落盘。"""
    assert "self._reply_json(415," in src


def test_image_rejects_oversized_body(src):
    assert "self._reply_json(413," in src


# ---------- 图片上传的端到端行为 ----------
# 这一组跟本文件其余部分的约定不同，真起一次 HTTP 服务。理由：上传端点是唯一会读
# 请求体字节并写二进制文件的路径，「路由挂没挂上」用源码断言够，「字节有没有原样落到
# 正确的文件名」只有真跑一遍才知道。服务起在 127.0.0.1 随机端口上，测完即关。

@pytest.fixture
def live_server(tmp_path):
    import threading
    from http.server import ThreadingHTTPServer

    root = tmp_path / "site"
    root.mkdir()
    # 每个测试派生独立的 Handler 子类，而不是直接改 canvas_server.CanvasHTTPRequestHandler
    # 的类属性：ThreadingHTTPServer 默认 daemon_threads=True，server_close() 不 join 请求
    # 线程，上一个测试残留的线程可能在类属性被下一个测试重指向之后才跑，把文件写进错的
    # root。独立子类从根上断掉这种跨测试串扰。
    handler_cls = type(
        "_TestHandler",
        (canvas_server.CanvasHTTPRequestHandler,),
        {
            "annotations_file": root / "annotations.json",
            "layout_file": root / "layout.json",
            "pages_file": root / "pages.json",
            "image_dir": root / "assets" / canvas_server.IMAGE_DIR_NAME,
            "site_root": root,
            # 静态文件根：真实服务靠 main() 里的 os.chdir，测试里不能改进程 cwd
            "__init__": lambda self, *a, **kw: canvas_server.CanvasHTTPRequestHandler.__init__(
                self, *a, directory=str(root), **kw
            ),
        },
    )
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
    httpd.daemon_threads = False  # 配合 block_on_close，server_close() 会 join 所有请求线程
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{httpd.server_address[1]}", root
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=5)


def _post(base, path, body, ctype):
    import json as _json
    import urllib.error
    import urllib.request

    req = urllib.request.Request(
        base + path, data=body, method="POST", headers={"Content-Type": ctype}
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, _json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, _json.loads(e.read().decode("utf-8"))


def test_image_upload_writes_bytes_verbatim(live_server):
    base, root = live_server
    body = b"\x89PNG\r\n\x1a\n" + b"payload-bytes" * 10
    status, data = _post(base, "/api/canvas/image", body, "image/png")

    assert status == 200
    assert data["path"].startswith("assets/canvas-images/")
    assert data["path"].endswith(".png")
    # 返回的是站点内相对路径，前端直接塞进 <img src> 按站点根解析
    landed = root / data["path"]
    assert landed.read_bytes() == body


def test_image_upload_is_content_addressed(live_server):
    """同一张图重复粘贴命中同一个文件，磁盘上不堆副本。"""
    base, root = live_server
    body = b"same-image-bytes"
    _, first = _post(base, "/api/canvas/image", body, "image/webp")
    _, second = _post(base, "/api/canvas/image", body, "image/webp")

    assert first["path"] == second["path"]
    assert len(list((root / "assets" / canvas_server.IMAGE_DIR_NAME).iterdir())) == 1


def test_image_upload_rejects_svg(live_server):
    """SVG 会被同源加载并执行脚本，白名单必须挡住它，且不能留下任何文件。"""
    base, root = live_server
    status, data = _post(
        base, "/api/canvas/image", b"<svg onload='alert(1)'></svg>", "image/svg+xml"
    )

    assert status == 415
    assert "error" in data
    assert not (root / "assets" / canvas_server.IMAGE_DIR_NAME).exists()


def test_image_upload_rejects_empty_body(live_server):
    base, _ = live_server
    status, _data = _post(base, "/api/canvas/image", b"", "image/png")
    assert status == 400


def test_probe_reports_image_feature_over_the_wire(live_server):
    base, _ = live_server
    status, data = _post(base, "/api/canvas/probe", b"{}", "application/json")
    assert status == 200
    assert data["features"]["image"] is True


def test_probe_drains_request_body_before_replying(live_server):
    """BaseHTTPRequestHandler 走 HTTP/1.0，一回应就关连接。接收缓冲区里还压着没读完的
    请求体时，内核关连接发的是 RST 而不是 FIN，客户端可能在读到响应前就撞上 reset。
    画布的 probeServer 发的正是带 body 的 POST，探测失败会让它误判成静态模式——
    横幅弹出、每一笔改动都停止落盘。body 必须在回应前读干净。"""
    base, _ = live_server
    body = _json.dumps({"pad": "x" * 256 * 1024}).encode("utf-8")   # 超过 socket 缓冲，未读时写入阶段就会断
    status, data = _post(base, "/api/canvas/probe", body, "application/json")
    assert status == 200
    assert data["features"]["image"] is True


# ---------- JSON 落盘：服务端盖时间戳 + 镜像 + 校验 ----------

import json as _json
import re as _re
import urllib.error as _urlerr
import urllib.request as _urlreq


def _get(base, path):
    import json as _json
    import urllib.error
    import urllib.request

    try:
        with urllib.request.urlopen(base + path, timeout=5) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def test_refs_endpoint_lists_html_over_the_wire(live_server):
    import json as _json

    base, root = live_server
    refs = root / "refs"
    refs.mkdir()
    (refs / "01-竞品调研.html").write_text("<title>竞品调研报告</title>", encoding="utf-8")
    (refs / "02-埋点.html").write_text("<html><body>没有标题</body></html>", encoding="utf-8")
    (refs / "readme.md").write_text("# 不是 HTML", encoding="utf-8")

    status, body = _get(base, "/api/canvas/refs")
    data = _json.loads(body.decode("utf-8"))
    assert status == 200
    assert [f["file"] for f in data["files"]] == ["01-竞品调研.html", "02-埋点.html"]
    assert [f["title"] for f in data["files"]] == ["竞品调研报告", "02-埋点"]


def test_refs_endpoint_is_live(live_server):
    """扔进去的文档刷新即可见，不必重跑画布生成——这是端点存在的全部理由。"""
    import json as _json

    base, root = live_server
    assert _json.loads(_get(base, "/api/canvas/refs")[1])["files"] == []
    (root / "refs").mkdir()
    (root / "refs" / "新加的.html").write_text("<title>新加的</title>", encoding="utf-8")
    assert len(_json.loads(_get(base, "/api/canvas/refs")[1])["files"]) == 1


def test_static_files_still_served_after_get_override(live_server):
    base, root = live_server
    (root / "ping.txt").write_text("pong", encoding="utf-8")
    status, body = _get(base, "/ping.txt")
    assert (status, body) == (200, b"pong")


def _put(base, path, body_bytes, ctype="application/json"):
    req = _urlreq.Request(base + path, data=body_bytes, method="PUT", headers={"Content-Type": ctype})
    try:
        with _urlreq.urlopen(req, timeout=5) as r:
            return r.status, _json.loads(r.read().decode("utf-8")), dict(r.headers)
    except _urlerr.HTTPError as e:
        return e.code, _json.loads(e.read().decode("utf-8")), dict(e.headers)


ISO_MS_Z = _re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$")


def test_now_iso_is_millisecond_utc_z():
    assert ISO_MS_Z.match(canvas_server.now_iso())


def test_mirror_source_defines_global_and_slot():
    src = canvas_server.mirror_source("annotations", {"a": 1})
    assert src.startswith("window.__CANVAS_DATA__ = window.__CANVAS_DATA__ || {};\n")
    assert 'window.__CANVAS_DATA__["annotations"] = {"a": 1};' in src


def test_write_json_with_mirror_writes_both_files(tmp_path):
    target = tmp_path / "layout.json"
    mirror = canvas_server.write_json_with_mirror(target, {"frames": [], "shapes": []})
    assert mirror == tmp_path / "layout.js"
    assert _json.loads(target.read_text(encoding="utf-8")) == {"frames": [], "shapes": []}
    assert '__CANVAS_DATA__["layout"]' in mirror.read_text(encoding="utf-8")
    assert not (tmp_path / "layout.json.tmp").exists()


@pytest.mark.parametrize(
    "payload,expect_error",
    [
        ({"annotations": [], "orphans": []}, False),
        ({}, False),
        ({"annotations": None}, True),
        ({"orphans": "x"}, True),
        ([], True),
        (None, True),
    ],
)
def test_validate_annotations_shape(payload, expect_error):
    assert (canvas_server._validate_annotations_shape(payload) is not None) == expect_error


def test_put_annotations_stamps_server_time_and_writes_mirror(live_server):
    base, root = live_server
    body = _json.dumps({"version": "1", "updatedAt": "1999-01-01T00:00:00.000Z", "annotations": [], "orphans": []}).encode()
    status, data, headers = _put(base, "/api/canvas/annotations", body)
    assert status == 200 and data["ok"] is True
    assert ISO_MS_Z.match(data["updatedAt"]) and data["updatedAt"] != "1999-01-01T00:00:00.000Z"
    on_disk = _json.loads((root / "annotations.json").read_text(encoding="utf-8"))
    assert on_disk["updatedAt"] == data["updatedAt"]
    assert (root / "annotations.js").exists()
    assert "Access-Control-Allow-Origin" not in headers
    assert headers.get("Cache-Control") == "no-store, no-cache, must-revalidate, max-age=0"


def test_put_annotations_rejects_bad_shape_without_writing(live_server):
    base, root = live_server
    status, data, _ = _put(base, "/api/canvas/annotations", b"[]")
    assert status == 400 and "error" in data
    assert not (root / "annotations.json").exists()


def test_put_rejects_nan(live_server):
    base, root = live_server
    status, _, _ = _put(base, "/api/canvas/layout", b'{"frames": [], "shapes": [], "x": NaN}')
    assert status == 400
    assert not (root / "layout.json").exists()


def test_put_rejects_oversized_body(live_server):
    base, _ = live_server
    huge = b'{"frames": [], "shapes": [], "pad": "' + b"x" * (canvas_server.JSON_MAX_BYTES + 1) + b'"}'
    status, _, _ = _put(base, "/api/canvas/layout", huge)
    assert status == 413


def test_options_no_longer_served(live_server):
    base, _ = live_server
    req = _urlreq.Request(base + "/api/canvas/layout", method="OPTIONS")
    try:
        _urlreq.urlopen(req, timeout=5)
        assert False, "OPTIONS 应返回 501"
    except _urlerr.HTTPError as e:
        assert e.code == 501


def test_concurrent_puts_all_succeed_and_files_stay_consistent(live_server):
    """ThreadingHTTPServer 并发处理多个 PUT，写 json 与写 js 镜像必须整体互斥，
    否则同名 .tmp 会被另一线程抢先 os.replace 掉，也可能出现 json 与镜像来自
    两个不同 payload 的半致状态。"""
    import concurrent.futures

    base, root = live_server

    def _put_one(i):
        payload = _json.dumps(
            {"version": "1", "annotations": [{"id": f"a-{i}"}], "orphans": []}
        ).encode()
        return _put(base, "/api/canvas/annotations", payload)

    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as pool:
        results = list(pool.map(_put_one, range(30)))

    statuses = [status for status, _, _ in results]
    assert statuses == [200] * 30, statuses

    on_disk = _json.loads((root / "annotations.json").read_text(encoding="utf-8"))
    mirror_text = (root / "annotations.js").read_text(encoding="utf-8")
    mirror_json = _json.loads(mirror_text.split("] = ", 1)[1].rstrip(";\n"))
    assert on_disk == mirror_json
    assert on_disk["updatedAt"] == mirror_json["updatedAt"]
    assert not (root / "annotations.json.tmp").exists()
    assert not (root / "annotations.js.tmp").exists()


# ---------- 站点默认视图：PUT /api/canvas/view ----------
# 锁定状态存进 pages.json 的 viewDefaults，评审包上传到静态托管后打开就是发出去的样子。
# 这是唯一一条 read-modify-write 的路径，行为测试真跑一次服务。

def test_view_route_registered(src):
    assert '"/api/canvas/view"' in src


def test_pages_file_attribute_declared(src):
    assert "pages_file: Path" in src


def test_pages_file_bound_to_root(src):
    assert 'CanvasHTTPRequestHandler.pages_file = root_dir / "pages.json"' in src


def test_view_writable_keys_is_a_closed_whitelist():
    """pages.json 的其余内容是 build_canvas.py 的扫描产物。这里一旦放开成黑名单，
    画布就能顺着这条通道把整站的页面清单覆盖掉。"""
    assert canvas_server.VIEW_WRITABLE_KEYS == {"locked"}


@pytest.mark.parametrize(
    "payload,expect_error",
    [
        ({"locked": True}, False),
        ({"locked": False}, False),
        ({}, True),                                  # 缺 locked
        ({"locked": "true"}, True),                  # 字符串不是布尔
        ({"locked": 1}, True),
        ({"locked": True, "pages": []}, True),       # 白名单外的字段
        ({"theme": "dark"}, True),                   # theme 走本机偏好，不由这条通道改
        (["not", "a", "dict"], True),
        (None, True),
    ],
)
def test_validate_view_shape(payload, expect_error):
    error = canvas_server._validate_view_shape(payload)
    assert (error is not None) == expect_error


def _write_pages(root, **view):
    import json as _json

    data = {
        "version": "1",
        "generatedAt": "2026-01-01T00:00:00.000Z",
        "project": "demo",
        "initialPage": "01-home",
        "viewDefaults": {"theme": "dark", "locked": False, **view},
        "pages": [{"id": "01-home", "order": 1}],
    }
    (root / "pages.json").write_text(_json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return data


def test_view_put_persists_locked_and_keeps_scan_result(live_server):
    """只改 viewDefaults.locked：同级的 theme 与整份 pages 扫描结果原样保留。"""
    base, root = live_server
    before = _write_pages(root)

    status, data, _ = _put(base, "/api/canvas/view", b'{"locked": true}')
    assert status == 200 and data["ok"] is True
    assert data["viewDefaults"]["locked"] is True

    after = _json.loads((root / "pages.json").read_text(encoding="utf-8"))
    assert after["viewDefaults"]["locked"] is True
    assert after["viewDefaults"]["theme"] == before["viewDefaults"]["theme"]
    assert after["pages"] == before["pages"]
    assert after["generatedAt"] == before["generatedAt"]


def test_view_put_writes_js_mirror(live_server):
    """file:// 下画布读的是 pages.js 镜像，不同步更新它，本机再打开还是旧的锁定态。"""
    base, root = live_server
    _write_pages(root)
    _put(base, "/api/canvas/view", b'{"locked": true}')

    mirror = (root / "pages.js").read_text(encoding="utf-8")
    assert _json.loads(mirror.split("] = ", 1)[1].rstrip(";\n"))["viewDefaults"]["locked"] is True


def test_view_put_can_unlock_again(live_server):
    base, root = live_server
    _write_pages(root, locked=True)
    status, data, _ = _put(base, "/api/canvas/view", b'{"locked": false}')
    assert status == 200 and data["viewDefaults"]["locked"] is False
    assert _json.loads((root / "pages.json").read_text(encoding="utf-8"))["viewDefaults"]["locked"] is False


def test_view_put_without_pages_json_refuses_to_create_one(live_server):
    """pages.json 是扫描产物。缺失时凭空造一份等于用空壳顶掉整站页面清单，
    回 409（客户端据此不重试），文件也不许出现。"""
    base, root = live_server
    status, data, _ = _put(base, "/api/canvas/view", b'{"locked": true}')
    assert status == 409 and "error" in data
    assert not (root / "pages.json").exists()


def test_view_put_on_corrupted_pages_json_refuses(live_server):
    base, root = live_server
    (root / "pages.json").write_text("[]", encoding="utf-8")
    status, _, _ = _put(base, "/api/canvas/view", b'{"locked": true}')
    assert status == 409
    assert (root / "pages.json").read_text(encoding="utf-8") == "[]"


def test_view_put_rejects_unlisted_field(live_server):
    """借这条通道改 pages 会被拒，磁盘上那份不能有任何变化。"""
    base, root = live_server
    _write_pages(root)
    original = (root / "pages.json").read_text(encoding="utf-8")
    status, _, _ = _put(base, "/api/canvas/view", b'{"locked": true, "pages": []}')
    assert status == 400
    assert (root / "pages.json").read_text(encoding="utf-8") == original


def test_update_view_defaults_creates_section_when_missing(tmp_path):
    """老 pages.json 可能没有 viewDefaults 这一节，补出来而不是炸掉。"""
    import json as _json

    path = tmp_path / "pages.json"
    path.write_text(_json.dumps({"version": "1", "pages": []}), encoding="utf-8")
    view = canvas_server.update_view_defaults(path, {"locked": True})
    assert view == {"locked": True}
    assert _json.loads(path.read_text(encoding="utf-8"))["pages"] == []
