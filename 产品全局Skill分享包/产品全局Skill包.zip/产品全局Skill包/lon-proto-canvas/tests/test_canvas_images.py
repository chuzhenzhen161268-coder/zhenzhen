"""贴进画布的图片在磁盘上的生命周期：sweep_canvas_images 的对账行为。

图片是二进制、随 prototypes/ 进 git，删掉图形后文件不会自己走。这个清理跑在每次
build 里，误删就是评审资料丢失，所以「什么该留」的判定要逐条钉死。
"""
import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import build_canvas  # noqa: E402


@pytest.fixture
def site(tmp_path):
    root = tmp_path / "prototypes"
    (root / "assets" / build_canvas.CANVAS_IMAGE_DIR).mkdir(parents=True)
    return root


def image_dir(site):
    return site / "assets" / build_canvas.CANVAS_IMAGE_DIR


def put(site, name, data=b"x"):
    p = image_dir(site) / name
    p.write_bytes(data)
    return p


def shape(src, kind="image"):
    return {"id": "sh-img-1", "kind": kind, "src": src}


def test_keeps_referenced_and_drops_the_rest(site):
    put(site, "keep.webp")
    put(site, "drop.webp")
    warnings = []

    out = build_canvas.sweep_canvas_images(
        site, {"shapes": [shape("assets/canvas-images/keep.webp")]}, warnings
    )

    assert (image_dir(site) / "keep.webp").exists()
    assert not (image_dir(site) / "drop.webp").exists()
    assert out["removed"] == ["drop.webp"]
    assert out["kept"] == 1
    assert warnings == []


def test_matches_on_basename_not_full_path(site):
    """导入的旧数据里 src 可能是别的路径写法。只认文件名，不因前缀变体误删。"""
    put(site, "a.png")
    build_canvas.sweep_canvas_images(site, {"shapes": [shape("./a.png")]}, [])
    assert (image_dir(site) / "a.png").exists()


def test_ignores_non_image_shapes(site):
    """别的图形也可能带 src 之外的字段；只有 kind == image 的 src 算引用。"""
    put(site, "orphan.webp")
    build_canvas.sweep_canvas_images(
        site,
        {"shapes": [{"id": "sh-rect-1", "kind": "rect", "src": "orphan.webp"}]},
        [],
    )
    assert not (image_dir(site) / "orphan.webp").exists()


def test_missing_dir_is_a_no_op(tmp_path):
    """没起过服务端、从没贴过图的站点走这条路，不能因为目录不存在就炸。"""
    out = build_canvas.sweep_canvas_images(tmp_path, {"shapes": []}, [])
    assert out == {"dir": None, "kept": 0, "removed": []}


def test_empty_layout_clears_everything(site):
    put(site, "a.webp")
    put(site, "b.webp")
    out = build_canvas.sweep_canvas_images(site, {"shapes": []}, [])
    assert out["removed"] == ["a.webp", "b.webp"]
    assert list(image_dir(site).iterdir()) == []


@pytest.mark.parametrize("shapes", [None, [], [None], ["not a dict"]])
def test_tolerates_malformed_shapes(site, shapes):
    """layout.json 可能是历史脏数据。畸形 shapes 只该导致「没有引用」，不该抛异常。"""
    put(site, "a.webp")
    out = build_canvas.sweep_canvas_images(site, {"shapes": shapes}, [])
    assert out["removed"] == ["a.webp"]


def test_shape_without_src_is_not_a_reference(site):
    put(site, "a.webp")
    out = build_canvas.sweep_canvas_images(
        site, {"shapes": [{"id": "sh-img-1", "kind": "image"}]}, []
    )
    assert out["removed"] == ["a.webp"]


def test_subdirectories_are_left_alone(site):
    """只删文件、不递归。目录里出现子目录时不该被当成待清理项处理。"""
    (image_dir(site) / "nested").mkdir()
    out = build_canvas.sweep_canvas_images(site, {"shapes": []}, [])
    assert out["removed"] == []
    assert (image_dir(site) / "nested").is_dir()
