"""标注 instanceId 迁移与孤儿判定的单元测试。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import layout  # noqa: E402


def _ann(aid, page_id, frame_key, instance_id=None, number=1):
    anchor = {"kind": "frame", "pageId": page_id, "frameKey": frame_key, "x": 0.5, "y": 0.5}
    if instance_id:
        anchor["instanceId"] = instance_id
    return {"id": aid, "number": number, "anchor": anchor, "html": "note"}


def _layout(*frames):
    return {"version": "2", "frames": list(frames), "shapes": []}


def _frame(fid, page_id, frame_key):
    return {"id": fid, "pageId": page_id, "frameKey": frame_key, "x": 0, "y": 0}


# ---------- attach_instance_ids ----------

def test_legacy_annotation_gets_instance_id():
    ann_obj = {"annotations": [_ann("a1", "01-a", "default")], "orphans": []}
    lay = _layout(_frame("fi-aaa111", "01-a", "default"))
    out, migrated = layout.attach_instance_ids(ann_obj, lay)
    assert out["annotations"][0]["anchor"]["instanceId"] == "fi-aaa111"
    assert migrated == 1


def test_existing_instance_id_is_left_alone():
    ann_obj = {"annotations": [_ann("a1", "01-a", "default", "fi-keepme")], "orphans": []}
    lay = _layout(_frame("fi-aaa111", "01-a", "default"))
    out, migrated = layout.attach_instance_ids(ann_obj, lay)
    assert out["annotations"][0]["anchor"]["instanceId"] == "fi-keepme"
    assert migrated == 0


def test_canvas_anchor_is_untouched():
    ann_obj = {"annotations": [{"id": "a1", "number": 1, "anchor": {"kind": "canvas", "x": 10, "y": 20}}], "orphans": []}
    out, migrated = layout.attach_instance_ids(ann_obj, _layout())
    assert "instanceId" not in out["annotations"][0]["anchor"]
    assert migrated == 0


def test_legacy_annotation_with_no_matching_instance_stays_unassigned():
    """该 frameKey 首次铺开时被 hidden 跳过 —— 留给孤儿判定处理，这里不硬塞。"""
    ann_obj = {"annotations": [_ann("a1", "01-a", "empty")], "orphans": []}
    lay = _layout(_frame("fi-aaa111", "01-a", "default"))
    out, migrated = layout.attach_instance_ids(ann_obj, lay)
    assert "instanceId" not in out["annotations"][0]["anchor"]
    assert migrated == 0


def test_multiple_instances_bind_to_the_first():
    """老数据没有实例概念，只能挂到第一个；用户可在孤儿抽屉重新挂载调整。"""
    ann_obj = {"annotations": [_ann("a1", "01-a", "default")], "orphans": []}
    lay = _layout(
        _frame("fi-first0", "01-a", "default"),
        _frame("fi-second", "01-a", "default"),
    )
    out, _ = layout.attach_instance_ids(ann_obj, lay)
    assert out["annotations"][0]["anchor"]["instanceId"] == "fi-first0"


# ---------- orphan_by_missing_instance ----------

def test_annotation_on_removed_instance_becomes_orphan():
    ann_obj = {"annotations": [_ann("a1", "01-a", "default", "fi-gone00")], "orphans": []}
    lay = _layout(_frame("fi-aaa111", "01-a", "default"))
    out, moved = layout.orphan_by_missing_instance(ann_obj, lay)
    assert out["annotations"] == []
    assert len(out["orphans"]) == 1
    assert moved == 1
    assert "lostReason" in out["orphans"][0]
    assert "lostAt" in out["orphans"][0]


def test_orphan_keeps_its_number_and_content():
    ann_obj = {"annotations": [_ann("a1", "01-a", "default", "fi-gone00", number=7)], "orphans": []}
    out, _ = layout.orphan_by_missing_instance(ann_obj, _layout())
    assert out["orphans"][0]["number"] == 7
    assert out["orphans"][0]["html"] == "note"


def test_annotation_on_live_instance_survives():
    ann_obj = {"annotations": [_ann("a1", "01-a", "default", "fi-aaa111")], "orphans": []}
    lay = _layout(_frame("fi-aaa111", "01-a", "default"))
    out, moved = layout.orphan_by_missing_instance(ann_obj, lay)
    assert len(out["annotations"]) == 1
    assert moved == 0


def test_unassigned_legacy_annotation_becomes_orphan():
    """attach 没能配上宿主的老标注，在这一步进孤儿区，不会静默隐身。"""
    ann_obj = {"annotations": [_ann("a1", "01-a", "empty")], "orphans": []}
    lay = _layout(_frame("fi-aaa111", "01-a", "default"))
    out, moved = layout.orphan_by_missing_instance(ann_obj, lay)
    assert out["annotations"] == []
    assert moved == 1


def test_canvas_anchor_never_orphaned():
    ann_obj = {"annotations": [{"id": "a1", "number": 1, "anchor": {"kind": "canvas", "x": 1, "y": 2}}], "orphans": []}
    out, moved = layout.orphan_by_missing_instance(ann_obj, _layout())
    assert len(out["annotations"]) == 1
    assert moved == 0


def test_existing_orphans_are_preserved():
    ann_obj = {"annotations": [], "orphans": [{"id": "old", "number": 3, "anchor": {"kind": "frame"}}]}
    out, moved = layout.orphan_by_missing_instance(ann_obj, _layout())
    assert len(out["orphans"]) == 1
    assert moved == 0
