"""export_site.py：剔除规则、大小写精确的引用校验、统计报告。"""
import json
import subprocess
import sys
from pathlib import Path, PurePosixPath

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import export_site  # noqa: E402


@pytest.mark.parametrize(
    "rel,excluded",
    [
        ("canvas_server.py", True),
        ("启动demo-局域网.command", True),
        ("启动demo-局域网.bat", True),
        ("annotations.json.bak.20260828-101010", True),
        ("layout.json.corrupt.20260828-101010", True),
        ("hidden.json.retired.20260828-101010", True),
        ("hidden.json", True),
        ("layout.json.tmp", True),
        ("assets/icons/x.svg", True),
        ("pages/__pycache__/x.pyc", True),
        (".DS_Store", True),
        ("index.html", False),
        ("annotations.json", False),
        ("annotations.js", False),
        ("assets/canvas.js", False),
        ("assets/canvas-images/abc.webp", False),
        ("pages/01-登录.html", False),
        ("dev-prd/x-PRD-v1.0.0.md", False),
    ],
)
def test_should_exclude(rel, excluded):
    assert export_site.should_exclude(PurePosixPath(rel)) == excluded


def _site(tmp_path):
    site = tmp_path / "prototypes"
    (site / "pages").mkdir(parents=True)
    (site / "assets" / "canvas-images").mkdir(parents=True)
    (site / "assets" / "icons").mkdir()
    (site / "index.html").write_text('<link rel="stylesheet" href="assets/canvas.css" /><script src="assets/canvas.js"></script>', encoding="utf-8")
    (site / "assets" / "canvas.css").write_text("", encoding="utf-8")
    (site / "assets" / "canvas.js").write_text("", encoding="utf-8")
    (site / "assets" / "icons" / "x.svg").write_text("<svg/>", encoding="utf-8")
    (site / "pages" / "01-Login.html").write_text("<html></html>", encoding="utf-8")
    (site / "pages.json").write_text(json.dumps({"pages": [{"id": "p1", "sourceFile": "pages/01-Login.html"}]}), encoding="utf-8")
    (site / "layout.json").write_text(json.dumps({"frames": [], "shapes": [{"id": "s1", "kind": "image", "src": "assets/canvas-images/a.webp"}]}), encoding="utf-8")
    (site / "assets" / "canvas-images" / "a.webp").write_bytes(b"x")
    (site / "canvas_server.py").write_text("# server", encoding="utf-8")
    (site / "annotations.json.bak.1").write_text("{}", encoding="utf-8")
    return site


def test_copy_site_skips_excluded_and_reports_relative_paths(tmp_path):
    site = _site(tmp_path)
    out = tmp_path / "dist"
    copied = export_site.copy_site(site, out, clean=True)
    assert "canvas_server.py" not in copied
    assert "annotations.json.bak.1" not in copied
    assert "assets/icons/x.svg" not in copied
    assert "pages/01-Login.html" in copied
    assert (out / "assets" / "canvas-images" / "a.webp").read_bytes() == b"x"


def test_copy_site_clean_removes_stale_files(tmp_path):
    site = _site(tmp_path)
    out = tmp_path / "dist"
    out.mkdir()
    (out / "stale.txt").write_text("old", encoding="utf-8")
    export_site.copy_site(site, out, clean=True)
    assert not (out / "stale.txt").exists()


def test_exists_exact_is_case_sensitive(tmp_path):
    (tmp_path / "pages").mkdir()
    (tmp_path / "pages" / "01-Login.html").write_text("", encoding="utf-8")
    assert export_site.exists_exact(tmp_path, "pages/01-Login.html")
    assert not export_site.exists_exact(tmp_path, "pages/01-login.html")
    assert not export_site.exists_exact(tmp_path, "Pages/01-Login.html")


def test_check_references_reports_missing_and_case_mismatch(tmp_path):
    site = _site(tmp_path)
    out = tmp_path / "dist"
    copied = export_site.copy_site(site, out, clean=True)
    assert export_site.check_references(out, copied) == []
    (out / "pages.json").write_text(json.dumps({"pages": [{"id": "p1", "sourceFile": "pages/01-login.html"}]}), encoding="utf-8")
    (out / "layout.json").write_text(json.dumps({"shapes": [{"kind": "image", "src": "assets/canvas-images/missing.webp"}]}), encoding="utf-8")
    missing = export_site.check_references(out, copied)
    assert "pages/01-login.html" in missing
    assert "assets/canvas-images/missing.webp" in missing


def test_check_references_ignores_stale_files_in_out(tmp_path):
    """不带 --clean 时，out 目录里残留的上一轮拷贝不能让本次校验假阳性通过：
    引用必须同时在本次 copied 集合里，且在 out 里精确存在，两者缺一不可。"""
    site = _site(tmp_path)
    out = tmp_path / "dist"
    export_site.copy_site(site, out, clean=True)

    # site 上删掉这个页面（pages.json 仍然引用它），但 out 里上一轮的副本还在
    (site / "pages" / "01-Login.html").unlink()
    copied = export_site.copy_site(site, out, clean=False)
    assert "pages/01-Login.html" not in copied
    assert (out / "pages" / "01-Login.html").exists()  # 残留文件确实还在磁盘上

    missing = export_site.check_references(out, copied)
    assert "pages/01-Login.html" in missing


def test_cli_exits_1_on_missing_reference(tmp_path):
    site = _site(tmp_path)
    (site / "pages.json").write_text(json.dumps({"pages": [{"id": "p1", "sourceFile": "pages/nope.html"}]}), encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(SCRIPTS / "export_site.py"), "--site", str(site), "--out", str(tmp_path / "dist"), "--clean"],
        capture_output=True, text=True,
    )
    assert proc.returncode == 1
    report = json.loads(proc.stdout)
    assert "pages/nope.html" in report["missingRefs"]


def test_cli_reports_broken_json_instead_of_passing_silently(tmp_path):
    """坏掉的 pages.json 被当成「读不到」的话，引用列表为空、报告就是一份漂亮的
    「0 缺失」——恰好放过最该拦住的情况。解析失败必须报出来并让退出码非 0。"""
    site = _site(tmp_path)
    (site / "pages.json").write_text("{ 这不是 json", encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(SCRIPTS / "export_site.py"), "--site", str(site), "--out", str(tmp_path / "dist"), "--clean"],
        capture_output=True, text=True,
    )
    assert proc.returncode == 1
    report = json.loads(proc.stdout)
    assert report["missingRefs"] == []
    assert report["errors"]
    assert any("pages.json" in e for e in report["errors"])


def test_read_json_separates_missing_from_broken(tmp_path):
    """文件不存在是合法的（老站点可能没有 layout.json），不记错误。"""
    errors = []
    assert export_site._read_json(tmp_path / "nope.json", errors) is None
    assert errors == []
    (tmp_path / "bad.json").write_text("{", encoding="utf-8")
    assert export_site._read_json(tmp_path / "bad.json", errors) is None
    assert len(errors) == 1
    assert "bad.json" in errors[0]


def test_cli_refuses_out_that_contains_site(tmp_path):
    """--out 是 --site 的祖先目录时（如 --out . 这类误输），--clean 会把 site 本身
    连同其内容一起 rmtree 掉，之后 site.rglob 静默返回空、产出一份假的「0 缺失」报告。
    目录重叠防呆必须双向：既挡 out 在 site 里面，也挡 out 是 site 的祖先。"""
    x = tmp_path / "x"
    site = x / "prototypes"
    site.mkdir(parents=True)
    (site / "index.html").write_text("<html></html>", encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(SCRIPTS / "export_site.py"), "--site", str(site), "--out", str(x), "--clean"],
        capture_output=True, text=True,
    )
    assert proc.returncode == 2
    report = json.loads(proc.stdout)
    assert "error" in report
    assert site.is_dir()
    assert (site / "index.html").exists()


def test_cli_report_shape(tmp_path):
    site = _site(tmp_path)
    proc = subprocess.run(
        [sys.executable, str(SCRIPTS / "export_site.py"), "--site", str(site), "--out", str(tmp_path / "dist")],
        capture_output=True, text=True,
    )
    assert proc.returncode == 0, proc.stderr
    report = json.loads(proc.stdout)
    assert set(report) >= {"outDir", "fileCount", "totalBytes", "largest", "nonAsciiPaths",
                           "excluded", "missingRefs", "warnings", "errors"}
    assert report["missingRefs"] == []
    assert report["warnings"] == []
    assert report["errors"] == []
    assert report["fileCount"] == len(report["files"])


# ---------------- 相关文档对账 ----------------

def _refs_site(tmp_path, docs, index_files):
    """造一个带 refs/ 的输出目录：docs 是磁盘上的文件，index_files 是索引里列的。"""
    import json as _json

    out = tmp_path / "dist"
    (out / "refs").mkdir(parents=True)
    for name in docs:
        (out / "refs" / name).write_text("<html></html>", encoding="utf-8")
    if index_files is not None:
        (out / "refs-index.json").write_text(
            _json.dumps({"version": "1", "refsDir": "refs",
                         "files": [{"file": n} for n in index_files]}),
            encoding="utf-8")
    return out


def test_check_refs_index_passes_when_in_sync(tmp_path):
    out = _refs_site(tmp_path, ["a.html", "b.html"], ["a.html", "b.html"])
    assert export_site.check_refs_index(out, []) == []


def test_check_refs_index_flags_doc_missing_from_index(tmp_path):
    """索引是静态包里唯一的清单来源，漏了的文档在画布上根本不会出现。"""
    out = _refs_site(tmp_path, ["a.html", "新加的.html"], ["a.html"])
    warnings = export_site.check_refs_index(out, [])
    assert len(warnings) == 1 and "新加的.html" in warnings[0]


def test_check_refs_index_flags_index_entry_without_file(tmp_path):
    out = _refs_site(tmp_path, ["a.html"], ["a.html", "删掉的.html"])
    warnings = export_site.check_refs_index(out, [])
    assert len(warnings) == 1 and "404" in warnings[0]


def test_check_refs_index_flags_missing_index(tmp_path):
    out = _refs_site(tmp_path, ["a.html"], None)
    warnings = export_site.check_refs_index(out, [])
    assert len(warnings) == 1 and "refs-index.json" in warnings[0]


def test_check_refs_index_quiet_on_site_without_refs(tmp_path):
    """没放过相关文档的站点占绝大多数，不该被这条校验吵。"""
    out = tmp_path / "dist"
    out.mkdir()
    assert export_site.check_refs_index(out, []) == []


def test_check_refs_index_ignores_non_html(tmp_path):
    out = _refs_site(tmp_path, ["a.html"], ["a.html"])
    (out / "refs" / "note.md").write_text("# x", encoding="utf-8")
    assert export_site.check_refs_index(out, []) == []
