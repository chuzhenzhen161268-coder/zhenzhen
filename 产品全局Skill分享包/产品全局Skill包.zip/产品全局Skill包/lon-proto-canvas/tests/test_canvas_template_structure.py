"""canvas-template.html 的结构断言。

画布模板是无构建链的单文件静态 HTML，没有 DOM 测试环境。这组测试用纯文本断言
守住关键结构契约：控件 id 存在、CSS 规则存在、已删除的东西确实删干净了。
它抓不到交互 bug，但能抓住「搬 DOM 时漏了一个按钮」「删 sidebar 时留了残余引用」
这类回归，代价是零依赖。
"""
import re
from pathlib import Path

import pytest

REFS = Path(__file__).resolve().parents[1] / "references"
TEMPLATE = REFS / "canvas-template.html"
PARTS = ("canvas-template.html", "canvas.css", "canvas.js")


def _load_all() -> str:
    """壳 + 样式 + 脚本拼成一段文本，原有的子串 / 开窗断言全部照旧。"""
    return "\n".join((REFS / n).read_text(encoding="utf-8") for n in PARTS)


_HTML = _load_all()   # 供下面几条测试在收集阶段生成 parametrize 列表


@pytest.fixture(scope="module")
def html() -> str:
    return _load_all()


@pytest.fixture(scope="module")
def shell() -> str:
    return TEMPLATE.read_text(encoding="utf-8")


def test_dock_container_exists(html):
    assert 'class="dock" id="dock"' in html


@pytest.mark.parametrize("tool", ["select", "pan", "rect", "arrow", "note", "text"])
def test_dock_tool_buttons_exist(html, tool):
    assert f'data-tool="{tool}"' in html


@pytest.mark.parametrize(
    "btn_id",
    ["btnMark", "btnPicker", "btnView", "btnZoomOut", "zoomDisplay", "btnZoomIn"],
)
def test_high_frequency_controls_moved_into_dock(html, btn_id):
    """高频控件必须落在 dock 内：dock 的起止区间里能找到该 id。"""
    dock_start = html.index('id="dock"')
    dock_end = html.index("<!-- /dock -->")
    assert f'id="{btn_id}"' in html[dock_start:dock_end]


@pytest.mark.parametrize("btn_id", ["btnLock", "btnTheme", "btnExport", "btnOrphan"])
def test_low_frequency_controls_stay_in_toolbar(html, btn_id):
    """低频全局操作留在右上 toolbar 内。"""
    tb_start = html.index('id="toolbar"')
    tb_end = html.index("<!-- /toolbar -->")
    assert f'id="{btn_id}"' in html[tb_start:tb_end]


def test_dock_css_uses_only_existing_tokens(html):
    """dock 样式禁止硬编码色值，只能引用已有 CSS 变量（#fff 是既有惯例，放行）。"""
    dock_css_start = html.index("/* ------- Dock")
    dock_css_end = html.index("  .mode-hint {", dock_css_start)
    css = html[dock_css_start:dock_css_end].replace("#fff", "")
    assert "#" not in css, "dock CSS 出现硬编码色值，应改用 var(--...)"


def test_dock_locked_rule_exists(html):
    """锁定态必须同时作用于 dock，否则锁定后注释按钮仍可点。"""
    assert ".dock.locked .dock-btn[data-lock-disable]" in html


def test_canvas_click_ignores_dock(html):
    """打标点击必须忽略落在 dock 上的点击，否则点工具条会打出图钉。"""
    assert 'closest(".dock")' in html


@pytest.mark.parametrize(
    "residue",
    [
        "--sidebar-w",
        "SIDEBAR_W",
        'class="sidebar"',
        'id="pageList"',
        'id="sidebarTitle"',
        'id="sidebarSub"',
        "renderSidebar",
        ".page-item",
        "bindPageObserver",
    ],
)
def test_sidebar_fully_removed(html, residue):
    """sidebar 必须连根删除，任何残留引用都会在运行时报 null。"""
    assert residue not in html


def test_stage_padding_has_no_sidebar_offset(html):
    """stage 左侧留白不再为 sidebar 让位。"""
    start = html.index(".canvas-stage {")
    end = html.index("}", start)
    rule = html[start:end]
    assert "--sidebar-w" not in rule
    assert "padding: 64px;" in rule


def test_pan_overlay_covers_full_viewport(html):
    start = html.index("#panOverlay {")
    end = html.index("}", start)
    assert "left: 0;" in html[start:end]


def test_state_has_tool_field(html):
    assert 'tool: "select"' in html


def test_set_tool_function_exists(html):
    assert "function setTool(tool)" in html


def test_is_typing_is_module_level(html):
    """isTyping 需要被快捷键与空格平移共用，必须是模块级函数。"""
    assert "\nfunction isTyping()" in html


@pytest.mark.parametrize(
    "key,tool",
    [("v", "select"), ("h", "pan"), ("r", "rect"), ("a", "arrow"), ("n", "note"), ("t", "text")],
)
def test_tool_shortcuts_mapped(html, key, tool):
    assert f'"{key}": "{tool}"' in html


def test_mode_hint_clears_dock(html):
    """提示条必须上移，否则被底部 dock 盖住。"""
    start = html.index(".mode-hint {")
    end = html.index("}", start)
    assert "bottom: 78px;" in html[start:end]


def test_shell_has_no_placeholders(shell):
    assert not re.search(r"__[A-Z_]+__", shell)


def test_shell_links_canvas_assets(shell):
    assert '<link rel="stylesheet" href="assets/canvas.css" />' in shell
    assert '<script src="assets/canvas.js"></script>' in shell
    assert "<style" not in shell


def test_data_globals_filled_at_boot(html):
    """数据加载完只落进 state，不另留模块级快照——两份会各自漂移。"""
    start = html.index("async function boot()")
    body = html[start:html.index("\n}", start)]
    assert "loadInitialData()" in body
    assert "applyInitialData(" in body
    assert "renderModeSwitch(" in body
    for residue in ("PAGES", "ANNOTATIONS", "LAYOUT"):
        assert not re.search(rf"\b{residue}\b", html)


def test_frame_block_is_absolutely_positioned(html):
    """内部用 flex column 竖排 iframe + caption，管的是块内子元素排列；.frame-block 本身
    按 position: absolute 定位，不是任何父级 flex 容器的成员——这条由同组的
    test_canvas_row_removed 把守。"""
    start = html.index(".frame-block {")
    end = html.index("}", start)
    rule = html[start:end]
    assert "position: absolute" in rule


def test_canvas_row_removed(html):
    """frame 实例各自带绝对坐标定位，摆放不依赖外层 flex 容器包裹页面行。"""
    assert ".canvas-row" not in html


def test_render_frame_instance_exists(html):
    assert "function renderFrameInstance(" in html


def test_frame_block_carries_instance_id(html):
    assert "data-instance-id" in html


def test_hidden_filters_gone_from_render(html):
    """渲染依据是 layout.frames 的实例列表：isFrameHidden / isPageHidden 不在代码里，
    renderCanvas 自然不引用它们（同文件的 test_hidden_subsystem_fully_removed 单独
    断言这两个函数名整体不出现）。"""
    start = html.index("function renderCanvas(")
    end = html.index("function syncSizer(")
    body = html[start:end]
    assert "isPageHidden" not in body
    assert "isFrameHidden" not in body


def test_layout_endpoint_declared(html):
    assert 'layout: "/api/canvas/layout"' in html
    assert 'annotations: "/api/canvas/annotations"' in html


@pytest.mark.parametrize(
    "fn",
    [
        "function writeLayout()",
        "function writeAnnotations()",
        "function persist(",
        "async function flush(",
        "async function probeServer()",
        "function enterStaticMode()",
        "function applyImport()",
    ],
)
def test_layout_sync_functions_exist(html, fn):
    assert fn in html


def test_orphan_by_missing_instance_exists(html):
    assert "function orphanByMissingInstance()" in html


def test_iframe_pointer_events_default_none(html):
    assert ".frame iframe { pointer-events: none; }" in html


def test_picking_restores_iframe_pointer(html):
    assert "body.picking .frame iframe { pointer-events: auto; }" in html


def test_alt_peek_restores_iframe_pointer(html):
    assert "body.alt-peek .frame iframe { pointer-events: auto; }" in html


def test_alt_peek_cleared_on_blur(html):
    """切换应用时收不到 keyup，不清会永久卡在放开态。"""
    start = html.index("function bindAltPeek()")
    end = html.index("function bindFrameDrag(")
    assert 'window.addEventListener("blur"' in html[start:end]


def test_alt_peek_corrected_by_pointer_events(html):
    """iframe 内 mousedown 会把浏览器焦点切到该 iframe 的 browsing context，松开 Option 后
    keyup 派发给 iframe 文档、window 也没失焦，keyup/blur 两个兜底都到不了父文档；
    只能靠 pointerdown/pointermove 上的 e.altKey 校正当前 alt-peek 状态。"""
    start = html.index("function bindAltPeek()")
    end = html.index("function bindFrameDrag(")
    body = html[start:end]
    assert 'addEventListener("pointerdown"' in body
    assert 'addEventListener("pointermove"' in body
    assert "e.altKey" in body


def test_set_active_toggles_picking_class(html):
    """picking 态必须由 setActive 联动到 body class，否则 bindFrameDrag 里的 picking 判断永远为 false，
    选元素模式下卡片照样能被拖走。"""
    start = html.index("function setActive(on)")
    end = html.index("window.__pickerDeactivate = () => setActive(false);")
    assert "classList.toggle('picking'" in html[start:end]


def test_bind_frame_drag_exists(html):
    assert "function bindFrameDrag(" in html


def test_old_mark_active_pointer_rule_removed(html):
    """mark 模式专用的 iframe 指针规则与三态开关并存会互相打架，只应保留三态开关一条。"""
    assert "#canvasStage.mark-active .frame iframe" not in html


def test_compute_anchor_records_instance_id(html):
    start = html.index("function computeAnchor(")
    end = html.index("function createAnnotation(")
    assert "instanceId: f.dataset.instanceId" in html[start:end]


def test_resolve_pin_position_queries_by_instance(html):
    start = html.index("function resolvePinPosition(")
    end = html.index("function cssEscape(")
    body = html[start:end]
    assert "data-instance-id" in body


@pytest.mark.parametrize(
    "fn",
    [
        "function addFrameInstance(",
        "function removeFrameInstance(",
        "function focusFrameInstance(",
        "function genInstanceId()",
        "function countAnnotationsOn(",
    ],
)
def test_add_panel_functions_exist(html, fn):
    assert fn in html


@pytest.mark.parametrize(
    "residue",
    [
        "hiddenPages",
        "hiddenFrames",
        "function loadHidden()",
        "function writeHidden()",
        "isPageHidden",
        "isFrameHidden",
        "countHiddenFrames",
        "HIDDEN_ENDPOINT",
        "HIDDEN_STORAGE_KEY",
        "refreshHiddenFromServer",
        "pushHiddenToServer",
    ],
)
def test_hidden_subsystem_fully_removed(html, residue):
    """hidden 被 layout 取代，残留会导致两套语义并存。"""
    assert residue not in html


def test_remove_instance_confirms_when_annotated(html):
    start = html.index("function removeFrameInstance(")
    end = html.index("function focusFrameInstance(")
    body = html[start:end]
    assert "countAnnotationsOn" in body
    assert "confirm(" in body


def test_panel_shows_new_badge(html):
    assert "is-new" in html


# =============================================================
#  补测试 A：dock 工具按钮必须有消费点
# =============================================================
# 粗粒度属性解析，只适用于本文件里单行、自封闭属性的 <button ...> 写法（本文件里
# dock 工具按钮都是这样写的）；如果未来写成跨行属性会漏抓，需要时再升级成真正的
# HTML parser。
_DOCK_TOOL_BUTTON_RE = re.compile(r'<button([^>]*)data-tool="(\w+)"([^>]*)>')


def _dock_tool_buttons(html: str) -> list:
    """从 dock 区间提取 [(tool, disabled), ...]。"""
    dock_start = html.index('id="dock"')
    dock_end = html.index("<!-- /dock -->")
    dock_html = html[dock_start:dock_end]
    out = []
    for m in _DOCK_TOOL_BUTTON_RE.finditer(dock_html):
        pre, tool, post = m.groups()
        out.append((tool, "disabled" in pre or "disabled" in post))
    return out


def test_dock_tool_button_set_matches_known_tools(html):
    """先验断言：dock 里的工具按钮集合与下面那条消费点测试预期的一致。谁加/删了工具
    按钮，这条测试会先炸，提醒同步下面的按钮态测试。"""
    tools = {t for t, _ in _dock_tool_buttons(html)}
    assert tools == {"select", "pan", "rect", "arrow", "note", "text", "flow"}


@pytest.mark.parametrize("tool", ["select", "pan", "rect", "note", "text", "arrow", "flow"])
def test_enabled_tool_buttons_are_consumed_by_state_tool(html, tool):
    """未禁用的工具按钮必须在 JS 里有 state.tool 的判断分支消费，否则点了没反应
    （I1 那类「控件存在但没行为」的回归）。"""
    pattern = re.compile(r'state\.tool\s*[!=]==\s*[\'"]' + re.escape(tool) + r'[\'"]')
    assert pattern.search(html), f'state.tool 未见对 "{tool}" 的消费判断'


# =============================================================
#  补测试 B：悬空 DOM 引用
# =============================================================
# 只抓字符串字面量参数（document.getElementById("x") / obj.querySelector('#x')），
# 变量/模板字符串参数（如 getElementById(HL_ID)、querySelector(`.dock-btn[...]`)）
# 匹配不到、也就不会误报——代价是这类动态引用不在本测试覆盖范围内。
# getElementById 只认 document.getElementById(...)：sanitizeAnnotationHtml() 里的
# doc.getElementById(...) 查的是 DOMParser 现造的临时文档，不是页面自身的 DOM，
# 混进来会产生假阳性（该临时文档给 id 用的是单引号，和页面真实控件的 id 定义无关）。
_DOC_GET_ELEMENT_BY_ID_RE = re.compile(r'document\.getElementById\(\s*["\']([A-Za-z0-9_-]+)["\']\s*\)')
_QUERY_SELECTOR_ID_RE = re.compile(r'\.querySelector\(\s*["\']#([A-Za-z0-9_-]+)["\']\s*\)')


def _referenced_dom_ids(html: str) -> set:
    return set(_DOC_GET_ELEMENT_BY_ID_RE.findall(html)) | set(_QUERY_SELECTOR_ID_RE.findall(html))


@pytest.mark.parametrize("dom_id", sorted(_referenced_dom_ids(_HTML)))
def test_referenced_dom_ids_exist(html, dom_id):
    """JS 里 document.getElementById(...) / xxx.querySelector('#id') 引用的 id，
    必须在 HTML 里真实存在，否则运行时拿到 null——删控件类改动最典型的运行时炸点。"""
    assert f'id="{dom_id}"' in html or f"id='{dom_id}'" in html


def test_view_panel_stays_off_theme_tokens(html):
    """添加面板固定白底、不跟随主题，区间内的颜色规则禁止引用会随主题切换的 token，
    否则暗色模式下会出现白底白字或对比度不足（I2 那类回归）。"""
    start = html.index(".view-panel {")
    end = html.index(".view-empty {", start)
    css = html[start:end]
    for token in ("var(--text)", "var(--text-mute)", "var(--hover-overlay)"):
        assert token not in css, f"{token} 出现在固定白底的添加面板 CSS 里"


# ---------- 图形层 ----------

def test_shape_layer_css_exists(html):
    """图形与箭头各有自己的层，z-index 显式声明，不靠 DOM 顺序。"""
    assert ".shape-block {" in html
    assert ".arrow-layer {" in html


def test_render_split_into_frames_and_shapes(html):
    """渲染必须拆开：画一个图形不能触发 iframe 重建。"""
    assert "function renderFrames()" in html
    assert "function renderShapes()" in html


def test_render_shapes_does_not_touch_frame_blocks(html):
    """renderShapes 的清理范围只能是图形层自己的元素。"""
    start = html.index("function renderShapes()")
    body = html[start:start + 1100]
    assert ".shape-block" in body
    assert "frame-block" not in body


def test_rect_tool_button_enabled(html):
    """方框按钮解禁：dock 里的方框按钮不再带 disabled。"""
    i = html.index('id="toolRect"')
    assert "disabled" not in html[i:html.index(">", i)]


def test_set_tool_has_no_disabled_property_access(html):
    """setTool 改用属性存在性判断，不再读 btn.disabled。"""
    start = html.index("function setTool(tool)")
    body = html[start:start + 700]
    assert "btn.disabled" not in body


def test_shape_delete_guarded_by_is_typing(html):
    """Delete / Backspace 删对象时必须让位给文字输入。"""
    start = html.index('e.key === "Delete" || e.key === "Backspace"')
    assert "isTyping()" in html[max(0, start - 600):start]


def test_rect_draft_cleans_up_on_pointercancel(html):
    """手势被系统打断时草稿元素与监听都要清掉。

    锚点是方框分支自己的入口而不是 bindShapeCreate：便签 / 文字 / 箭头的分派都排在
    方框之前，从函数头开窗会先扫到箭头分支的 pointercancel，方框这边删光了也照样绿。
    窗口 1900 恰好罩住整个方框分支，注册与注销两处都要在，只留一处不算数。
    """
    start = html.index('if (state.tool !== "rect")')
    body = html[start:start + 1900]
    assert body.count("pointercancel") >= 2


@pytest.mark.parametrize("d", ["nw", "n", "ne", "e", "se", "s", "sw", "w"])
def test_resize_dirs_cover_eight_directions(html, d):
    """八向手柄的系数表必须八个方向齐全。

    行首锚定而不是子串包含：`e` 是 `ne` / `se` 的后缀、`w` 是 `sw` 的后缀，
    用 `in` 判定会让这两个方向的用例永远为真，丢掉回归防线。
    """
    start = html.index("const RESIZE_DIRS")
    window = html[start:start + 400]
    assert re.search(rf"^\s+{d}:\s*\{{", window, re.M)


def test_resize_clamps_to_minimum(html):
    """缩放必须钳最小尺寸，否则能把图形拖成 0 尺寸再也点不中。"""
    start = html.index("function bindShapeResize")
    body = html[start:start + 1800]
    assert "SHAPE_MIN_W" in body
    assert "SHAPE_MIN_H" in body


def test_resize_cleans_up_on_pointercancel(html):
    start = html.index("function bindShapeResize")
    assert "pointercancel" in html[start:start + 1800]


def test_note_reuses_shape_resize(html):
    """缩放对「非文字」的图形一律生效：便签也要能缩放，条件写成 === "rect" 就会漏掉它。"""
    assert 'if (sh.kind !== "text") bindShapeResize' in html


def test_esc_level1_uses_editing_shape_id_not_is_typing(html):
    """ESC 第 1 级必须认 editingShapeId 这个专有标志，用 isTyping() 会吃掉标注编辑卡的 ESC。"""
    start = html.index('if (e.key === "Escape")')
    chain = html[start:start + 800]
    assert chain.index("state.editingShapeId") < chain.index('state.mode === "mark"')
    assert "isTyping()" not in chain


def test_shape_text_edit_defers_focus_one_frame(html):
    """contenteditable 要延一帧 focus，否则被浏览器默认焦点处理抢走。"""
    start = html.index("function beginShapeTextEdit")
    assert "requestAnimationFrame" in html[start:start + 900]


def test_shape_text_read_write_is_plaintext_only(html):
    """图形文本只走纯文本读写，不给 innerHTML 留入口。"""
    start = html.index("function commitShapeTextEdit")
    body = html[start:start + 900]
    assert "readEditableText" in body
    assert "innerHTML" not in body
    reader = html.index("function readEditableText")
    assert "innerHTML" not in html[reader:reader + 400]
    render_start = html.index("function renderShapeBlock")
    assert "txt.textContent = sh.text" in html[render_start:render_start + 2400]


def test_editable_text_read_preserves_line_breaks(html):
    """contenteditable 的换行是 <br> / 块级边界，读值必须走 innerText 才留得住。"""
    reader = html.index("function readEditableText")
    body = html[reader:reader + 400]
    assert "innerText" in body
    for commit in ("function commitShapeTextEdit", "function commitArrowLabelEdit"):
        start = html.index(commit)
        assert "readEditableText" in html[start:start + 900]


def test_enter_inserts_line_break_instead_of_browser_default(html):
    """Enter 走 insertLineBreak，不让浏览器拆出嵌套 <div>。"""
    render_start = html.index("function renderShapeBlock")
    render_body = html[render_start:render_start + 2400]
    assert '"keydown"' in render_body
    assert 'insertLineBreak' in render_body
    label_start = html.index("function ensureArrowLabelEl")
    assert "insertLineBreak" in html[label_start:label_start + 1600]


def test_paste_listener_bound_at_element_creation(html):
    """paste 监听绑在渲染时，不能绑在 beginShapeTextEdit 里累积。"""
    render_start = html.index("function renderShapeBlock")
    render_body = html[render_start:render_start + 2200]
    assert '"paste"' in render_body
    begin_start = html.index("function beginShapeTextEdit")
    assert '"paste"' not in html[begin_start:begin_start + 900]


@pytest.mark.parametrize("color", ["yellow", "pink", "blue", "green"])
def test_note_palette_has_four_colors(html, color):
    """便签色板四色齐全，与 layout.json 契约一致。"""
    start = html.index("const NOTE_COLORS")
    assert color in html[start:start + 400]


@pytest.mark.parametrize("tool", ["Note", "Text"])
def test_note_and_text_buttons_enabled(html, tool):
    """便签与文字按钮解禁：dock 里的按钮不再带 disabled。"""
    i = html.index(f'id="tool{tool}"')
    assert "disabled" not in html[i:html.index(">", i)]


def test_empty_text_shape_is_not_persisted_on_create(html):
    """空文字对象不落盘：创建时不写，由 commit 决定写入还是删除。"""
    start = html.index('if (state.tool === "text")')
    body = html[start:start + 550]      # 只覆盖 text 分派块本身，不越进相邻分支
    assert "beginShapeTextEdit" in body
    assert "writeLayout()" not in body


def test_arrow_tool_button_enabled(html):
    """箭头按钮解禁：dock 里的箭头按钮不再带 disabled。"""
    i = html.index('id="toolArrow"')
    assert "disabled" not in html[i:html.index(">", i)]


def test_arrow_follows_frame_drag(html):
    """拖卡片时箭头要跟着重算，且走只改几何的轻路径，不能整层重建。
    卡片与图形共用同一条位移路径，断言落在 beginGroupDrag 身上。"""
    start = html.index("function beginGroupDrag()")
    body = html[start:html.index("function prepareSelectionForDrag(", start)]
    assert "refreshArrowGeometry()" in body
    assert "renderShapes()" not in body


def test_arrow_follows_iframe_autoresize(html):
    """iframe 自适应撑高会改变卡片高度，绑在下边 / 侧边的端点要跟着重算。"""
    start = html.index('data.type !== "canvas-frame-ready"')
    body = html[start:html.index("function findFrameMeta", start)]
    assert "refreshArrowGeometry()" in body


def test_arrow_geometry_refresh_does_not_rebuild(html):
    start = html.index("function refreshArrowGeometry")
    assert "createElementNS" not in html[start:start + 1200]


def test_detach_runs_before_frames_filtered(html):
    """端点降级必须在实例被过滤掉之前跑，否则算不出它的坐标。"""
    start = html.index("function removeFrameInstance")
    body = html[start:start + 1800]
    assert body.index('detachArrowsFromHost("instanceId"') < body.index("state.frames = state.frames.filter")


def test_export_produces_canvas_state_file(html):
    """导出扩为整份画布状态，四个数组齐全；下载动作走共用的 downloadJson。"""
    start = html.index("function exportCanvasState")
    body = html[start:html.index("\nfunction ", start + 10)]
    assert 'downloadJson("canvas-state.json"' in body
    for field in ["annotations", "orphans", "frames", "shapes"]:
        assert field in body
    dl = html.index("function downloadJson(")
    assert "a.download = name;" in html[dl:html.index("\nfunction ", dl + 10)]


def test_import_button_in_toolbar(html):
    tb_start = html.index('id="toolbar"')
    tb_end = html.index("<!-- /toolbar -->")
    assert 'id="btnImport"' in html[tb_start:tb_end]


def test_import_report_shows_both_sides(html):
    """导入整体覆盖，动手前让用户看到双方条数、导出时间与覆盖语义。"""
    start = html.index("function renderImportReport(")
    body = html[start:html.index("function showImportError(", start)]
    assert "state[key].length" in body
    assert "info.incoming[key].length" in body
    assert "generatedAt" in body
    assert "不做合并" in body


def test_import_validates_arrays(html):
    """导入数据每个字段都要验型并滤掉畸形条目：覆盖式没有第二道关口，
    脏数据进了 state 就直接落盘。"""
    start = html.index("function analyzeImport(")
    body = html[start:html.index("function renderImportReport(", start)]
    assert "Array.isArray(data[key])" in body
    assert 'typeof x.id === "string"' in body


def test_import_is_wholesale_not_merge(html):
    """导入语义是覆盖：四个数组整体替换，不做按 id 合并。"""
    assert "mergeCanvasState" not in html
    start = html.index("function applyImport()")
    body = html[start:html.index("function bindImportModal(", start)]
    assert "for (const key of IMPORT_KEYS) state[key] = info.incoming[key];" in body


def test_import_modal_has_drop_zone_and_actions(html):
    """导入走弹窗：拖放区 + 报告区 + 取消 / 确认，不再用原生 confirm。"""
    start = html.index('id="importModal"')
    body = html[start:start + 1200]
    for el in ('id="importDrop"', 'id="importReport"', 'id="importCancel"',
               'id="importConfirm"', 'id="importReset"', 'id="importClose"'):
        assert el in body, el
    assert "function bindImportModal()" in html
    assert 'drop.addEventListener("drop"' in html


def test_import_modal_warns_in_static_mode(html):
    """静态副本上导入只进内存，弹窗里必须说，否则有人以为已经存下了。"""
    start = html.index("function renderImportReport(")
    body = html[start:html.index("function showImportError(", start)]
    assert "!state.serverMode" in body
    assert "刷新即丢" in body


def test_canvas_drop_intercepts_every_file(html):
    """拖任意文件进画布都要 preventDefault：不拦浏览器就把它当导航目标打开，
    画布连同未落盘的改动一起被替换掉。"""
    start = html.index('scroll.addEventListener("drop"')
    body = html[start:start + 700]
    assert body.index("e.preventDefault();") < body.index("pickImageFile(")
    assert "pickJsonFile(" in body


def test_export_binding_points_to_canvas_state(html):
    assert "exportAnnotations" not in html


# ---------- 交互模式互斥 ----------

def test_set_tool_blocks_shape_tools_when_locked(html):
    """锁定态下图形工具不能生效：data-lock-disable 只是 CSS，拦不住 R / A / N / T 快捷键。
    select / pan 必须放行，否则 ESC 回 select、画完自动回 select 这两条路径会卡死。"""
    start = html.index("function setTool(tool)")
    body = html[start:start + 900]
    assert re.search(
        r'state\.locked && tool !== "select" && tool !== "pan"\)\s*return', body
    )


@pytest.mark.parametrize("tool", ["rect", "arrow", "note", "text"])
def test_shape_tool_buttons_are_lock_disabled(html, tool):
    """四个图形按钮在锁定态要跟着变灰失效，不能看着可点、点了什么都不发生。

    先切到 dock 区间再找：CSS 里的 body[data-tool="rect"] 排在按钮前面，
    从整份文档找第一处会落到那条选择器上。
    """
    dock = html[html.index('id="dock"'):html.index("<!-- /dock -->")]
    i = dock.index(f'data-tool="{tool}"')
    tag = dock[dock.rindex("<button", 0, i):dock.index(">", i)]
    assert "data-lock-disable" in tag


def test_lock_css_targets_dock(html):
    """按钮上的 data-lock-disable 要有对应的 CSS，且 .dock 本身会被打上 locked。"""
    assert ".dock.locked .dock-btn[data-lock-disable]" in html
    assert 'getElementById("dock").classList.toggle("locked"' in html


def test_lock_marks_body_and_freezes_frame_cursor(html):
    """锁定态要落到 body 上：添加面板 / 孤儿抽屉不在 toolbar 与 dock 内，
    只靠那两处 class 够不到它们；frame 卡片锁定后不能再显示抓手。"""
    assert 'document.body.classList.toggle("locked"' in html
    assert "body.locked .frame-block" in html
    assert 'body.locked .view-add-btn[data-action="add-instance"]' in html
    assert 'body.locked .view-add-btn[data-action="remove-instance"]' in html
    assert "body.locked .orphan-drawer [data-act]" in html


@pytest.mark.parametrize(
    "anchor, window",
    [
        ("function bindFrameDrag(block)", 400),
        ("function addFrameInstance(", 120),
        ("function removeFrameInstance(", 120),
        ("function applyImport()", 120),
    ],
)
def test_mutation_entries_guard_locked(html, anchor, window):
    """每个会写盘的入口都要在函数体里挡 state.locked，不能只靠按钮变灰。"""
    start = html.index(anchor)
    assert "if (state.locked) return;" in html[start:start + window]


def test_orphan_drawer_guards_locked_and_rearms(html):
    """孤儿抽屉的 click 监听是 once：锁定早退必须重挂，否则抽屉点一次就死。"""
    start = html.index("function orphanDrawerClick")
    body = html[start:html.index("function isTyping", start)]
    assert "if (state.locked) { renderOrphanDrawer(); return; }" in body
    assert "if (state.locked) return;" not in body


def test_frame_drag_resolves_instance_by_id(html):
    """拖拽处理不能闭包持有 inst 对象：撤销会整体替换 state.frames，
    旧引用会让下一次拖拽写不进 state。按 data-instance-id 现查。"""
    assert "bindFrameDrag(block, inst)" not in html
    assert "bindFrameDrag(block);" in html


# ---------- 撤销 / 重做 ----------

def test_history_buttons_live_in_dock(html):
    dock = html[html.index('id="dock"'):html.index("<!-- /dock -->")]
    for btn_id in ("btnUndo", "btnRedo"):
        i = dock.index(f'id="{btn_id}"')
        tag = dock[dock.rindex("<button", 0, i):dock.index(">", i)]
        assert "data-lock-disable" in tag


def test_writers_schedule_history(html):
    """history 挂在两个领域层 writer 上，不挂传输层 persist。"""
    for fn in ("function writeLayout()", "function writeAnnotations()"):
        start = html.index(fn)
        assert "historySchedule()" in html[start:start + 300]


def test_undo_flushes_history_before_shift(html):
    """收口编辑态产生的写入排在微任务里，pop 之前必须同步 flush，
    否则用户刚提交的那笔既被吃掉又无法 redo。"""
    for fn in ("function undoCanvas()", "function redoCanvas()"):
        start = html.index(fn)
        body = html[start:start + 400]
        assert body.index("settleEditing()") < body.index("historyFlush()") < body.index("historyShift(")


def test_restore_replaces_only_changed_arrays(html):
    """没变的那层 DOM 不重建，其闭包还指着原对象；整体换掉会让下一次拖拽写进游离对象。"""
    start = html.index("function restoreSnapshot(snap)")
    body = html[start:start + 1200]
    assert "if (framesChanged) state.frames = JSON.parse(snap.f);" in body
    assert "if (shapesChanged) state.shapes = JSON.parse(snap.s);" in body
    assert "if (snap.a !== before.a) state.annotations = JSON.parse(snap.a);" in body
    assert "if (snap.o !== before.o) state.orphans = JSON.parse(snap.o);" in body


def test_new_annotation_is_one_history_step(html):
    """新建时的空钉不入栈，编辑卡关闭时同步入栈：撤销不会停在一个空钉上。"""
    start = html.index("function createAnnotation(")
    assert "withoutHistory(writeAnnotations);" in html[start:start + 900]
    start = html.index("function closeCurrentCard()")
    assert "historyFlush();" in html[start:start + 400]


def test_picker_resets_tool_before_activating(html):
    """开 picker 前把工具归位：否则点卡片进 iframe 拾元素、点空白却画出一个图形。"""
    start = html.index("btn.addEventListener('click'")
    body = html[start:start + 500]
    assert "setTool('select')" in body


def test_mark_mode_resets_tool(html):
    """进打标模式前归位工具，否则画布保持十字光标，盖掉打标模式的气泡光标。"""
    start = html.index('getElementById("btnMark").addEventListener')
    body = html[start:start + 400]
    assert 'setTool("select")' in body
    assert body.index('setTool("select")') < body.index("enterMarkMode()")


def _rule_block(html: str, selector: str) -> str:
    """取该选择器所在那条规则的声明块：从选择器出现处扫到下一个 `}`。

    只断言选择器在不在，守不住这条规则做了什么——把 none 改成 auto 照样绿。
    多个选择器共用一个声明块时，任一条都会扫到同一个块。
    """
    i = html.index(selector)
    return html[i:html.index("}", i)]


def test_shapes_yield_pointer_in_picking_and_alt_peek(html):
    """指针权三态开关：picking / alt-peek 两态下，压在卡片上的图形连同它的子元素
    一起让出指针，否则 iframe 那块区域选不了元素、也复制不了原型里的文字。"""
    for sel in ("body.picking .shape-block", "body.alt-peek .shape-block"):
        for full in (sel + ",", sel + " *"):
            assert full in html
            assert re.search(r"pointer-events:\s*none", _rule_block(html, full)), \
                f"{full} 所在规则没有把指针让出去"


def test_arrows_yield_pointer_in_picking_and_alt_peek(html):
    """箭头的 .arrow-hit 是 14px 的透明加粗描边，而箭头的用途就是连两张卡片，
    命中带横跨卡片是常态：两态下它与端点手柄要一起让开，否则同样吞掉指针权。"""
    for sel in ("body.picking .arrow-layer", "body.alt-peek .arrow-layer"):
        for full in (sel + ",", sel + " *"):
            assert full in html
            assert re.search(r"pointer-events:\s*none", _rule_block(html, full)), \
                f"{full} 所在规则没有把指针让出去"


# ---------- 图形层与导出徽标 ----------

def test_export_badge_counts_all_four_arrays(html):
    """徽标数的是导出文件里的条数，四部分都要算：只数标注会让画满图形的画布显示 0。"""
    start = html.index("function refreshBadges")
    body = html[start:start + 700]
    for field in ["annotations.length", "orphans.length", "frames.length", "shapes.length"]:
        assert field in body


def test_persist_marks_dirty_in_static_mode(html):
    """静态模式下改动只在内存、回流全靠导出：徽标必须跟着亮。"""
    start = html.index("function persist(")
    body = html[start:html.index("async function flush(", start)]
    assert "if (!state.serverMode)" in body
    assert "state.dirty = true" in body
    assert "refreshBadges()" in body


def test_shape_text_edit_guards_reentry(html):
    """编辑态下在文字上再双击会冒泡回来，重入会多挂一个 blur 监听并把选区改成全选。"""
    start = html.index("function beginShapeTextEdit")
    body = html[start:start + 700]
    assert "state.editingShapeId === shapeId" in body
    assert body.index("state.editingShapeId === shapeId") < body.index("findShape(shapeId)")


@pytest.mark.parametrize(
    "fn,end",
    [
        ("function applyImport()", "function bindImportModal("),
    ],
)
def test_shape_selection_cleared_on_wholesale_replace(html, fn, end):
    """整体替换 state.shapes 的路径都要清选中与编辑态，否则它们指向已经不存在的图形。

    右界用下一个函数的定义而不是定长窗口：这两条清理在两个相邻函数里长得一模一样，
    定长窗口会随函数变长而读到邻居的副本，把自己变成永真。
    """
    start = html.index(fn)
    body = html[start:html.index(end, start)]
    assert "clearSelection()" in body or "pruneSelection()" in body
    assert "state.editingShapeId = null" in body


# ---------- 方框：圈住而不是盖住 ----------

def test_rect_interior_is_pointer_transparent(html):
    """方框的语义是圈住一组卡片：内部整片让出指针，被圈住的卡片照常拖得动。"""
    assert re.search(
        r'\.shape-block\[data-kind="rect"\]\s*\{[^}]*pointer-events:\s*none', html
    )


def test_rect_hit_ring_takes_pointer_back(html):
    """让出指针后，命中靠压在边框上的四条透明边条 + 八个手柄 + 文字，缺一样方框就选不中。"""
    assert re.search(r'\.shape-hit-edge\s*\{[^}]*pointer-events:\s*auto', html)
    assert re.search(r'\.sh-handle\s*\{[^}]*pointer-events:\s*auto', html)
    assert re.search(r'\.shape-block \.shape-text\s*\{[^}]*pointer-events:\s*auto', html)
    for edge in ("t", "r", "b", "l"):
        assert f'.shape-hit-edge[data-edge="{edge}"]' in html


def test_shape_drag_listens_on_document(html):
    """方框内部让出指针后，光标一离开命中环，事件就不再经过图形本身：拖拽期的
    pointermove / up 必须挂 document，挂在图形上会等不到超过阈值的那一下，拖不动。"""
    start = html.index("function startGroupDragGesture(e, opts)")
    body = html[start:html.index("function bindShapeDrag(el, sh)", start)]
    for ev in ("pointermove", "pointerup", "pointercancel"):
        assert f'document.addEventListener("{ev}"' in body
        assert f'el.addEventListener("{ev}"' not in body


def test_rect_renders_hit_edges(html):
    """四条边条由 renderShapeBlock 建出来，且只给方框建——便签有实心底色，盖住是对的。"""
    start = html.index("function renderShapeBlock")
    body = html[start:html.index("function selectShape(", start)]
    assert 'sh.kind === "rect"' in body
    assert '"shape-hit-edge"' in body


def test_empty_shape_text_leaves_no_hit_spot(html):
    """空文本不占命中区：居中的空文本元素会在方框正中间留一小片挡住卡片的死角。"""
    assert re.search(
        r'\.shape-block \.shape-text:empty\s*\{[^}]*pointer-events:\s*none', html
    )


# ---------- 图形文字：不跟画布主题走 ----------

def test_shape_text_plate_stays_off_theme_tokens(html):
    """rect / text 的字压在 iframe 上，而 iframe 里的原型底色不跟画布主题变：
    字色跟着 --text 走，暗色主题下就是近白字压白底。"""
    start = html.index('.shape-block[data-kind="rect"] .shape-text,')
    css = html[start:html.index("}", start)]
    assert "var(--text)" not in css
    assert "#171717" in css
    assert "background: rgba(255, 255, 255" in css


def test_shape_text_base_rule_has_no_theme_color(html):
    """公共文字规则不能再回填主题色，否则会盖掉上面那条固定色。"""
    start = html.index(".shape-block .shape-text {")
    css = html[start:html.index("}", start)]
    assert "color:" not in css


def test_empty_shape_text_has_no_plate(html):
    """方框可以合法地不带文字，那时它应该是干净的一个框，不能留一块突兀的色块。"""
    start = html.index('.shape-block[data-kind="rect"] .shape-text:empty,')
    css = html[start:html.index("}", start)]
    assert "background: transparent" in css


# ---------- 命中层 ----------

def test_shape_create_listens_on_sizer(html):
    """画布空白区要能起笔：stage 的命中盒只有 padding 那一小块，宿主必须是 sizer。"""
    start = html.index("function bindShapeCreate()")
    body = html[start:start + 600]
    assert 'getElementById("canvasSizer")' in body
    assert 'stage.addEventListener("pointerdown"' not in body


def test_canvas_click_listens_on_sizer(html):
    """注释与重挂模式同理：空白区点击必须收得到。"""
    start = html.index("function bindCanvasClick()")
    body = html[start:start + 600]
    assert 'getElementById("canvasSizer")' in body
    assert 'stage.addEventListener("click"' not in body


def test_canvas_click_keeps_stage_as_coordinate_base(html):
    """宿主换了，坐标基准不能跟着换：仍要以 stage 的 rect 换算。"""
    start = html.index("function bindCanvasClick()")
    body = html[start:start + 1200]
    assert "stage.getBoundingClientRect()" in body


@pytest.mark.parametrize("tool", ["rect", "note", "text", "arrow"])
def test_tool_cursor_covers_blank_canvas(html, tool):
    """十字光标要盖住整片可画区域，否则空白区没有「现在能画」的提示。"""
    assert f'body[data-tool="{tool}"] .canvas-sizer' in html


# ---------- 对齐参考线 ----------

def test_guide_layer_exists(html):
    """参考线自成一层，不复用箭头层：箭头层每次 renderShapes 都整体重建。"""
    assert 'id="guideLayer"' in html
    assert ".guide-layer {" in html


def test_guide_layer_never_takes_pointer(html):
    """参考线只是视觉提示，吃掉指针会让拖拽中途断掉。"""
    start = html.index(".guide-layer {")
    css = html[start:html.index("}", start)]
    assert "pointer-events: none" in css


def test_guide_line_stroke_does_not_scale(html):
    """stage 处在 transform:scale 下，不加 non-scaling-stroke 的话缩小后线会细到看不见。"""
    start = html.index(".guide-line {")
    css = html[start:html.index("}", start)]
    assert "vector-effect: non-scaling-stroke" in css


def test_align_module_functions_exist(html):
    for fn in ("function shapeBox(sh)", "function beginAlign(", "function applyAlign(",
               "function renderGuides(", "function endAlign()"):
        assert fn in html


def test_align_threshold_is_zoom_compensated(html):
    """阈值是屏幕像素，必须除以 zoom 再和画布坐标比，否则缩放下手感会飘。"""
    start = html.index("function applyAlign(")
    body = html[start:start + 600]
    assert "ALIGN_THRESHOLD / state.zoom" in body


def test_align_skips_arrows(html):
    """箭头没有矩形包围盒语义，不能进候选集。"""
    start = html.index("function beginAlign(")
    body = html[start:start + 800]
    assert 'kind === "arrow"' in body


def test_frame_drag_uses_align(html):
    """卡片拖拽走与图形同一条手势，对齐参考线因此不必在两处各写一遍。"""
    start = html.index("function bindFrameDrag(block)")
    body = html[start:html.index("//  空格 + 拖动平移", start)]
    assert "startGroupDragGesture(e, {" in body


def test_shape_drag_uses_align(html):
    """整组拖动时自己人不参与吸附，否则参考线会打在组内成员之间、永远命中。"""
    start = html.index("function startGroupDragGesture(e, opts)")
    body = html[start:html.index("function bindShapeDrag(el, sh)", start)]
    assert "beginAlign(group.ids)" in body
    assert "applyAlign(" in body
    assert "endAlign()" in body


def test_drag_cleanup_clears_guides(html):
    """手势被打断也要清线，否则红线会留在画布上直到下次拖拽。"""
    start = html.index("function startGroupDragGesture(e, opts)")
    body = html[start:html.index("function bindShapeDrag(el, sh)", start)]
    cleanup = body[body.index("const cleanup = () => {"):]
    assert "endAlign()" in cleanup[:cleanup.index("};")]


# ---------- 箭头路由 ----------

def test_arrow_path_takes_point_list(html):
    assert "function arrowPath(points, headLen)" in html


def test_arrow_head_angle_uses_last_segment(html):
    """折线下用首尾连线算箭羽角度会指错方向，必须取最后一段。"""
    start = html.index("function arrowPath(points, headLen)")
    body = html[start:start + 700]
    assert "points[points.length - 2]" in body


def test_arrow_points_is_single_routing_entry(html):
    """渲染与几何刷新都必须走同一个路由出口，否则两条路径会画出不同的线。"""
    assert "function arrowPoints(sh)" in html
    for fn in ("function renderArrow(sh, layer)", "function refreshArrowGeometry()"):
        start = html.index(fn)
        body = html[start:start + 1200]
        assert "arrowPoints(" in body


def test_elbow_routing_exists(html):
    start = html.index("function arrowPoints(sh)")
    body = html[start:start + 1400]
    assert "endAxis(sh.from" in body
    assert "endAxis(sh.to" in body


def test_legacy_arrows_stay_straight(html):
    """老数据没有 route 字段，必须按直线渲染，既有画布外观不能变。"""
    start = html.index("function arrowPoints(sh)")
    body = html[start:start + 600]
    assert 'if (sh.route !== "elbow") return [p1, p2];' in body


def test_mid_is_clamped(html):
    """折点比例贴到 0 或 1 时中段会退化成零长度，手柄再也抓不住。"""
    assert "function clampMid(v)" in html
    start = html.index("function clampMid(v)")
    body = html[start:start + 300]
    assert "ARROW_MID_MIN" in body and "ARROW_MID_MAX" in body


def test_new_arrow_route_follows_panel(html):
    """落笔的路由取箭头面板当前选择，非法值兜回折线。"""
    start = html.index('if (state.tool === "arrow")')
    body = html[start:start + 700]
    assert 'route: state.arrowRoute === "straight" ? "straight" : "elbow"' in body


def test_arrow_route_defaults_to_elbow(html):
    """画流程是主场景，站点起手默认折线。"""
    assert 'arrowRoute: "elbow"' in html


def test_arrow_handles_are_addressed_by_role(html):
    """折点手柄加进来后，按下标取手柄会串位，必须按 data 属性精确定位。"""
    start = html.index("function refreshArrowGeometry()")
    body = html[start:start + 1600]
    assert '.arrow-handle[data-end="from"]' in body
    assert '.arrow-handle[data-role="mid"]' in body


def test_shape_toolbar_exists(html):
    assert 'id="shapeToolbar"' in html
    assert ".shape-toolbar {" in html


def test_set_tool_refreshes_shape_toolbar(html):
    """画完图形的收尾是「先 renderShapes 再 setTool("select")」，setTool 不重算浮条的话，
    新落的图形要等下一次选中才等到自己的浮条。"""
    start = html.index("function setTool(tool)")
    body = html[start:html.index("function bindDockTools()", start)]
    assert "syncShapeToolbar();" in body


def test_shape_toolbar_locks_width(html):
    """stage 的命中盒只有 padding 撑出的一小块，浮条不锁宽会被 shrink-to-fit
    压成一列一个字。"""
    start = html.index(".shape-toolbar {")
    css = html[start:html.index(".shape-toolbar[hidden]", start)]
    assert "width: max-content;" in css


def test_shape_toolbar_serves_nodes_only(html):
    """浮条只服务图形节点：箭头的路由归 dock 面板，标签走双击线，选中箭头不冒浮条。"""
    start = html.index("function syncShapeToolbar()")
    body = html[start:html.index("function applyShapeVariant(", start)]
    assert "!NODE_KINDS.includes(sh.kind)" in body
    assert "data-route" not in html
    assert 'data-act="label"' not in html


def test_shape_swap_keeps_geometry(html):
    """换形状只改轮廓：位置尺寸文字都留着，否则等于删了重画。"""
    start = html.index("function applyShapeVariant(id, v)")
    body = html[start:html.index("function bindShapeToolbar()", start)]
    for banned in ("sh.x =", "sh.y =", "sh.w =", "sh.h =", "sh.text ="):
        assert banned not in body, banned
    assert "renderShapes();" in body
    assert "refreshArrowGeometry();" in body


def test_shape_picker_dedupes_variants(html):
    """切换器是去重全集：同一轮廓不为两种叫法排两个格子。"""
    start = html.index("const SHAPE_ALL_ORDER")
    body = html[start:html.index(";", start)]
    assert "GEO_ORDER.concat(" in body
    assert "!GEO_ORDER.includes(v)" in body


def test_ports_only_on_node_kinds(html):
    """便签四边外侧被色板占着、文字图形没有稳定包围盒，都不长连接点。"""
    start = html.index("const NODE_KINDS")
    body = html[start:html.index(";", start)]
    assert '"flow"' in body and '"rect"' in body
    assert '"note"' not in body and '"text"' not in body
    assert "NODE_KINDS.includes(sh.kind)" in html


def test_port_click_creates_linked_node(html):
    """点连接点 = 落一个同型节点 + 一条连上两端的折线箭头。"""
    start = html.index("function createLinkedNode(src, side)")
    body = html[start:html.index("function bindShapePorts(el, sh)", start)]
    assert "from: { shapeId: src.id, anchor: side }" in body
    assert "to: { shapeId: sh.id, anchor: OPPOSITE_SIDE[side] }" in body
    assert 'route: "elbow"' in body
    assert "beginShapeTextEdit(sh.id)" in body


def test_port_drag_falls_back_to_arrow(html):
    """超过阈值是拉线、没超过才是接节点，两种手势共用一次 pointerdown。"""
    start = html.index("function bindShapePorts(el, sh)")
    body = html[start:start + 2600]
    assert "createLinkedNode(sh, side)" in body
    assert "snapToTarget(p, arrow.id)" in body


def test_port_ghost_is_not_persisted(html):
    """落点预览是纯视觉元素：不进 state.shapes，也不能触发落盘。"""
    start = html.index("function showPortGhost(src, side)")
    body = html[start:html.index("function createLinkedNode(src, side)", start)]
    assert "state.shapes.push" not in body
    assert "writeLayout" not in body


def test_arrow_label_layer_exists(html):
    assert 'id="arrowLabelLayer"' in html
    assert ".arrow-label-layer {" in html
    assert ".arrow-label {" in html


def test_arrow_label_edit_entries(html):
    """双击线与浮条按钮是同一个入口，空标签提交等于删掉。"""
    start = html.index("function renderArrow(sh, layer)")
    body = html[start:start + 1600]
    assert "beginArrowLabelEdit(sh.id)" in body
    commit = html.index("function commitArrowLabelEdit()")
    cbody = html[commit:commit + 900]
    assert "delete sh.label" in cbody
    assert "el.remove()" in cbody


def test_arrow_label_follows_geometry(html):
    """标签压在线中段上，线一动就得跟着走，落位与浮条共用一份中点算法。"""
    start = html.index("function refreshArrowGeometry()")
    body = html[start:start + 1800]
    assert "syncArrowLabelPos(sh)" in body
    assert "function arrowMidPoint(sh)" in html
    sync = html.index("function syncArrowLabelPos(sh, el)")
    assert "arrowMidPoint(sh)" in html[sync:sync + 400]


def test_arrow_label_edit_state_is_cleared_with_shapes(html):
    """整体替换 state.shapes 的路径都要清编辑指针，否则指向不存在的 id。"""
    assert html.count("state.editingArrowLabelId = null;") >= 4


def test_snap_target_covers_shapes(html):
    """流程节点要能连线，候选集不能只有 frame 卡片。"""
    assert "function snapToTarget(pt, selfId)" in html
    assert "function snapToFrame(" not in html
    start = html.index("function snapToTarget(pt, selfId)")
    body = html[start:start + 1200]
    assert "ARROW_SNAP_KINDS" in body
    assert "state.shapes" in body


def test_arrow_cannot_snap_to_itself(html):
    """自吸会让端点解析成环，拖端点时线原地打转。"""
    start = html.index("function snapToTarget(pt, selfId)")
    body = html[start:start + 1200]
    assert "sh.id === selfId" in body


def test_anchor_point_takes_box(html):
    """锚点计算统一吃包围盒，才能同时服务 frame 与图形。"""
    assert "function anchorPoint(box, anchor)" in html


def test_shape_removal_detaches_arrows_before_filtering(html):
    """降级必须在对象还在 state.shapes 里时做，否则锚点算不出来，端点会塌到原点。"""
    start = html.index("function removeShape(id)")
    body = html[start:start + 700]
    assert body.index('detachArrowsFromHost("shapeId"') < body.index("state.shapes = state.shapes.filter")


def test_shape_move_refreshes_arrows(html):
    """图形当宿主后，拖动要带着连线走。"""
    start = html.index("function beginGroupDrag()")
    body = html[start:html.index("function prepareSelectionForDrag(", start)]
    assert "refreshArrowGeometry()" in body


def test_shape_resize_refreshes_arrows(html):
    """尺寸变了边中点也变，连线要重算。"""
    start = html.index("function bindShapeResize(el, sh)")
    body = html[start:start + 2400]
    assert "refreshArrowGeometry()" in body


# ---------- 流程图形 ----------

def test_shape_defs_cover_both_groups(html):
    """形状注册表是形状库的唯一定义处：面板、切换器、落笔尺寸全从它派生。"""
    start = html.index("const SHAPE_DEFS = {")
    body = html[start:html.index("const FLOW_VARIANTS", start)]
    for v in ("start", "process", "decision", "io", "data", "doc", "connector",
              "predefined", "manualOp", "manualInput", "delay", "prep",
              "display", "multidoc", "offpage",
              "square", "triangle", "triangleDown", "trapezoid",
              "pentagon", "star", "cross", "arrowRight", "cloud"):
        assert f"{v}:" in body, v
    assert 'groups: ["flow"]' in body
    assert 'groups: ["geo"]' in body


def test_shape_groups_derive_from_one_table(html):
    """两个面板的顺序表都由 SHAPE_DEFS 过滤得到，不能各自再抄一份形状清单。"""
    assert "const FLOW_VARIANTS = Object.keys(SHAPE_DEFS);" in html
    assert 'SHAPE_DEFS[v].groups.includes("flow")' in html
    assert 'SHAPE_DEFS[v].groups.includes("geo")' in html


def test_geo_order_leads_with_rect(html):
    """方框是 kind === "rect" 的圈选框，不是 flow 节点，但在用户眼里就是一种基础图形。"""
    start = html.index("const GEO_ORDER")
    body = html[start:html.index(";", start)]
    assert '["rect"].concat(' in body


def test_shape_path_covers_every_variant(html):
    """注册表里的每个 key 都要有轮廓生成函数，否则落下去是个看不见但点得到的幽灵节点。"""
    defs_start = html.index("const SHAPE_DEFS = {")
    defs = html[defs_start:html.index("const FLOW_VARIANTS", defs_start)]
    keys = re.findall(r"^  (\w+):", defs, re.M)
    assert len(keys) >= 24
    path_start = html.index("const SHAPE_PATH = {")
    path_body = html[path_start:html.index("function flowPath(variant, w, h)", path_start)]
    for k in keys:
        assert f"{k}(w, h)" in path_body, k


def test_flow_path_falls_back_to_process(html):
    """非法 variant 不能画出空 path——那会是一个看不见但点得到的幽灵节点。"""
    start = html.index("function flowPath(variant, w, h)")
    body = html[start:start + 300]
    assert "SHAPE_PATH[variant] || SHAPE_PATH.process" in body


def test_flow_uses_svg_not_clip_path(html):
    """clip-path 会把描边一起裁掉，菱形与平行四边形画不出边。"""
    start = html.index(".flow-svg {")
    css = html[start:start + 1400]
    assert "clip-path" not in css
    assert ".flow-path {" in html


def test_flow_resize_repaints_path(html):
    """轮廓按实际 w/h 重算，不靠 viewBox 拉伸，否则窄高节点描边会粗细不均。"""
    start = html.index("function bindShapeResize(el, sh)")
    body = html[start:start + 2400]
    assert "syncFlowPath(el, sh)" in body


def test_flow_variant_on_dataset(html):
    start = html.index("function renderShapeBlock(sh)")
    body = html[start:start + 1400]
    assert "el.dataset.variant" in body


# ---------- 流程图工具面板 ----------

def test_flow_dock_button_exists(html):
    """先切到 dock 区间再找，理由同 test_shape_tool_buttons_are_lock_disabled：
    CSS 里的 body[data-tool="flow"] 排在按钮前面，从整份文档找第一处会落到那条选择器上。"""
    dock = html[html.index('id="dock"'):html.index("<!-- /dock -->")]
    assert 'data-tool="flow"' in dock
    i = dock.index('data-tool="flow"')
    seg = dock[dock.rindex("<button", 0, i):dock.index(">", i)]
    assert "data-lock-disable" in seg


def test_flow_shortcut_registered(html):
    start = html.index("const TOOL_SHORTCUTS")
    body = html[start:html.index("};", start)]
    assert '"f": "flow"' in body


def test_shape_panel_is_generated_not_hardcoded(html):
    """面板预览图由 flowPath 生成，避免面板与画布上的轮廓两套定义。"""
    assert "function buildShapePanel(cfg)" in html
    start = html.index("function shapeMiniSvg(")
    body = html[start:html.index("function buildShapePanel(cfg)", start)]
    assert "flowPath(v, w, h)" in body


def test_all_shape_panels_share_one_renderer(html):
    """R / F / A 是同一个面板的三份配置，渲染 / 开合 / 同步按钮三条路径都只有一份实现。"""
    start = html.index("const SHAPE_PANELS = {")
    body = html[start:html.index("function shapeMiniSvg(", start)]
    assert 'panelId: "geoPanel"' in body
    assert 'panelId: "flowPanel"' in body
    assert 'panelId: "arrowPanel"' in body
    for fn in ("buildShapePanel", "bindShapePanel", "syncShapeButton"):
        assert html.count(f"function {fn}(cfg)") == 1


def test_panel_label_and_preview_go_through_hooks(html):
    """路由不在形状库里，取名与预览必须走 cfg 钩子，否则三份配置没法共用一个渲染器。"""
    start = html.index("function buildShapePanel(cfg)")
    body = html[start:html.index("function syncShapePanelActive(cfg)", start)]
    assert "cfg.labelOf(v)" in body
    assert "cfg.mini(cfg.miniW" in body or "cfg.mini(v, cfg.miniW" in body


# ---------- 箭头路由面板 ----------

def test_arrow_panel_container_exists(html):
    """与 R / F 面板同一个外壳，落位、开合、外部点击收起全部继承。"""
    assert '<div class="flow-panel" id="arrowPanel" hidden></div>' in html


def test_arrow_panel_registered_with_dock_button(html):
    start = html.index("  arrow: {", html.index("const SHAPE_PANELS = {"))
    body = html[start:html.index("};", start)]
    assert 'btnId: "toolArrow"' in body
    assert 'stateKey: "arrowRoute"' in body
    assert 'tool: "arrow"' in body
    assert "order: ARROW_ROUTE_ORDER" in body


def test_arrow_dock_button_carries_mini_preview(html):
    """按钮图标要能被 syncShapeButton 换掉，得是 flow-mini 而不是字体图标。"""
    dock = html[html.index('id="dock"'):html.index("<!-- /dock -->")]
    i = dock.index('id="toolArrow"')
    seg = dock[i:dock.index("</button>", i)]
    assert 'class="flow-mini"' in seg


def test_arrow_mini_reuses_canvas_path(html):
    """面板预览与画布落笔共用 arrowPath，不会出现两种线。"""
    start = html.index("function arrowMiniSvg(route, w, h)")
    body = html[start:html.index("function arrowPoints(sh)", start)]
    assert "arrowPath(pts," in body


def test_panel_highlights_current_choice(html):
    """面板打开时压住 dock 按钮的预览图，当前选中项要在面板里自己显出来。"""
    start = html.index("function syncShapePanelActive(cfg)")
    body = html[start:html.index("function syncShapeButton(cfg)", start)]
    assert 'classList.toggle("is-on"' in body
    sync = html[html.index("function syncShapeButton(cfg)"):]
    assert "syncShapePanelActive(cfg)" in sync[:sync.index("\n}")]


def test_flow_click_creates_default_sized_node(html):
    """流程图是连续摆节点的活，每个都要求拖出尺寸太累：点一下也要落一个。"""
    start = html.index('if (state.tool === "flow" || state.tool === "geo")')
    body = html[start:start + 2800]
    assert "shapeDefaultSize(variant)" in body


def test_geo_tool_shares_flow_create_branch(html):
    """几何形状落下来也是 kind === "flow" 的节点，只是形状取 state.geoVariant。"""
    start = html.index('if (state.tool === "flow" || state.tool === "geo")')
    body = html[start:start + 400]
    assert 'state.tool === "geo" ? state.geoVariant : state.flowVariant' in body


def test_flow_tool_cursor(html):
    assert 'body[data-tool="flow"] .canvas-sizer' in html


def test_shape_panel_closes_on_outside_pointer(html):
    start = html.index("function bindShapePanel(cfg)")
    body = html[start:start + 1400]
    assert 'closest("#" + cfg.panelId)' in body


def test_flow_data_rim_arc_matches_outer_winding(html):
    """圆柱的碗口弧要和外轮廓同绕向：反向的话 nonzero 填充规则会让顶盖下半区绕数归零，
    节点上开一条横贯全宽的透明带。"""
    start = html.index("  data(w, h) {")
    body = html[start:html.index("  doc(w, h) {", start)]
    assert "M${w} ${ry} A${rx} ${ry} 0 0 1 0 ${ry}" in body


def test_mid_handle_is_rebuilt_on_refresh(html):
    """L 型变回 Z 型时折点手柄要补回来：几何刷新这条路径不重建 DOM，
    只在 renderArrow 里创建会让手柄一旦摘掉就永久消失。"""
    assert "function makeMidHandle(sh, pts, g)" in html
    start = html.index("function refreshArrowGeometry()")
    body = html[start:start + 1800]
    assert "makeMidHandle(sh, pts, g)" in body


def test_arrow_panel_anchors_to_its_dock_button(html):
    """两格的面板落在 dock 正中间离触发它的按钮太远，要吸在按钮正上方。"""
    start = html.index("function positionPanelToButton(cfg)")
    body = html[start:html.index("function positionAnchoredPanels()", start)]
    assert "getBoundingClientRect()" in body
    assert "window.innerWidth" in body           # 边上的按钮不能把面板顶出屏幕
    cfg = html[html.index("  arrow: {", html.index("const SHAPE_PANELS = {")):]
    assert "anchorToButton: true" in cfg[:cfg.index("};")]


def test_arrow_panel_gives_up_css_centering(html):
    """CSS 的 left:50% + translateX(-50%) 与现算的 left 会叠加，必须让出来。"""
    start = html.index("#arrowPanel {")
    body = html[start:html.index("}", start)]
    assert "left: 0" in body
    assert "transform: none" in body


def test_anchored_panel_repositions_on_resize(html):
    """按钮跟着 dock 居中走，窗口一改宽面板就脱开。"""
    start = html.index('window.addEventListener("resize"')
    assert "positionAnchoredPanels()" in html[start:start + 300]


# ---------- 形状切换器：贴着浮条落位 ----------

def test_shape_picker_overrides_dock_panel_anchoring(html):
    """切换器复用 .flow-panel 的外壳，但落位另起一套。.flow-panel 的
    bottom / transform 不覆盖掉，JS 写的 inline top 会和底部锚点打架。"""
    match = re.search(r"\.shape-picker\s*\{([^}]*)\}", html)
    assert match
    body = match.group(1)
    assert re.search(r"bottom:\s*auto", body)
    assert re.search(r"transform:\s*none", body)


def test_shape_picker_stays_fixed_not_inside_stage(html):
    """切换器不能塞进 canvas-stage：stage 带 scale(zoom)，30% 缩放下面板会小到点不中。
    它靠读浮条的屏幕矩形定位，两个坐标系的桥就在 getBoundingClientRect 这一步。"""
    start = html.index("function positionShapePicker()")
    body = html[start:html.index("function closeShapePicker()", start)]
    assert "shapeToolbar" in body
    assert "getBoundingClientRect()" in body
    assert "state.zoom" not in body


def test_shape_picker_flips_below_when_it_cannot_fit_above(html):
    """图形贴着视口顶部时，面板往上放会露出视口外，要翻到浮条下方。"""
    start = html.index("function positionShapePicker()")
    body = html[start:html.index("function closeShapePicker()", start)]
    assert "if (top < PICKER_MARGIN) top = b.bottom + PICKER_GAP;" in body


def test_shape_picker_clamps_to_viewport(html):
    start = html.index("function positionShapePicker()")
    body = html[start:html.index("function closeShapePicker()", start)]
    assert "window.innerHeight" in body
    assert "window.innerWidth" in body


def test_shape_picker_closes_with_its_toolbar(html):
    """浮条收起时切换器必须跟着收：留在屏幕上的话，点里面的形状会作用到
    一个已经取消选中的图形。"""
    start = html.index("function syncShapeToolbar()")
    body = html[start:html.index("function applyShapeVariant(", start)]
    assert "closeShapePicker();" in body


def test_shape_picker_repositions_on_zoom_and_scroll(html):
    """浮条在 stage 里、跟着缩放与滚动动；切换器是 fixed 的，不跟着重贴就会脱开。"""
    start = html.index("function applyZoom()")
    assert "positionShapePicker()" in html[start:start + 400]
    start = html.index('document.getElementById("canvasScroll").addEventListener("scroll"')
    assert "positionShapePicker()" in html[start:start + 300]


def test_shape_picker_repositions_after_zoom_scroll_compensation(html):
    """zoomAround 里 applyZoom() 跑在滚动补偿之前，那一次重贴读到的浮条屏幕位置还是旧的。
    scroll 监听也补不上——赋值后的滚动值若未变（已在边界）根本不触发 scroll 事件。
    必须在改完 scrollLeft/scrollTop 之后再贴一次。"""
    start = html.index("function zoomAround(factor, anchorX, anchorY)")
    body = html[start:html.index("function zoomByStep(", start)]
    tail = body[body.index("scroll.scrollTop ="):]
    assert "positionShapePicker();" in tail


# ---------- frame 选中态 ----------

def test_frame_selection_has_visual_state(html):
    assert re.search(
        r"\.frame-block\.selected\s*\{[^}]*outline:\s*2px solid var\(--accent\)", html
    ) or re.search(
        r"\.frame-block\.focused,\s*\n\s*\.frame-block\.selected\s*\{[^}]*outline:", html
    )


def test_frame_and_shape_share_one_selection(html):
    """卡片与图形同住一个选中集合，两个单选值由集合派生：只有恰好一个成员时才有值。
    多选时它们双双为 null，八向手柄 / 连接点 / 形状浮条这些单选专属 UI 因此自动收起。"""
    start = html.index("function syncSelection()")
    body = html[start:html.index("function syncSelectionDom()", start)]
    assert "state.selection.length === 1" in body
    assert "state.selectedShapeId = one" in body
    assert "state.selectedFrameId = one" in body


def test_frame_selection_survives_canvas_rerender(html):
    """renderCanvas 整片重建卡片 DOM，不回填的话「删了个图形，选中的卡片高亮就没了」。"""
    start = html.index("function renderFrameInstance(inst)")
    body = html[start:start + 800]
    assert 'selectionClass("frame", inst.id)' in body
    assert "block.classList.add(selCls)" in body


def test_clicking_a_frame_does_not_immediately_deselect_it(html):
    """bindFrameDrag 的 pointerdown 挂在更深的 .frame-block 上、冒泡后才到画布空白处的
    取消逻辑。不放行卡片就等于刚选中又立刻被取消。"""
    start = html.index('if (state.tool === "select") {')
    body = html[start:start + 500]
    assert 'if (e.target.closest(".frame-block")) return;' in body


def test_delete_key_removes_whole_selection(html):
    """Delete 删的是整个选中集合，卡片与图形混选也是一次操作、一步撤销。"""
    start = html.index('if (e.key === "Delete" || e.key === "Backspace")')
    assert "deleteSelection();" in html[start:start + 400]
    d = html.index("function deleteSelection()")
    body = html[d:d + 400]
    assert 'm.kind === "frame"' in body and 'm.kind === "shape"' in body
    assert "removeCanvasObjects(" in body


def test_removing_a_frame_clears_its_selection(html):
    start = html.index("function removeCanvasObjects(instanceIds, shapeIds)")
    body = html[start:html.index("function deleteSelection()", start)]
    assert "pruneSelection();" in body


# ---------- 多选：框选 / Shift 加减选 / 整组拖删 ----------

def test_selection_is_a_collection(html):
    """选中是一个集合，两个单选值只是它的派生。"""
    assert "selection: []" in html
    for fn in ("function setSelection(", "function toggleSelection(", "function isSelected(",
               "function clearSelection(", "function pruneSelection("):
        assert fn in html, fn


def test_no_raw_writes_to_derived_selection_ids(html):
    """两个单选值只能由 syncSelection 派生。别处的裸赋值会让集合与派生值脱钩：
    集合里还攥着三个成员，浮条却以为只选中了一个。"""
    start = html.index("function syncSelection()")
    end = html.index("function syncSelectionDom()", start)
    outside = html[:start] + html[end:]
    assert "state.selectedShapeId = " not in outside
    assert "state.selectedFrameId = " not in outside


def test_marquee_starts_only_on_empty_canvas(html):
    """框选只从空白起手：落在卡片或图形上是拖那个对象，两种手势不能抢。"""
    start = html.index('if (state.tool === "select") {')
    body = html[start:start + 600]
    assert 'e.target.closest("[data-shape-id]")' in body
    assert 'e.target.closest(".frame-block")' in body
    assert "startMarqueeGesture(e);" in body


def test_marquee_selects_by_intersection(html):
    """相交即选中，不要求把对象整个框住——一张卡片就占半屏，要求全包等于逼人先缩到很小。"""
    start = html.index("function marqueeHits(box)")
    body = html[start:html.index("function startMarqueeGesture(", start)]
    assert "boxesIntersect(box, b)" in body
    assert 'kind: "frame"' in body and 'kind: "shape"' in body


def test_marquee_hit_test_is_throttled(html):
    """命中判定要把所有卡片与图形的包围盒算一遍，必须按帧节流，不能每个 pointermove 都算。"""
    start = html.index("function startMarqueeGesture(e)")
    body = html[start:html.index("// 图形创建：", start)]
    assert "requestAnimationFrame(paint)" in body
    assert "cancelAnimationFrame" in body


def test_shift_click_toggles_membership(html):
    """Shift 点击加进来 / 摘出去；摘出去之后这一下不再进拖拽。"""
    start = html.index("function prepareSelectionForDrag(")
    body = html[start:html.index("function startGroupDragGesture(", start)]
    assert "toggleSelection(kind, id)" in body
    assert "return isSelected(kind, id);" in body


def test_group_drag_replays_from_origin(html):
    """每帧都从起手快照 + 本帧总位移重算：累加式写法会把吸附修正的误差攒进坐标，
    拖一段路组内相对位置就散了。"""
    start = html.index("function beginGroupDrag()")
    body = html[start:html.index("function prepareSelectionForDrag(", start)]
    assert "ox: inst.x || 0" in body
    assert "it.obj.x = it.ox + dx" in body


def test_group_drag_moves_only_free_arrow_ends(html):
    """绑在宿主上的端点由宿主带着走，整组位移只搬自由端，否则连线会被拽离卡片。"""
    start = html.index("function beginGroupDrag()")
    body = html[start:html.index("function prepareSelectionForDrag(", start)]
    assert '!sh[k].instanceId && !sh[k].shapeId' in body


def test_group_delete_confirms_and_saves_once(html):
    """一组卡片上的标注合并成一次确认、一次落盘：逐个删会弹 N 次框、在撤销栈里占 N 步。"""
    start = html.index("function removeCanvasObjects(instanceIds, shapeIds)")
    body = html[start:html.index("function deleteSelection()", start)]
    assert body.count("confirm(") == 1
    assert body.count("writeLayout();") == 1
    assert body.count("renderCanvas();") == 1


def test_nudge_batches_into_one_history_step(html):
    """连按方向键只落一步历史：写盘延到停手之后；撤销 / 锁定前先 flush，
    否则那一步还没进栈，Cmd+Z 会直接跳过它。"""
    assert "setTimeout(commitNudge, NUDGE_SAVE_DELAY)" in html
    start = html.index("function settleEditing()")
    assert "flushNudge();" in html[start:start + 300]


def test_select_all_and_escape_clear_bound(html):
    assert 'e.metaKey || e.ctrlKey) && (e.key === "a"' in html
    assert "selectAllObjects();" in html
    start = html.index('if (e.key === "Escape") {')
    body = html[start:start + 900]
    assert "state.selection.length) clearSelection();" in body


def test_marquee_cancel_restores_prior_selection(html):
    """手势被打断要还原到起手前的那一份，而不是清空：非 Shift 框选的 base 是空的，
    拿它还原等于一次误触就把原本选好的一组清掉。"""
    start = html.index("function startMarqueeGesture(e)")
    body = html[start:html.index("// 图形创建：", start)]
    assert "const before = state.selection.slice()" in body
    assert "teardown(); setSelection(before);" in body


def test_multi_select_has_visual_state(html):
    """多选成员照常描边，外面再套一个虚线整组框；两者都不接指针。"""
    assert ".frame-block.co-selected," in html
    assert ".shape-block.co-selected .shape-body" in html
    assert ".marquee {" in html
    assert ".selection-box {" in html


def test_group_box_hidden_during_marquee(html):
    """框选进行中不画整组框：选框本身已经在表达圈住了哪一片，两个框叠着看会分不清。"""
    start = html.index("function syncSelectionBox()")
    body = html[start:start + 400]
    assert "!marqueeActive" in body


# ---------- 贴图 ----------

def test_image_binary_never_enters_layout(html):
    """图片只在 shape 里留一个相对路径。base64 进 shape 会跟着 writeLayout 一起 PUT，
    几张就顶过 4MB 上限——被拒的不是这张图，是这一轮的全部 frames + shapes。"""
    start = html.index("async function placeImageFile(file, at)")
    body = html[start:html.index("function pickImageFile(dt)", start)]
    assert "src: path" in body
    assert "readAsDataURL" not in body
    assert "toDataURL" not in body


def test_image_upload_is_gated_on_server_capability(html):
    """静态模式下没有落盘的地方，所以直接拦住并说清怎么办，而不是给一个只在内存里
    活着、刷新就没的降级。"""
    start = html.index("function imageUploadBlocker()")
    body = html[start:html.index("async function placeImageFile(", start)]
    assert "!state.serverMode" in body
    assert "!state.imageUpload" in body


def test_image_capability_comes_from_probe_features(html):
    """canvas_server.py 拷进各站点分发，版本参差。读 probe 自报的 features，
    才能在用户按下 Cmd+V 之前给准话，而不是等撞上 404。"""
    start = html.index("async function probeServer()")
    body = html[start:start + 900]
    assert "state.imageUpload = !!(info && info.features && info.features.image);" in body


def test_image_is_downscaled_before_upload(html):
    start = html.index("async function normalizeImageBlob(file)")
    body = html[start:html.index("async function uploadImageBlob(blob)", start)]
    assert "IMAGE_MAX_EDGE" in body
    assert "IMAGE_ENCODE_TYPE" in body


def test_small_images_skip_lossy_reencode(html):
    """PNG 截图里的文字过一次有损重编码就发虚，尺寸与体积都在预算内的直接留原始字节。"""
    start = html.index("async function normalizeImageBlob(file)")
    body = html[start:html.index("async function uploadImageBlob(blob)", start)]
    assert "IMAGE_KEEP_ORIGINAL_BYTES" in body
    assert "return { blob: file, w: nw, h: nh };" in body


def test_upload_content_type_follows_actual_blob(html):
    """不支持 webp 编码的浏览器上 toBlob 自行退回 image/png。写死 Content-Type
    会让服务端按错误的白名单项存扩展名。"""
    start = html.index("async function uploadImageBlob(blob)")
    body = html[start:start + 700]
    assert 'blob.type || "application/octet-stream"' in body


def test_image_paste_yields_to_text_editing(html):
    start = html.index("function bindCanvasImageInput()")
    body = html[start:start + 1600]
    assert "if (isTyping()) return;" in body


def test_image_drop_prevents_browser_navigation(html):
    """dragover 不 preventDefault 的话，浏览器默认行为是把这张图当导航目标打开，
    整个画布连同未落盘的改动一起被替换掉。"""
    start = html.index("function bindCanvasImageInput()")
    body = html[start:start + 2200]
    assert 'scroll.addEventListener("dragover"' in body
    assert 'dropEffect = "copy"' in body


def test_image_lands_where_the_user_can_see_it(html):
    """键盘粘贴时鼠标可能压根不在画布上，那就落到视口中心。"""
    start = html.index("function imageDropPoint()")
    body = html[start:html.index("function imageUploadBlocker()", start)]
    assert "rect.left + rect.width / 2" in body


def test_image_resize_locks_aspect_ratio(html):
    start = html.index("function constrainRatio(w0, h0, tw, th, dir)")
    body = html[start:html.index("function bindShapeResize(el, sh)", start)]
    assert "const ratio = h0 / w0;" in body
    # 高一律由 ratio 反推，下限只钳宽。分轴钳制会放出两个独立自变量，
    # 拖过最小尺寸时把任意比例压成 SHAPE_MIN_W x SHAPE_MIN_H 那一个方框。
    assert "return { w: tw, h: tw * ratio };" in body
    assert "const minW = Math.max(SHAPE_MIN_W, SHAPE_MIN_H / ratio);" in body
    assert "th = Math.max(" not in body


def test_image_shape_has_no_text_layer(html):
    """图片承载的是截图本身，双击进文字编辑没有意义。"""
    start = html.index("function renderShapeBlock(sh)")
    body = html[start:html.index("function selectShape(", start)]
    assert 'if (sh.kind === "image") {' in body
    assert 'if (sh.kind === "image") return;' in body      # dblclick 守卫


def test_image_can_host_arrow_endpoints(html):
    assert 'const ARROW_SNAP_KINDS = ["rect", "note", "flow", "image"];' in html


def test_image_is_not_a_node_kind(html):
    """NODE_KINDS 决定谁能换形状、谁长连接点。图片换成菱形是没有意义的操作。"""
    assert 'const NODE_KINDS = ["flow", "rect"];' in html


# ---------- 视口档位：卡片尺寸按所属页面取 ----------

def test_frame_instance_writes_viewport_vars(html):
    """卡片宽高靠 inline 的 --frame-w / --frame-h 驱动，中台页才不会被塞进手机壳。

    变量必须挂在最外层 .frame-block 上：选中描边与拖拽包围盒按 block 宽度算，
    挂到内层 .frame 上 block 取不到（CSS 变量只向下继承）。
    """
    start = html.index("function renderFrameInstance(inst)")
    body = html[start:html.index("function renderFrames(", start)]
    assert "const vp = pageViewport(meta.page);" in body
    assert 'block.style.setProperty("--frame-w", vp.width + "px")' in body
    assert 'block.style.setProperty("--frame-h", vp.height + "px")' in body
    assert 'data-frame-h="${vp.height}"' in body           # 供 bindIframeAutoresize 定高度下限


def test_inst_viewport_resolves_by_page(html):
    start = html.index("function instViewport(inst)")
    body = html[start:html.index("\n}", start)]
    assert "state.pages.find(p => p.id === (inst && inst.pageId))" in body


def test_card_size_constants_are_gone(html):
    """卡片尺寸不再是全局常量：同一张画布上手机页与中台页各按各的档位。"""
    assert "const FRAME_W = 375;" not in html
    assert "const FRAME_H = 812;" not in html


@pytest.mark.parametrize("fn", ["frameBox(inst)", "syncSizer()", "nextPositionFor(pageId)"])
def test_layout_math_reads_instance_viewport(html, fn):
    """算包围盒 / 画布尺寸 / 新实例落位都要按实例视口取数，不能退回写死的手机壳。"""
    start = html.index(f"function {fn}")
    body = html[start:html.index("\nfunction ", start + 10)]
    assert "instViewport(" in body


def test_initial_zoom_fits_widest_instance(html):
    """首屏缩放让最宽的一帧完整落进可视区；APP 恒为 1，中台自动缩。"""
    start = html.index("function computeInitialZoom()")
    body = html[start:html.index("\n}", start)]
    assert "state.frames.reduce" in body
    assert "instViewport(inst).width" in body
    assert "SIDEBAR_W" not in html                          # 分支已无左侧栏，不该再为它留白


# ---------- 持久化：文件是唯一真理 ----------

@pytest.mark.parametrize(
    "residue",
    [
        "mergeInitialData", "refreshAnnotationsFromServer", "refreshLayoutFromServer",
        "function loadLayout()", "loadFromStorage", "STORAGE_KEY", "pushToServer",
        "pushLayoutToServer", "_annNeedsUpload", "_layoutNeedsUpload", "writeStorage",
        "reportLayoutStorageFailure", "annServerRefresh", "layoutServerRefresh",
    ],
)
def test_local_arbitration_fully_removed(html, residue):
    """localStorage 退出数据仲裁：三级来源、补传标志、本机缓存键都不该再出现。"""
    assert residue not in html


def test_localstorage_only_holds_preferences(html):
    """写进 localStorage 的只有主题 / 分屏宽度 / 上次文档 / 相关文档折叠态 / 目录折叠态五类偏好。"""
    keys = set(re.findall(r'localStorage\.setItem\(\s*([A-Za-z_]+)', html))
    assert keys == {"THEME_KEY", "PRD_WIDTH_KEY", "PRD_LAST_FILE_KEY",
                    "REFS_COLLAPSED_KEY", "PRD_TOC_KEY"}


def test_legacy_localstorage_rescue_runs_at_boot(html):
    """旧版画布把标注 / 编排存在本机 localStorage，用 file:// 或纯静态服务评审过的人，
    数据只在自己浏览器里，重跑生成覆盖 index.html 后再没有入口能捞回来。启动时扫一遍
    旧键，整理成导出同格式的文件交还用户；确认后才清，解析不了的键原样留着。"""
    start = html.index("function rescueLegacyLocalStorage()")
    body = html[start:html.index("\n//  导入：覆盖式还原", start)]
    assert '"proto-canvas:annotations:"' in body
    assert '"proto-canvas:layout:"' in body
    assert "localStorage.key(i)" in body
    assert "confirm(" in body
    assert 'downloadJson("legacy-canvas-state-"' in body
    assert "localStorage.removeItem(k)" in body
    # 清除只在确认之后：removeItem 必须排在 confirm 判定之后
    assert body.index("confirm(") < body.index("localStorage.removeItem(")
    # 全文的 removeItem 只此一处，其余地方不碰用户的本机存储
    assert html.count("localStorage.removeItem(") == 1
    boot = html.index("async function boot()")
    boot_body = html[boot:html.index("\n}", boot)]
    assert boot_body.index("refreshBadges()") < boot_body.index("rescueLegacyLocalStorage()")


def test_persist_serializes_per_kind_and_keeps_latest(html):
    start = html.index("async function flush(")
    body = html[start:html.index("\n}", start)]
    assert "if (inflight[kind]) return;" in body
    assert "while (pending[kind])" in body
    assert "scheduleRetry(kind)" in body


def test_probe_requires_write_service_receipt(html):
    """任意静态托管都可能对未知路径回 2xx（SPA 兜底 / 自定义错误页配 200）。只看 HTTP
    状态会进服务模式：保存状态显示「已保存」、PUT 出去全被丢弃、beforeunload 也不拦，
    用户失去唯一的回流手段（导出）却收不到任何信号。判据必须是响应体自报的 ok。"""
    start = html.index("async function probeServer()")
    body = html[start:html.index("\n}", start)]
    assert "info.ok !== true" in body


def test_flush_confirms_write_receipt_and_skips_retry_on_4xx(html):
    """成功判据同 probe：PUT 回的 {ok: true, updatedAt} 才算落盘。4xx 是这份 payload
    过不了校验，重试永远不会好，只留 pending 与 dirty 等下一次编辑。"""
    start = html.index("async function flush(")
    body = html[start:html.index("\n}", start)]
    assert "body.ok !== true" in body
    assert "r.status >= 500" in body
    assert "if (retriable) scheduleRetry(kind);" in body


def test_boot_loads_data_and_probes_before_binding(html):
    start = html.index("async function boot()")
    body = html[start:html.index("\n}", start)]
    assert "Promise.all([loadInitialData(), probeServer()])" in body
    assert body.index("Promise.all") < body.index("bindToolbar()")


def test_boot_sets_zoom_before_applying_it(html):
    """applyZoom() 按 state.zoom 算 sizer 尺寸，缩放还停在默认 1 时算出来的是错的。"""
    start = html.index("async function boot()")
    body = html[start:html.index("\n}", start)]
    assert body.index("state.zoom = computeInitialZoom()") < body.index("applyZoom()")


def test_static_mode_ui_present(html, shell):
    assert 'id="staticBanner"' in shell
    assert 'id="saveState"' in shell
    assert 'class="static-banner-close" id="staticBannerClose"' in shell
    assert "function enterStaticMode()" in html
    assert 'window.addEventListener("beforeunload"' in html


def test_static_banner_clears_the_toolbar_row(html):
    """横幅 z-index 高于 toolbar / mode-switch 且吃指针，压在它们身上会连按钮的点击
    一起吞掉——静态模式下「导出」是唯一的回流路径，横幅文案自己还在指向它。
    让开那一行 + 限宽换行，两者缺一不可。"""
    start = html.index(".static-banner {")
    rule = html[start:html.index("}", start)]
    assert "top: 64px" in rule
    assert "max-width: min(560px, calc(100vw - 32px))" in rule
    assert "white-space: nowrap" not in rule


def test_save_state_has_dark_variants(html):
    """工具栏跟随主题，暗色下亮色字色对比度不够；四个状态色各自要有暗色变体。"""
    for status in ("saving", "saved", "error", "static"):
        assert f'[data-theme="dark"] .save-state[data-state="{status}"]' in html


# ---------------- 左上角堆叠 + 相关文档 ----------------

def test_corner_stack_container_exists(shell):
    assert 'class="corner-stack" id="cornerStack"' in shell


def test_mode_switch_mounts_into_corner_stack(html):
    """切换条不再自己 fixed 到 body：与「相关文档」共用一套定位，谁不渲染另一个自然顶上去。"""
    start = html.index("function renderModeSwitch(")
    body = html[start:html.index("\n}", start)]
    assert 'getElementById("cornerStack")' in body
    assert 'stack.insertAdjacentHTML("afterbegin"' in body
    assert "document.body.insertAdjacentHTML" not in body


def test_mode_switch_rule_no_longer_positions_itself(html):
    rule = html[html.index(".mode-switch {"):html.index("}", html.index(".mode-switch {"))]
    assert "position: fixed" not in rule
    assert "z-index" not in rule


def test_corner_stack_lets_pointer_through(html):
    """容器铺在左上角一整块矩形上，里面为空时也在；不放行指针那一片画布就拖不动、框选不了。"""
    rule = html[html.index(".corner-stack {"):html.index("}", html.index(".corner-stack {"))]
    assert "pointer-events: none" in rule
    assert "position: fixed" in rule
    assert ".corner-stack > * { pointer-events: auto; }" in html


@pytest.mark.parametrize("ident", [
    'class="refs-panel" id="refsPanel"',
    'id="refsToggle"',
    'id="refsCount"',
    'id="refsRefresh"',
    'id="refsCaret"',
    'class="refs-list" id="refsList"',
])
def test_refs_panel_controls_exist(shell, ident):
    assert ident in shell


def test_refs_panel_starts_hidden(shell):
    """清单是异步回来的；先亮出一块空面板再填内容会闪。"""
    start = shell.index('id="refsPanel"')
    assert "hidden" in shell[start:shell.index(">", start)]


def test_refs_panel_hides_itself_when_empty(html):
    """一篇文档都没有时整块不占地方，左上角回到只有切换条。"""
    start = html.index("function renderRefsPanel()")
    body = html[start:html.index("\n}", start)]
    assert "panel.hidden = files.length === 0" in body


def test_refs_items_open_in_new_tab(html):
    """画布的缩放 / 滚动位置 / 未提交的标注草稿只活在当前标签页，文档不能就地导航走。"""
    start = html.index("function renderRefsPanel()")
    body = html[start:html.index("\n}", start)]
    assert 'target="_blank" rel="noopener"' in body


def test_refs_index_falls_back_when_endpoint_absent(html):
    """静态托管常把未知路径回成 200 + 一张 HTML 404 页，ok 之外还得验 files 真是数组；
    两关任一不过退回构建期落盘的索引（file:// 下本来就只有这一条路）。"""
    start = html.index("async function loadRefsIndex()")
    body = html[start:html.index("\n}", start)]
    assert "REFS_ENDPOINT" in body
    assert "Array.isArray(d.files)" in body
    assert 'loadDataFile("refs-index")' in body
    assert 'location.protocol !== "file:"' in body


def test_refs_panel_bound_at_boot(html):
    start = html.index("async function boot()")
    body = html[start:html.index("\n}", start)]
    assert "bindRefsPanel();" in body


# ---- PRD 分屏目录 ----

@pytest.mark.parametrize("ident", ['id="prdToc"', 'id="prdTocToggle"', ".prd-toc-item"])
def test_prd_toc_parts_exist(html, ident):
    assert ident in html


def test_prd_toc_sits_beside_content_in_drawer_body(shell):
    """目录与正文是 drawer-body 里的并列两栏，目录在右。"""
    body_start = shell.index('id="prdDrawerBody"')
    assert shell.index('id="prdContent"', body_start) < shell.index('id="prdToc"', body_start)


def test_prd_content_owns_the_scroll(html):
    """两栏各自滚动，正文滚动条不能再留在 drawer-body 上，否则目录会随正文滚走。"""
    start = html.index("  .prd-drawer-body {")
    assert "overflow: hidden;" in html[start:html.index("\n  }", start)]
    start = html.index("  .prd-content {")
    assert "overflow-y: auto;" in html[start:html.index("\n  }", start)]


def test_prd_toc_only_lists_two_levels(html):
    """三级往下是段内细目，列出来会淹没主结构。"""
    assert 'const PRD_TOC_LEVELS = "h1, h2";' in html


def test_prd_heading_ids_stay_out_of_shared_renderer(html):
    """锚点 id 在 buildPrdToc 里就地补：renderMarkdown 注释预览也在用，不能让它吐全局 id。"""
    start = html.index("function buildPrdToc(")
    assert 'h.id = "prd-h-" + idx;' in html[start:html.index("\nfunction clearPrdToc(", start)]
    start = html.index("function renderMarkdown(")
    assert "prd-h-" not in html[start:html.index("\nfunction ", html.index("\n}", start))]


def test_prd_toc_bound_and_rebuilt_on_document_switch(html):
    start = html.index("function bindPrdPanel()")
    body = html[start:html.index("\n}", start)]
    assert "bindPrdTocSpy();" in body
    assert 'getElementById("prdTocToggle")' in body
    start = html.index("async function selectPrdFile(")
    body = html[start:html.index("\n}", start)]
    assert "buildPrdToc(content);" in body
    assert "clearPrdToc();" in body


def test_paste_dispatches_image_then_signed_json_then_memory(html):
    """Cmd/Ctrl+V 一个键接三种内容：截图、别的标签页复制走的画布对象、本页复制的那份。
    顺序不能乱——复制一张图时剪贴板里常常同时躺着文件和一段文件名文本，先认文件
    才不会把截图粘成对象。"""
    start = html.index('document.addEventListener("paste", (e) => {\n    if (isTyping()) return;')
    body = html[start:start + 1200]
    assert body.index("placeImageFile(file, imageDropPoint())") < body.index("readClipPayload")
    assert "|| state.clipboard" in body
    assert "pasteCanvasObjects(payload)" in body


def test_clip_payload_requires_signature(html):
    """剪贴板里的任何文字都会流经粘贴分支。没有签名，用户复制的一段普通文字
    就会被当成画布内容粘进来。"""
    start = html.index("function readClipPayload(text)")
    body = html[start:html.index("function copySelection()", start)]
    assert "obj.__protoCanvas !== CLIP_SIGNATURE" in body


def test_copy_works_while_locked_but_paste_does_not(html):
    """锁定是「别改这张画布」，不是「别把内容拿走」：复制只读，锁着也该能拷去别处；
    粘贴要写数据，必须被锁挡住。"""
    start = html.index('shortcutLetter(e) === "c"')
    assert "state.locked" not in html[start:html.index("copySelection();", start)]
    start2 = html.index("function pasteCanvasObjects(payload)")
    assert "if (state.locked || !payload) return;" in html[start2:start2 + 200]


def test_copy_does_not_carry_annotations(html):
    """标注带全局编号、是评审意见，副本再带一份重复意见没有意义——与移除卡片时
    把标注迁去孤儿区、而不是跟着卡片走是同一条逻辑。"""
    body = html[html.index("function copySelection()"):html.index("function writeSystemClipboard(")]
    assert "annotations" not in body
    assert "orphans" not in body


def test_clipboard_payload_is_a_snapshot_not_a_reference(html):
    """存引用的话，复制完接着改原件，粘出来的是改完之后的样子。"""
    body = html[html.index("function copySelection()"):html.index("function writeSystemClipboard(")]
    assert "JSON.parse(JSON.stringify({" in body


def test_system_clipboard_write_never_throws(html):
    """file:// 与非 secure context 下没有 navigator.clipboard，有也可能因失焦或权限被拒。
    内存那份必成、就是它的兜底，所以写系统剪贴板失败既不能报错也不能中断复制。"""
    body = html[html.index("function writeSystemClipboard(payload)"):html.index("function pasteCanvasObjects(")]
    assert '!navigator.clipboard || typeof navigator.clipboard.writeText !== "function"' in body
    assert ".catch(() => {})" in body
    assert "try {" in body


def test_pasted_frames_are_reconciled_against_local_pages(html):
    """跨站点粘来的卡片可能指向本站点没有的页面 / 状态：渲染不出来，留着就是画布上
    一个看不见的空位。"""
    start = html.index("function pasteCanvasObjects(payload)")
    body = html[start:start + 2600]
    assert "deadInstanceIds(srcFrames, state.pages)" in body
    assert "已跳过" in body


def test_paste_is_one_undo_step_and_selects_the_copies(html):
    """一次粘贴是一次操作：落盘只走一次 writeLayout，微任务快照才会合成一步撤销；
    粘完选中副本，可以直接拖走或接着再粘一份。"""
    start = html.index("function pasteCanvasObjects(payload)")
    body = html[start:start + 2600]
    assert "setSelection(" in body
    assert body.count("writeLayout();") == 1


def test_hidden_attribute_is_not_defeated_by_display():
    """`[hidden]` 的 display:none 只是 UA 样式，作者样式里随便一条 display 都盖得过它。
    靠 hidden 属性显隐、CSS 里又声明了 display 的元素必须自带 `.x[hidden]` 兜底，
    否则 `el.hidden = true` 设了也白设，元素照样占着地方。"""
    css = (REFS / "canvas.css").read_text(encoding="utf-8")
    shell = TEMPLATE.read_text(encoding="utf-8")
    js = (REFS / "canvas.js").read_text(encoding="utf-8")

    styled = {}
    for m in re.finditer(r"\n\s*\.([a-z0-9-]+)\s*\{([^}]*)\}", css):
        d = re.search(r"\bdisplay:\s*([a-z-]+)", m.group(2))
        if d and d.group(1) != "none":
            styled.setdefault(m.group(1), d.group(1))
    guarded = set(re.findall(r"\.([a-z0-9-]+)\[hidden\]", css))

    id_to_classes = {}
    for tag in re.findall(r"<[a-z]+\b[^>]*>", shell):
        i = re.search(r'\bid="([^"]+)"', tag)
        c = re.search(r'\bclass="([^"]*)"', tag)
        if i and c:
            id_to_classes[i.group(1)] = c.group(1).split()

    # 模板里静态带 hidden 的，加上 JS 里直接按 id 开关 hidden 的
    toggled = set(re.findall(r'\bid="([^"]+)"[^>]*\shidden(?![-\w])', shell))
    toggled |= set(re.findall(r'\shidden(?![-\w])[^>]*\bid="([^"]+)"', shell))
    toggled |= set(re.findall(r'getElementById\("([^"]+)"\)\.hidden\s*=', js))

    naked = sorted(
        (i, c, styled[c]) for i in toggled for c in id_to_classes.get(i, [])
        if c in styled and c not in guarded
    )
    assert not naked, "设了 hidden 也隐不掉，缺 [hidden] 兜底：%s" % (naked,)
