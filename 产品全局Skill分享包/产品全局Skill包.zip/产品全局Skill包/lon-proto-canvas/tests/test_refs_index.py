"""相关文档清单的扫描与落盘测试。

扫描实现在 canvas_server（服务端实时端点与构建期索引共用同一份），update_refs_index
只负责把它写成 refs-index.json + 镜像。两层分开测：前者管「看到什么」，后者管「写成什么」。
"""
import json
import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import canvas_server  # noqa: E402
import update_refs_index  # noqa: E402


def _write(root: Path, name: str, body: str) -> Path:
    p = root / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body, encoding="utf-8")
    return p


# ---------------- doc_title ----------------

@pytest.mark.parametrize("body,expected", [
    ("<html><head><title>竞品调研报告</title></head><body>x</body></html>", "竞品调研报告"),
    ("<html><head><title>  多余   空白  </title></head></html>", "多余 空白"),
    ("<html><head><title>换行\n也算\n空白</title></head></html>", "换行 也算 空白"),
    ("<html><head><TITLE>大小写不敏感</TITLE></head></html>", "大小写不敏感"),
    ("<html><head><title>A &amp; B</title></head></html>", "A & B"),
    ("<html><head><title><span>剥掉内层标签</span></title></head></html>", "剥掉内层标签"),
])
def test_doc_title_reads_html_title(tmp_path, body, expected):
    assert canvas_server.doc_title(_write(tmp_path, "doc.html", body)) == expected


def test_doc_title_falls_back_to_filename(tmp_path):
    """没有 title 的文档照样要能列出来，用文件名当展示名。"""
    assert canvas_server.doc_title(_write(tmp_path, "埋点方案.html", "<html><body>x</body></html>")) == "埋点方案"


def test_doc_title_falls_back_when_title_is_empty(tmp_path):
    assert canvas_server.doc_title(_write(tmp_path, "空标题.html", "<title>   </title>")) == "空标题"


def test_doc_title_only_reads_head_of_file(tmp_path):
    """title 按规范在 head 里；超出扫描窗口的不认，避免为一个标题读进整份大报告。"""
    body = "<html><head>" + "<!--" + "x" * canvas_server.TITLE_SCAN_BYTES + "-->" + \
           "<title>太靠后</title></head></html>"
    assert canvas_server.doc_title(_write(tmp_path, "big.html", body)) == "big"


def test_doc_title_survives_broken_encoding(tmp_path):
    """编码不对只该让标题花掉，不能炸掉整张清单。"""
    p = tmp_path / "bad.html"
    p.write_bytes(b"<title>\xff\xfe\xfa</title>")
    assert canvas_server.doc_title(p)   # 有值即可，具体替换字符不做断言


# ---------------- scan_refs ----------------

def test_scan_refs_returns_empty_when_dir_missing(tmp_path):
    """还没放过文档是常态，不是错误。"""
    data = canvas_server.scan_refs(tmp_path)
    assert data["files"] == []
    assert data["refsDir"] == "refs"
    assert data["version"] == "1"


def test_scan_refs_collects_html_only(tmp_path):
    refs = tmp_path / "refs"
    _write(refs, "a.html", "<title>甲</title>")
    _write(refs, "b.htm", "<title>乙</title>")
    _write(refs, "c.md", "# 不是 HTML")
    _write(refs, "d.pdf", "%PDF")
    _write(refs / "sub", "e.html", "<title>子目录不递归</title>")
    files = canvas_server.scan_refs(tmp_path)["files"]
    assert [f["file"] for f in files] == ["a.html", "b.htm"]


def test_scan_refs_sorts_by_filename(tmp_path):
    """按文件名升序：用户拿 01- 这类前缀就能自己排面板顺序。"""
    refs = tmp_path / "refs"
    for name in ("03-丙.html", "01-甲.html", "02-乙.html"):
        _write(refs, name, "<html></html>")
    assert [f["file"] for f in canvas_server.scan_refs(tmp_path)["files"]] == \
        ["01-甲.html", "02-乙.html", "03-丙.html"]


def test_scan_refs_entry_carries_display_fields(tmp_path):
    _write(tmp_path / "refs", "x.html", "<title>用户访谈纪要</title>")
    entry = canvas_server.scan_refs(tmp_path)["files"][0]
    assert entry["file"] == "x.html"
    assert entry["title"] == "用户访谈纪要"
    assert entry["size"] > 0
    assert entry["mtimeIso"].endswith("+00:00")


# ---------------- 落盘 ----------------

def test_write_index_writes_json_and_mirror(tmp_path):
    """镜像不是可选项：file:// 下打开画布 fetch 用不了，只能读 <script src>。"""
    _write(tmp_path / "refs", "a.html", "<title>甲</title>")
    out = update_refs_index.write_index(tmp_path)
    assert out.name == "refs-index.json"
    mirror = tmp_path / "refs-index.js"
    assert mirror.is_file()
    data = json.loads(out.read_text(encoding="utf-8"))
    assert [f["title"] for f in data["files"]] == ["甲"]
    assert '__CANVAS_DATA__["refs-index"]' in mirror.read_text(encoding="utf-8")


def test_write_index_on_empty_site(tmp_path):
    data = json.loads(update_refs_index.write_index(tmp_path).read_text(encoding="utf-8"))
    assert data["files"] == []


def test_ensure_refs_dir_is_idempotent(tmp_path):
    first = update_refs_index.ensure_refs_dir(tmp_path)
    second = update_refs_index.ensure_refs_dir(tmp_path)
    assert first == second == tmp_path / "refs"
    assert first.is_dir()


def test_scan_shares_one_implementation_with_the_server(tmp_path):
    """构建期索引与服务端实时端点必须是同一份扫描，否则服务在与不在会看到两张清单。"""
    _write(tmp_path / "refs", "a.html", "<title>甲</title>")
    assert update_refs_index.scan(tmp_path)["files"] == canvas_server.scan_refs(tmp_path)["files"]
