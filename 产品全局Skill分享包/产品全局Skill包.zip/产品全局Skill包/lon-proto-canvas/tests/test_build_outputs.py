"""build_canvas.py 产物侧的单元测试：数据文件与镜像、演示入口解析、坏 JSON 处理、服务脚本拷贝。"""
import json
import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import build_canvas  # noqa: E402


@pytest.mark.parametrize(
    "present,expected",
    [
        (["demo/demo.html"], "demo/demo.html"),
        (["pages/index.html"], None),
        (["demo/demo.html", "pages/index.html"], "demo/demo.html"),
        ([], None),
    ],
)
def test_resolve_demo_entry_only_accepts_demo_shell(tmp_path, present, expected):
    for rel in present:
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("<html></html>", encoding="utf-8")
    assert build_canvas._resolve_demo_entry(tmp_path) == expected


def test_load_json_or_die_returns_none_when_missing(tmp_path):
    assert build_canvas._load_json_or_die(tmp_path / "x.json", "x", "hint") is None


def test_load_json_or_die_parses_valid(tmp_path):
    p = tmp_path / "x.json"
    p.write_text('{"a": 1}', encoding="utf-8")
    assert build_canvas._load_json_or_die(p, "x", "hint") == {"a": 1}


def test_load_json_or_die_preserves_corrupt_copy_and_exits(tmp_path, capsys):
    p = tmp_path / "annotations.json"
    p.write_text("{not json", encoding="utf-8")
    with pytest.raises(SystemExit) as ex:
        build_canvas._load_json_or_die(p, "annotations.json", "修好再跑")
    assert ex.value.code == 3
    out = json.loads(capsys.readouterr().out)
    assert "annotations.json 解析失败" in out["error"]
    assert Path(out["preservedCopy"]).exists()
    assert ".corrupt." in out["preservedCopy"]


def test_write_data_files_writes_json_and_mirrors(tmp_path):
    files = build_canvas.write_data_files(
        tmp_path,
        {"version": "1", "pages": []},
        {"version": "1", "annotations": [], "orphans": []},
        {"version": "2", "frames": [], "shapes": []},
    )
    names = sorted(Path(f).name for f in files)
    assert names == ["annotations.js", "annotations.json", "layout.js", "layout.json", "pages.js", "pages.json"]
    assert json.loads((tmp_path / "pages.json").read_text(encoding="utf-8")) == {"version": "1", "pages": []}
    assert '__CANVAS_DATA__["pages"]' in (tmp_path / "pages.js").read_text(encoding="utf-8")


def test_copy_server_script_places_identical_copy(tmp_path):
    dst = Path(build_canvas.copy_server_script(tmp_path))
    assert dst == tmp_path / "canvas_server.py"
    assert dst.read_bytes() == (SCRIPTS / "canvas_server.py").read_bytes()


def test_copy_canvas_assets_copies_css_and_js(tmp_path):
    files = sorted(Path(f).name for f in build_canvas.copy_canvas_assets(tmp_path))
    assert files == ["canvas.css", "canvas.js"]
    refs = SCRIPTS.parent / "references"
    assert (tmp_path / "assets" / "canvas.js").read_bytes() == (refs / "canvas.js").read_bytes()
    assert (tmp_path / "assets" / "canvas.css").read_bytes() == (refs / "canvas.css").read_bytes()


def test_write_canvas_shell_copies_template_verbatim(tmp_path):
    dst = Path(build_canvas.write_canvas_shell(tmp_path))
    assert dst == tmp_path / "index.html"
    assert dst.read_bytes() == build_canvas.TEMPLATE_PATH.read_bytes()


def test_legacy_render_helpers_removed():
    for name in ("render_index", "_build_mode_switch"):
        assert not hasattr(build_canvas, name)


def test_now_iso_shared_with_layout():
    import layout
    assert build_canvas.now_iso is layout.now_iso


def test_build_wires_the_refs_index(tmp_path):
    """相关文档清单是画布左上角那块区域的数据源，build 得负责建目录 + 落索引。"""
    source = (SCRIPTS / "build_canvas.py").read_text(encoding="utf-8")
    assert "import update_refs_index" in source
    assert "update_refs_index.ensure_refs_dir(output_dir)" in source
    assert "update_refs_index.write_index(output_dir)" in source
    assert '"refsIndex": refs_index_info' in source


def test_refs_index_failure_degrades_to_warning():
    """索引生成失败不该炸掉整次构建：画布其余部分照常，warning 里说清楚哪块会空。"""
    source = (SCRIPTS / "build_canvas.py").read_text(encoding="utf-8")
    start = source.index("update_refs_index.ensure_refs_dir")
    block = source[start:source.index("out = {", start)]
    assert "except Exception as e:" in block
    assert "warnings.append" in block
