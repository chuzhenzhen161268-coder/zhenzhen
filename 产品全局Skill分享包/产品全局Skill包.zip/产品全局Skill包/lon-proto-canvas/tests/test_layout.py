"""layout.json 生成与合并的单元测试。"""
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import layout  # noqa: E402


def _page(pid, order, states, overlays=(), triggers=(), viewport=None):
    p = {
        "id": pid,
        "order": order,
        "name": pid,
        "mainStates": [{"key": k, "label": k} for k in states],
        "overlays": [{"key": k, "label": k, "kind": "popup"} for k in overlays],
        "triggers": list(triggers),
    }
    # 不传 viewport 就是旧 pages.json 的形态，走 FALLBACK_VIEWPORT 回退
    if viewport:
        p["viewport"] = viewport
    return p


MOBILE_W, MOBILE_H = layout.FALLBACK_VIEWPORT
DESKTOP = {"width": 1280, "height": 800}


EMPTY_HIDDEN = {"version": "1", "pages": [], "frames": []}


# ---------- ordered_frame_keys ----------

def test_ordered_frame_keys_puts_overlay_right_after_its_trigger_state():
    page = _page(
        "01-a", 1,
        states=["default", "empty"],
        overlays=["confirm"],
        triggers=[{"stateKey": "default", "overlayKey": "confirm", "action": "tap"}],
    )
    assert layout.ordered_frame_keys(page) == ["default", "confirm", "empty"]


def test_ordered_frame_keys_appends_unlinked_overlays_last():
    page = _page("01-a", 1, states=["default"], overlays=["toast"])
    assert layout.ordered_frame_keys(page) == ["default", "toast"]


def test_ordered_frame_keys_never_duplicates_an_overlay():
    """同一浮层被两个状态触发时只出现一次。"""
    page = _page(
        "01-a", 1,
        states=["s1", "s2"],
        overlays=["shared"],
        triggers=[
            {"stateKey": "s1", "overlayKey": "shared"},
            {"stateKey": "s2", "overlayKey": "shared"},
        ],
    )
    assert layout.ordered_frame_keys(page) == ["s1", "shared", "s2"]


# ---------- now_iso ----------

def test_now_iso_has_millisecond_precision_and_z_suffix():
    """格式需要与前端 nowIso()（new Date().toISOString()）字符串序对齐：导入合并按
    updatedAt 的字符串大小定同 id 标注的新旧，精度不一致会让同一秒内的两条判反。"""
    ts = layout.now_iso()
    assert re.match(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$', ts)


# ---------- make_instance_id ----------

def test_make_instance_id_is_deterministic():
    a = layout.make_instance_id("01-a", "default", 0)
    b = layout.make_instance_id("01-a", "default", 0)
    assert a == b
    assert a.startswith("fi-")
    assert len(a) == 9


def test_make_instance_id_differs_per_seq():
    assert layout.make_instance_id("01-a", "default", 0) != layout.make_instance_id("01-a", "default", 1)


# ---------- build_layout: 首次全量铺开 ----------

def test_first_build_lays_out_every_frame():
    pages = [_page("01-a", 1, ["default", "empty"]), _page("02-b", 2, ["default"])]
    result, summary = layout.build_layout(pages, None, EMPTY_HIDDEN)
    assert len(result["frames"]) == 3
    assert summary["created"] == 3
    assert result["version"] == "2"
    assert result["shapes"] == []
    assert "dismissed" not in result


def test_first_build_positions_page_frames_in_a_row():
    pages = [_page("01-a", 1, ["default", "empty"])]
    result, _ = layout.build_layout(pages, None, EMPTY_HIDDEN)
    xs = [f["x"] for f in result["frames"]]
    ys = [f["y"] for f in result["frames"]]
    assert xs == [0, MOBILE_W + layout.GAP_X]
    assert ys == [0, 0]


def test_first_build_stacks_pages_vertically():
    pages = [_page("01-a", 1, ["default"]), _page("02-b", 2, ["default"])]
    result, _ = layout.build_layout(pages, None, EMPTY_HIDDEN)
    row_h = MOBILE_H + layout.CAPTION_H + layout.GAP_Y
    assert [f["y"] for f in result["frames"]] == [0, row_h]


def test_first_build_skips_missing_pages():
    p = _page("01-a", 1, ["default"])
    p["missing"] = True
    result, summary = layout.build_layout([p], None, EMPTY_HIDDEN)
    assert result["frames"] == []
    assert summary["created"] == 0


def test_frame_entry_shape():
    pages = [_page("01-a", 1, ["default"])]
    result, _ = layout.build_layout(pages, None, EMPTY_HIDDEN)
    assert set(result["frames"][0]) == {"id", "pageId", "frameKey", "x", "y"}


# ---------- build_layout: hidden.json 迁移 ----------

def test_hidden_frames_are_skipped_on_first_build():
    pages = [_page("01-a", 1, ["default", "empty"])]
    hidden = {"version": "1", "pages": [], "frames": ["01-a#empty"]}
    result, summary = layout.build_layout(pages, None, hidden)
    assert [f["frameKey"] for f in result["frames"]] == ["default"]
    assert summary["migratedFromHidden"] == 1


def test_hidden_pages_skip_all_their_frames():
    pages = [_page("01-a", 1, ["default", "empty"]), _page("02-b", 2, ["default"])]
    hidden = {"version": "1", "pages": ["01-a"], "frames": []}
    result, summary = layout.build_layout(pages, None, hidden)
    assert [f["pageId"] for f in result["frames"]] == ["02-b"]
    assert summary["migratedFromHidden"] == 2


def test_hidden_is_ignored_when_layout_already_exists():
    """迁移只在首次发生。已有 layout 时 hidden 不再起作用。"""
    pages = [_page("01-a", 1, ["default"])]
    existing = {
        "version": "2",
        "frames": [{"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 9, "y": 9}],
        "shapes": [],
    }
    hidden = {"version": "1", "pages": ["01-a"], "frames": []}
    result, summary = layout.build_layout(pages, existing, hidden)
    assert len(result["frames"]) == 1
    assert summary["migratedFromHidden"] == 0


# ---------- build_layout: 增量 ----------

def test_existing_coordinates_are_never_touched():
    pages = [_page("01-a", 1, ["default"])]
    existing = {
        "version": "2",
        "frames": [{"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 777, "y": 888}],
        "shapes": [],
    }
    result, _ = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert result["frames"][0]["x"] == 777
    assert result["frames"][0]["y"] == 888
    assert result["frames"][0]["id"] == "fi-aaa111"


def test_new_frame_key_is_not_auto_added():
    """主动添加语义：扫到新状态不自动上画布。"""
    pages = [_page("01-a", 1, ["default", "brand-new"])]
    existing = {
        "version": "2",
        "frames": [{"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0}],
        "shapes": [],
    }
    result, summary = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert [f["frameKey"] for f in result["frames"]] == ["default"]
    assert summary["created"] == 0


def test_vanished_frame_key_removes_all_its_instances():
    pages = [_page("01-a", 1, ["default"])]
    existing = {
        "version": "2",
        "frames": [
            {"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0},
            {"id": "fi-bbb222", "pageId": "01-a", "frameKey": "gone", "x": 500, "y": 0},
            {"id": "fi-ccc333", "pageId": "01-a", "frameKey": "gone", "x": 900, "y": 0},
        ],
        "shapes": [],
    }
    result, summary = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert [f["id"] for f in result["frames"]] == ["fi-aaa111"]
    assert summary["removed"] == 2


def test_multiple_instances_of_same_frame_key_survive():
    pages = [_page("01-a", 1, ["default"])]
    existing = {
        "version": "2",
        "frames": [
            {"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0},
            {"id": "fi-bbb222", "pageId": "01-a", "frameKey": "default", "x": 900, "y": 400},
        ],
        "shapes": [],
    }
    result, _ = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert len(result["frames"]) == 2


def test_shapes_are_preserved_verbatim():
    pages = [_page("01-a", 1, ["default"])]
    shape = {"id": "sh-note-d4p1", "kind": "note", "x": 1, "y": 2, "w": 3, "h": 4, "text": "x", "color": "yellow"}
    existing = {"version": "2", "frames": [], "shapes": [shape]}
    result, _ = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert result["shapes"] == [shape]


def test_updated_at_preserved_when_nothing_changes():
    """frames / shapes 一个字节都没变时，updatedAt 必须沿用旧值——file:// 模式下前端靠它
    做 inline / localStorage 两级来源仲裁，时间戳被无谓刷新会让用户在画布上的编排
    （拖拽位置、增删实例）在下次 build 后被判定为「更旧」而永久丢失。"""
    pages = [_page("01-a", 1, ["default"])]
    existing = {
        "version": "2",
        "updatedAt": "2020-01-01T00:00:00.000Z",
        "frames": [{"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0}],
        "shapes": [],
    }
    result, _ = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert result["updatedAt"] == existing["updatedAt"]


def test_updated_at_refreshed_when_a_frame_is_actually_removed():
    """真的发生了删减时 updatedAt 必须刷新，否则前端仲裁判断不出这是更新的版本。"""
    pages = [_page("01-a", 1, ["default"])]
    existing = {
        "version": "2",
        "updatedAt": "2020-01-01T00:00:00.000Z",
        "frames": [
            {"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0},
            {"id": "fi-bbb222", "pageId": "01-a", "frameKey": "gone", "x": 500, "y": 0},
        ],
        "shapes": [],
    }
    result, _ = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert result["updatedAt"] != existing["updatedAt"]


def test_build_layout_tolerates_null_frames_field():
    """existing_layout['frames'] / ['shapes'] 是非 list 值（如一次畸形 PUT 写入的
    null）时按空列表处理，不应该抛异常。"""
    pages = [_page("01-a", 1, ["default"])]
    existing = {"version": "2", "updatedAt": "2020-01-01T00:00:00.000Z", "frames": None, "shapes": None}
    result, summary = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert result["frames"] == []
    assert result["shapes"] == []
    assert summary["removed"] == 0


def test_missing_page_removes_its_instances():
    p = _page("01-a", 1, ["default"])
    p["missing"] = True
    existing = {
        "version": "2",
        "frames": [{"id": "fi-aaa111", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0}],
        "shapes": [],
    }
    result, summary = layout.build_layout([p], existing, EMPTY_HIDDEN)
    assert result["frames"] == []
    assert summary["removed"] == 1


# ---------- detach_arrows ----------

def test_detach_arrows_converts_bound_end_to_absolute():
    frames = [{"id": "fi-gone", "pageId": "01-a", "frameKey": "default", "x": 100, "y": 200}]
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow",
        "from": {"instanceId": "fi-gone", "anchor": "right"},
        "to": {"x": 900, "y": 500},
    }]
    out = layout.detach_arrows(shapes, frames, {"fi-gone"})
    h = MOBILE_H + layout.CAPTION_H
    assert out[0]["from"] == {"x": 100 + MOBILE_W, "y": 200 + h / 2}
    assert out[0]["to"] == {"x": 900, "y": 500}


def test_detach_arrows_keeps_live_bindings():
    frames = [
        {"id": "fi-live", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0},
        {"id": "fi-gone", "pageId": "01-a", "frameKey": "empty", "x": 500, "y": 0},
    ]
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow",
        "from": {"instanceId": "fi-live", "anchor": "right"},
        "to": {"instanceId": "fi-gone", "anchor": "left"},
    }]
    out = layout.detach_arrows(shapes, frames, {"fi-gone"})
    h = MOBILE_H + layout.CAPTION_H
    assert out[0]["from"] == {"instanceId": "fi-live", "anchor": "right"}
    assert out[0]["to"] == {"x": 500, "y": h / 2}


def test_detach_arrows_leaves_non_arrow_shapes_untouched():
    shapes = [{"id": "sh-note-1", "kind": "note", "x": 1, "y": 2, "w": 3, "h": 4,
               "text": "x", "color": "yellow"}]
    out = layout.detach_arrows(shapes, [], {"fi-gone"})
    assert out == shapes


def test_detach_arrows_survives_malformed_entries():
    """磁盘上的 shapes 可能是手改坏的，不能让一条脏数据打断整次构建。"""
    shapes = ["not-a-dict", {"kind": "arrow", "from": None, "to": {"x": 1, "y": 2}}]
    out = layout.detach_arrows(shapes, [], {"fi-gone"})
    assert out[0] == "not-a-dict"
    assert out[1]["to"] == {"x": 1, "y": 2}


def test_detach_arrows_ignores_ends_without_instance_id():
    """被删的 frame 字典缺 id 键时，removed_ids 里会混进一个 None。自由端的
    instanceId 取出来同样是 None，不先排空值就会被判成命中，坐标被覆盖成垃圾值。"""
    frames = [{"pageId": "01-a", "frameKey": "default", "x": 100, "y": 200}]
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow",
        "from": {"x": 300, "y": 400},
        "to": {"x": 900, "y": 500},
    }]
    out = layout.detach_arrows(shapes, frames, {None})
    assert out[0]["from"] == {"x": 300, "y": 400}
    assert out[0]["to"] == {"x": 900, "y": 500}


def test_build_layout_detaches_arrows_of_removed_frames():
    """frameKey 从 pages.json 消失后，指向它的箭头端点在同一次构建里降级。"""
    pages = [_page("01-a", 1, states=["default"])]
    existing = {
        "version": "2",
        "updatedAt": "2026-01-01T00:00:00.000Z",
        "frames": [
            {"id": "fi-live", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0},
            {"id": "fi-gone", "pageId": "01-a", "frameKey": "removed", "x": 800, "y": 0},
        ],
        "shapes": [{
            "id": "sh-arw-1", "kind": "arrow",
            "from": {"instanceId": "fi-live", "anchor": "right"},
            "to": {"instanceId": "fi-gone", "anchor": "left"},
        }],
    }
    data, stats = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    h = MOBILE_H + layout.CAPTION_H
    assert stats["removed"] == 1
    assert data["shapes"][0]["from"] == {"instanceId": "fi-live", "anchor": "right"}
    assert data["shapes"][0]["to"] == {"x": 800, "y": h / 2}
    assert data["updatedAt"] != existing["updatedAt"]


def test_build_layout_keeps_timestamp_when_arrows_unchanged():
    """没有实例被删时 shapes 一个字节不变，updatedAt 不能被刷新。"""
    pages = [_page("01-a", 1, states=["default"])]
    existing = {
        "version": "2",
        "updatedAt": "2026-01-01T00:00:00.000Z",
        "frames": [{"id": "fi-live", "pageId": "01-a", "frameKey": "default", "x": 0, "y": 0}],
        "shapes": [{
            "id": "sh-arw-1", "kind": "arrow",
            "from": {"instanceId": "fi-live", "anchor": "right"},
            "to": {"x": 900, "y": 500},
        }],
    }
    data, _ = layout.build_layout(pages, existing, EMPTY_HIDDEN)
    assert data["updatedAt"] == "2026-01-01T00:00:00.000Z"


def test_detach_arrows_ignores_shape_hosted_ends():
    """端点绑在图形上时不带 instanceId，构建期不能把它误判成命中而覆盖坐标。"""
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow",
        "from": {"shapeId": "sh-flow-1", "anchor": "right"},
        "to": {"instanceId": "fi-gone", "anchor": "left"},
    }]
    frames = [{"id": "fi-gone", "x": 100, "y": 200}]
    out = layout.detach_arrows(shapes, frames, {"fi-gone"})
    assert out[0]["from"] == {"shapeId": "sh-flow-1", "anchor": "right"}
    assert "x" in out[0]["to"] and "y" in out[0]["to"]


def test_detach_arrows_preserves_route_fields():
    """降级只动端点，路由字段不能丢，否则折线会在构建后变回直线。"""
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow", "route": "elbow", "mid": 0.3,
        "from": {"instanceId": "fi-gone", "anchor": "right"},
        "to": {"x": 10, "y": 20},
    }]
    frames = [{"id": "fi-gone", "x": 0, "y": 0}]
    out = layout.detach_arrows(shapes, frames, {"fi-gone"})
    assert out[0]["route"] == "elbow"
    assert out[0]["mid"] == 0.3


# ---------- 视口档位：卡片尺寸按页取，不再是常量 ----------

def test_page_viewport_falls_back_to_mobile():
    assert layout.page_viewport({}) == layout.FALLBACK_VIEWPORT
    assert layout.page_viewport(None) == layout.FALLBACK_VIEWPORT
    assert layout.page_viewport({"viewport": {"width": 0, "height": -1}}) == layout.FALLBACK_VIEWPORT


def test_page_viewport_reads_declared_profile():
    assert layout.page_viewport({"viewport": DESKTOP}) == (1280, 800)


def test_first_build_spaces_desktop_frames_by_its_own_width():
    pages = [_page("01-a", 1, ["default", "empty"], viewport=DESKTOP)]
    result, _ = layout.build_layout(pages, None, EMPTY_HIDDEN)
    assert [f["x"] for f in result["frames"]] == [0, 1280 + layout.GAP_X]


def test_first_build_row_height_follows_each_page_viewport():
    """手机页与中台页并存时，每行的行高按自己那页的档位走。"""
    pages = [
        _page("01-a", 1, ["default"], viewport=DESKTOP),
        _page("02-b", 2, ["default"]),
    ]
    result, _ = layout.build_layout(pages, None, EMPTY_HIDDEN)
    assert [f["y"] for f in result["frames"]] == [0, 800 + layout.CAPTION_H + layout.GAP_Y]


def test_detach_arrows_uses_host_page_viewport():
    """降级坐标按宿主页面的档位算：中台卡片的右锚点在 x+1280，不是 x+375。"""
    frames = [{"id": "fi-gone", "pageId": "01-a", "x": 100, "y": 200}]
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow",
        "from": {"instanceId": "fi-gone", "anchor": "right"},
        "to": {"x": 900, "y": 400},
    }]
    out = layout.detach_arrows(shapes, frames, {"fi-gone"}, {"01-a": (1280, 800)})
    h = 800 + layout.CAPTION_H
    assert out[0]["from"] == {"x": 100 + 1280, "y": 200 + h / 2}


def test_detach_arrows_without_viewport_map_falls_back():
    """不传档位表时按手机壳算，保持旧调用方的行为。"""
    frames = [{"id": "fi-gone", "pageId": "01-a", "x": 0, "y": 0}]
    shapes = [{
        "id": "sh-arw-1", "kind": "arrow",
        "from": {"instanceId": "fi-gone", "anchor": "right"},
        "to": {"x": 900, "y": 400},
    }]
    out = layout.detach_arrows(shapes, frames, {"fi-gone"})
    assert out[0]["from"]["x"] == MOBILE_W
