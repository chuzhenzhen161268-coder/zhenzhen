#!/usr/bin/env node
// 画布持久化纯函数的行为测试：按函数名从 canvas.js 抠出函数体执行。
// 用法：node test_canvas_persistence.mjs <canvas.js>
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';

// .pathname 留的是百分号编码，路径里有空格或中文时 readFileSync 直接 ENOENT
const target = process.argv[2] || fileURLToPath(new URL('../references/canvas.js', import.meta.url));
const src = fs.readFileSync(target, 'utf8');

function grab(name) {
  const re = new RegExp('\\nfunction ' + name + '\\([\\s\\S]*?\\n\\}\\n');
  const m = src.match(re);
  if (!m) throw new Error('canvas.js 里找不到 function ' + name + '——测试抠不到目标时必须失败，不能静默跳过');
  return m[0];
}

// ---------- 导入前对账：卡片画不画得出来、箭头端点有没有宿主 ----------

const findFrameMetaIn = new Function(grab('findFrameMetaIn') + '\nreturn findFrameMetaIn;')();
const deadInstanceIds = new Function(
  grab('findFrameMetaIn') + grab('deadInstanceIds') + '\nreturn deadInstanceIds;')();
const danglingArrowEnds = new Function(grab('danglingArrowEnds') + '\nreturn danglingArrowEnds;')();

const PAGES = [{
  id: 'p1',
  mainStates: [{ key: 'default', label: '默认态', tag: '主' }],
  overlays: [{ key: 'filter', label: '筛选浮层', kind: 'popup' }]
}];
const inst = (id, frameKey, pageId) => ({ id, pageId: pageId || 'p1', frameKey, x: 0, y: 0 });

test('findFrameMetaIn 命中主状态与浮层，各带自己的 kind', () => {
  assert.equal(findFrameMetaIn(PAGES, 'p1', 'default').kind, 'state');
  assert.equal(findFrameMetaIn(PAGES, 'p1', 'default').label, '默认态');
  assert.equal(findFrameMetaIn(PAGES, 'p1', 'filter').kind, 'overlay');
});

test('findFrameMetaIn 查不到页 / 查不到 key / pages 为空都返回 null', () => {
  assert.equal(findFrameMetaIn(PAGES, 'p9', 'default'), null);
  assert.equal(findFrameMetaIn(PAGES, 'p1', 'nope'), null);
  assert.equal(findFrameMetaIn([], 'p1', 'default'), null);
  assert.equal(findFrameMetaIn(null, 'p1', 'default'), null);
});

test('deadInstanceIds 只挑出画不出来的：缺页与缺状态都算', () => {
  const dead = deadInstanceIds([
    inst('f1', 'default'),
    inst('f2', 'filter'),
    inst('f3', 'gone'),
    inst('f4', 'default', 'p9')
  ], PAGES);
  assert.deepEqual([...dead].sort(), ['f3', 'f4']);
});

test('deadInstanceIds 忽略畸形实例，不把 undefined 塞进集合', () => {
  const dead = deadInstanceIds([null, {}, { id: 7 }, inst('f1', 'default')], PAGES);
  assert.equal(dead.size, 0);
});

const arrow = (id, from, to) => ({ id, kind: 'arrow', from, to });
const FRAMES = [inst('f1', 'default')];
const SHAPES_BASE = [{ id: 's1', kind: 'note', x: 0, y: 0, w: 10, h: 10 }];

test('danglingArrowEnds：两端宿主都在、或两端都是自由坐标时不报', () => {
  const shapes = SHAPES_BASE.concat([
    arrow('ar1', { instanceId: 'f1', anchor: 'right' }, { shapeId: 's1', anchor: 'left' }),
    arrow('ar2', { x: 1, y: 2 }, { x: 3, y: 4 })
  ]);
  assert.deepEqual(danglingArrowEnds(shapes, FRAMES), []);
});

test('danglingArrowEnds：宿主实例 / 宿主图形缺失时各报对应端', () => {
  const shapes = SHAPES_BASE.concat([
    arrow('ar1', { instanceId: 'gone', anchor: 'right' }, { x: 3, y: 4 }),
    arrow('ar2', { x: 1, y: 2 }, { shapeId: 'nope', anchor: 'left' }),
    arrow('ar3', { instanceId: 'gone', anchor: 'right' }, { shapeId: 'nope', anchor: 'left' })
  ]);
  assert.deepEqual(danglingArrowEnds(shapes, FRAMES), [
    { id: 'ar1', from: false, to: true },
    { id: 'ar2', from: true, to: false },
    { id: 'ar3', from: false, to: false }
  ]);
});

test('danglingArrowEnds 只看箭头，别的图形不参与', () => {
  const shapes = [{ id: 's1', kind: 'flow', variant: 'process', x: 0, y: 0 }, null];
  assert.deepEqual(danglingArrowEnds(shapes, FRAMES), []);
});

// ---------- rescueLegacyLocalStorage ----------
// 这条路径会删用户浏览器里仅有的一份数据，只靠结构断言不够，必须真跑一遍。

function runRescue(store, answer) {
  const removed = [], downloads = [];
  const fakeStorage = {
    get length() { return Object.keys(store).length; },
    key: i => Object.keys(store)[i],
    getItem: k => (k in store ? store[k] : null),
    removeItem: k => { removed.push(k); delete store[k]; }
  };
  let asked = 0;
  const fn = new Function(
    'localStorage', 'confirm', 'downloadJson', 'nowIso',
    grab('rescueLegacyLocalStorage') + '\nreturn rescueLegacyLocalStorage;'
  )(
    fakeStorage,
    () => { asked++; return answer; },
    (name, obj) => downloads.push({ name, obj }),
    () => '2026-08-28T00:00:00.000Z'
  );
  fn();
  return { removed, downloads, asked: () => asked };
}

const A1 = { id: 'a1', number: 1, updatedAt: '2026-01-01T00:00:00.000Z' };

test('没有旧键时不打扰用户', () => {
  const r = runRescue({ 'proto-canvas:theme:x': 'dark' }, true);
  assert.equal(r.asked(), 0);
  assert.deepEqual(r.downloads, []);
  assert.deepEqual(r.removed, []);
});

test('同一命名空间的标注与编排合成一份导出格式的文件，确认后清键', () => {
  const store = {
    'proto-canvas:annotations:ns1': JSON.stringify({ annotations: [A1], orphans: [] }),
    'proto-canvas:layout:ns1': JSON.stringify({ frames: [{ id: 'f1' }], shapes: [{ id: 's1' }] })
  };
  const r = runRescue(store, true);
  assert.equal(r.downloads.length, 1);
  assert.equal(r.downloads[0].name, 'legacy-canvas-state-ns1.json');
  const d = r.downloads[0].obj;
  assert.equal(d.version, '1');
  assert.deepEqual(d.annotations, [A1]);
  assert.deepEqual(d.orphans, []);
  assert.deepEqual(d.frames, [{ id: 'f1' }]);
  assert.deepEqual(d.shapes, [{ id: 's1' }]);
  assert.deepEqual(Object.keys(store), []);
});

test('取消时一个键都不动，下次打开还能再问', () => {
  const store = { 'proto-canvas:annotations:ns1': JSON.stringify({ annotations: [A1] }) };
  const r = runRescue(store, false);
  assert.equal(r.asked(), 1);
  assert.deepEqual(r.downloads, []);
  assert.deepEqual(r.removed, []);
  assert.equal(Object.keys(store).length, 1);
});

test('解析不了的键原样留着：读不懂不等于可以替用户销毁', () => {
  const store = {
    'proto-canvas:annotations:ns1': '{ 半截 json',
    'proto-canvas:layout:ns1': JSON.stringify({ frames: [{ id: 'f1' }], shapes: [] })
  };
  const r = runRescue(store, true);
  assert.deepEqual(r.downloads[0].obj.annotations, []);
  assert.deepEqual(r.downloads[0].obj.frames, [{ id: 'f1' }]);
  assert.deepEqual(r.removed, ['proto-canvas:layout:ns1']);
  assert.deepEqual(Object.keys(store), ['proto-canvas:annotations:ns1']);
});

test('空数组的旧键不触发弹窗', () => {
  const store = { 'proto-canvas:layout:ns1': JSON.stringify({ frames: [], shapes: [] }) };
  const r = runRescue(store, true);
  assert.equal(r.asked(), 0);
  assert.deepEqual(r.downloads, []);
});

test('多个命名空间各出一份文件', () => {
  const store = {
    'proto-canvas:annotations:ns1': JSON.stringify({ annotations: [A1] }),
    'proto-canvas:annotations:ns2': JSON.stringify({ annotations: [A1] })
  };
  const r = runRescue(store, true);
  assert.deepEqual(r.downloads.map(d => d.name),
    ['legacy-canvas-state-ns1.json', 'legacy-canvas-state-ns2.json']);
  assert.deepEqual(Object.keys(store), []);
});

test('命名空间里的路径分隔符不带进文件名', () => {
  const store = { 'proto-canvas:layout:/a/b c': JSON.stringify({ frames: [{ id: 'f1' }] }) };
  const r = runRescue(store, true);
  assert.equal(r.downloads[0].name, 'legacy-canvas-state--a-b-c.json');
});

// ---------- 撤销 / 重做：history 纯函数 ----------
const historyPush = new Function(grab('historyPush') + '\nreturn historyPush;')();
const historyShift = new Function(grab('historyShift') + '\nreturn historyShift;')();

// 四条 JSON 串各 2-3 字符，一份快照 9 字节，方便按字节上限算裁剪
const snap = (n) => ({ f: `[${n}]`, s: '[]', a: '[]', o: '[]' });
const mkHistory = (over) => Object.assign(
  { undo: [], redo: [], present: snap(0), cap: 100, maxBytes: 8 * 1024 * 1024 }, over);

test('快照与 present 全同：不入栈、不清 redo、返回 false', () => {
  const h = mkHistory({ redo: [snap(9)] });
  assert.equal(historyPush(h, snap(0)), false);
  assert.equal(h.undo.length, 0);
  assert.equal(h.redo.length, 1);
});

test('快照变化：present 压入 undo、新快照成为 present、redo 清空', () => {
  const h = mkHistory({ redo: [snap(9)] });
  assert.equal(historyPush(h, snap(1)), true);
  assert.deepEqual(h.undo, [snap(0)]);
  assert.deepEqual(h.present, snap(1));
  assert.equal(h.redo.length, 0);
});

test('undo / redo 往返，栈空返回 null', () => {
  const h = mkHistory();
  historyPush(h, snap(1));
  historyPush(h, snap(2));
  assert.deepEqual(historyShift(h, 'undo'), snap(1));
  assert.deepEqual(h.redo, [snap(2)]);
  assert.deepEqual(historyShift(h, 'undo'), snap(0));
  assert.equal(historyShift(h, 'undo'), null);
  assert.deepEqual(historyShift(h, 'redo'), snap(1));
  assert.deepEqual(historyShift(h, 'redo'), snap(2));
  assert.equal(historyShift(h, 'redo'), null);
  assert.deepEqual(h.present, snap(2));
});

test('超过 cap 步数丢最旧', () => {
  const h = mkHistory({ cap: 3 });
  for (let i = 1; i <= 5; i++) historyPush(h, snap(i));
  assert.deepEqual(h.undo.map(s => s.f), ['[2]', '[3]', '[4]']);
});

test('超过 maxBytes 丢最旧', () => {
  const h = mkHistory({ maxBytes: 20 });
  for (let i = 1; i <= 5; i++) historyPush(h, snap(i));
  assert.deepEqual(h.undo.map(s => s.f), ['[3]', '[4]']);
});

// ---------- 快捷键字母判定 ----------
const shortcutLetter = new Function(grab('shortcutLetter') + '\nreturn shortcutLetter;')();

test('拉丁布局按键帽字母，AZERTY 的 Z 键（code KeyW）仍是 z、W 键（code KeyZ）不是 z', () => {
  assert.equal(shortcutLetter({ key: 'z', code: 'KeyZ' }), 'z');
  assert.equal(shortcutLetter({ key: 'Z', code: 'KeyZ' }), 'z');
  assert.equal(shortcutLetter({ key: 'z', code: 'KeyW' }), 'z');
  assert.equal(shortcutLetter({ key: 'w', code: 'KeyZ' }), 'w');
});

test('键帽不是拉丁字母时退回物理键位；非字母键返回空串', () => {
  assert.equal(shortcutLetter({ key: 'я', code: 'KeyZ' }), 'z');
  assert.equal(shortcutLetter({ key: 'Enter', code: 'Enter' }), '');
  assert.equal(shortcutLetter({ key: '1', code: 'Digit1' }), '');
});

// ---------- 剪贴板：载荷识别与克隆 ----------
// 常量值跟着 canvas.js 走，改了签名而测试没跟上时这里会先红
function grabConst(name) {
  const re = new RegExp('\\nconst ' + name + ' = [^\\n]*\\n');
  const m = src.match(re);
  if (!m) throw new Error('canvas.js 里找不到 const ' + name);
  return m[0];
}

const readClipPayload = new Function(
  grabConst('CLIP_SIGNATURE') + grab('readClipPayload') + '\nreturn readClipPayload;')();
const cloneCanvasObjects = new Function(
  grab('cloneCanvasObjects') + '\nreturn cloneCanvasObjects;')();

test('readClipPayload 只认带签名的 JSON', () => {
  const sig = grabConst('CLIP_SIGNATURE').match(/"([^"]+)"/)[1];
  assert.equal(readClipPayload(JSON.stringify({ __protoCanvas: sig, shapes: [] })).__protoCanvas, sig);
  assert.equal(readClipPayload(JSON.stringify({ shapes: [] })), null);
  assert.equal(readClipPayload(JSON.stringify({ __protoCanvas: 'clip/999' })), null);
  assert.equal(readClipPayload('随手复制的一段文字'), null);
  assert.equal(readClipPayload('{ 不是合法 JSON'), null);
  assert.equal(readClipPayload(''), null);
  assert.equal(readClipPayload(null), null);
});

// 克隆用的桩：id 按调用序号递增，端点解析返回宿主的固定坐标
function mkCtx(over) {
  let n = 0;
  return Object.assign({
    taken: new Set(),
    dx: 100, dy: 200,
    newShapeId: (kind) => 'new-' + kind + '-' + (++n),
    newInstanceId: () => 'new-fi-' + (++n),
    resolveEnd: () => ({ x: 10, y: 20 })
  }, over || {});
}

test('cloneCanvasObjects 换新 id 并整组平移，非坐标字段原样带过去', () => {
  const out = cloneCanvasObjects({
    frames: [{ id: 'fi-1', pageId: 'p1', frameKey: 'default', x: 5, y: 7 }],
    shapes: [
      { id: 'sh-note-1', kind: 'note', x: 1, y: 2, w: 200, h: 200, text: '甲', color: 'pink' },
      { id: 'sh-flow-1', kind: 'flow', variant: 'decision', x: 3, y: 4, w: 80, h: 60, text: '乙' },
      { id: 'sh-img-1', kind: 'image', x: 0, y: 0, w: 50, h: 50, src: 'assets/canvas-images/a.webp' }
    ]
  }, mkCtx());

  assert.equal(out.frames[0].id.startsWith('new-fi-'), true);
  assert.deepEqual([out.frames[0].x, out.frames[0].y], [105, 207]);
  assert.equal(out.frames[0].pageId, 'p1');
  assert.equal(out.frames[0].frameKey, 'default');

  assert.deepEqual([out.shapes[0].x, out.shapes[0].y], [101, 202]);
  assert.equal(out.shapes[0].color, 'pink');
  assert.equal(out.shapes[0].text, '甲');
  assert.equal(out.shapes[1].variant, 'decision');
  assert.equal(out.shapes[2].src, 'assets/canvas-images/a.webp');
  assert.equal(out.shapes[2].w, 50);
  assert.equal(out.shapes.every(s => s.id.startsWith('new-')), true);
});

test('cloneCanvasObjects 深拷贝，改副本不动原件', () => {
  const src0 = { id: 'sh-arw-1', kind: 'arrow', from: { x: 0, y: 0 }, to: { x: 1, y: 1 }, route: 'elbow' };
  const out = cloneCanvasObjects({ shapes: [src0] }, mkCtx());
  out.shapes[0].from.x = 999;
  assert.equal(src0.from.x, 0);
});

test('箭头两端宿主都在组里时重挂副本，锚点方向不变', () => {
  const out = cloneCanvasObjects({
    frames: [{ id: 'fi-1', pageId: 'p1', frameKey: 'default', x: 0, y: 0 }],
    shapes: [
      { id: 'sh-note-1', kind: 'note', x: 0, y: 0, w: 10, h: 10 },
      {
        id: 'sh-arw-1', kind: 'arrow', route: 'elbow', mid: 0.4, label: '是',
        from: { instanceId: 'fi-1', anchor: 'right' },
        to: { shapeId: 'sh-note-1', anchor: 'left' }
      }
    ]
  }, mkCtx());

  const arrow = out.shapes.find(s => s.kind === 'arrow');
  assert.equal(arrow.from.instanceId, out.frames[0].id);
  assert.equal(arrow.from.anchor, 'right');
  assert.equal(arrow.to.shapeId, out.shapes[0].id);
  assert.equal(arrow.to.anchor, 'left');
  assert.equal(arrow.route, 'elbow');
  assert.equal(arrow.mid, 0.4);
  assert.equal(arrow.label, '是');
});

test('宿主留在组外的那端降级成绝对坐标：取宿主当前位置再平移，不牵回原件', () => {
  const out = cloneCanvasObjects({
    shapes: [
      { id: 'sh-note-1', kind: 'note', x: 0, y: 0, w: 10, h: 10 },
      {
        id: 'sh-arw-1', kind: 'arrow',
        from: { shapeId: 'sh-note-1', anchor: 'right' },
        to: { shapeId: 'sh-note-9', anchor: 'left' }   // 组外
      }
    ]
  }, mkCtx());

  const arrow = out.shapes.find(s => s.kind === 'arrow');
  assert.equal(arrow.from.shapeId, out.shapes[0].id);
  assert.equal(arrow.to.shapeId, undefined);
  assert.deepEqual([arrow.to.x, arrow.to.y], [110, 220]);   // resolveEnd 桩的 (10,20) + 位移
});

test('自由端直接平移，不经过端点解析', () => {
  const out = cloneCanvasObjects({
    shapes: [{ id: 'sh-arw-1', kind: 'arrow', from: { x: 1, y: 2 }, to: { x: 3, y: 4 } }]
  }, mkCtx({ resolveEnd: () => { throw new Error('自由端不该走端点解析'); } }));

  assert.deepEqual([out.shapes[0].from.x, out.shapes[0].from.y], [101, 202]);
  assert.deepEqual([out.shapes[0].to.x, out.shapes[0].to.y], [103, 204]);
});

test('新 id 撞上画布里已有的就重生成', () => {
  let n = 0;
  const out = cloneCanvasObjects({
    shapes: [{ id: 'sh-note-1', kind: 'note', x: 0, y: 0 }]
  }, mkCtx({
    taken: new Set(['占位-1']),
    newShapeId: () => '占位-' + (++n)          // 第一次必撞
  }));
  assert.equal(out.shapes[0].id, '占位-2');
});

test('缺 id 的脏条目直接跳过，不产出半个对象', () => {
  const out = cloneCanvasObjects({
    frames: [{ pageId: 'p1', frameKey: 'default', x: 0, y: 0 }, null],
    shapes: [{ kind: 'note', x: 0, y: 0 }, undefined]
  }, mkCtx());
  assert.equal(out.frames.length, 0);
  assert.equal(out.shapes.length, 0);
});
