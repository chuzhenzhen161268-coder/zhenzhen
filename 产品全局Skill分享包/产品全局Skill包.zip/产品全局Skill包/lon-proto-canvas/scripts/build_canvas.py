#!/usr/bin/env python3
"""
build_canvas.py — lon-proto-canvas 的核心生成器（iframe 协议版）

从源 HTML 原型扫描 → 生成画布四件套（index.html / pages.json / annotations.json / layout.json）。
覆盖 SKILL.md 的 Phase 1-4：扫描、孤儿处理、合并 pages.json、渲染 index.html。

iframe 协议：每个 frame 用 `<iframe src="...?canvasMode=1#<frameKey>">` 渲染。
扫描阶段会幂等补丁原 HTML（注入 patch CSS + bootstrap），不再抠 DOM outerHTML、
不再合并源样式（iframe 已天然隔离 CSS）。

模式（自动判断或 --force-mode 覆盖）:
  - new-folder   : 输入是目录 + pages.json 不存在
  - new-single   : 输入是单 html + pages.json 不存在
  - merge        : 输入是目录 + pages.json 已存在
  - update-page  : 输入是单 html + 命中已有 page.sourceHtml
  - add-page     : 输入是单 html + 未命中

CLI:
  python3 build_canvas.py --input <绝对路径> --output <绝对路径> [--force-mode <mode>]

输出：JSON 摘要到 stdout，供 Claude 直接读取并向用户复述。
"""

import argparse
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

from canvas_server import write_json_with_mirror
from patch_prototype import patch_html
import layout as layout_mod
import update_dev_prd_index
import update_refs_index
import vendor_assets

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
TEMPLATE_PATH = SKILL_ROOT / "references" / "canvas-template.html"

# 文件夹扫描时强制排除的文件名（小写比较）：都不是 PRD 页面，扫进来只会产生噪音 warning
#   demo.html  —— lon-proto-builder 的演示壳
#   index.html —— 站点 / 目录的入口页，不是业务原型
FOLDER_SCAN_EXCLUDE = {'demo.html', 'index.html'}


now_iso = layout_mod.now_iso


def stamp_for_backup():
    return datetime.now().strftime('%Y%m%d-%H%M%S')


# ============================================================
# 视口档位（viewport profile）
# ============================================================
# iframe 的宽度就是原型内部的 CSS 视口宽度（<meta name="viewport"> 在 iframe 内不生效），
# 所以画布必须知道每页按多宽渲染：APP 原型是手机壳 375x812，中台原型是宽屏 1280x800
# （lon-proto-builder 中台模式产出 <meta name="viewport" content="width=1280">）。
#
# 优先级：manifest 的 page.viewport > 源 HTML <meta name="viewport"> 嗅探 > mobile 默认。
# height 只作 frame 高度下限：state frame 仍按 iframe 回报的真实内容高撑开，
# overlay frame 固定按此高展示（不跟随底层 scene 被拉长）。
VIEWPORT_PROFILES = {
    'mobile': {"width": 375, "height": 812},
    'desktop': {"width": 1280, "height": 800},
}
DEFAULT_VIEWPORT = dict(VIEWPORT_PROFILES['mobile'])
# 嗅探到的 width 达到此阈值即视为宽屏，套 desktop 档的高度下限
DESKTOP_WIDTH_THRESHOLD = 700

META_VIEWPORT_RE = re.compile(
    r'<meta[^>]*name=["\']viewport["\'][^>]*content=["\']([^"\']*)["\']',
    re.IGNORECASE,
)


def _coerce_dim(value, lo, hi):
    """把宽/高声明收敛成合法整数像素；越界或非数字返回 None。"""
    try:
        n = int(round(float(value)))
    except (TypeError, ValueError):
        return None
    return n if lo <= n <= hi else None


def resolve_viewport(manifest, html, file_name, warnings):
    """决定该页 frame 的视口尺寸，返回 {"width": int, "height": int}。"""
    declared = ((manifest or {}).get('page') or {}).get('viewport')

    # 1. manifest 显式声明：档位名字符串，或 {profile?, width?, height?}
    if isinstance(declared, str):
        prof = VIEWPORT_PROFILES.get(declared.strip().lower())
        if prof:
            return dict(prof)
        warnings.append(
            f"{file_name}: 未知 viewport 档位 «{declared}»，"
            f"可选 {'/'.join(VIEWPORT_PROFILES)}，已回退嗅探"
        )
    elif isinstance(declared, dict):
        prof = VIEWPORT_PROFILES.get(str(declared.get('profile', '')).strip().lower())
        width = _coerce_dim(declared.get('width'), 240, 4096)
        height = _coerce_dim(declared.get('height'), 240, 8192)
        if prof or width or height:
            vp = dict(prof) if prof else dict(DEFAULT_VIEWPORT)
            if width:
                vp['width'] = width
            if height:
                vp['height'] = height
            return vp
        warnings.append(f"{file_name}: viewport 声明无有效字段，已回退嗅探")

    # 2. 嗅探 <meta name="viewport" content="width=1280">；device-width 等非数字值不算宽屏
    m = META_VIEWPORT_RE.search(html)
    if m:
        wm = re.search(r'width\s*=\s*(\d+)', m.group(1))
        if wm:
            width = _coerce_dim(wm.group(1), 240, 4096)
            if width:
                base = (VIEWPORT_PROFILES['desktop']
                        if width >= DESKTOP_WIDTH_THRESHOLD
                        else VIEWPORT_PROFILES['mobile'])
                return {"width": width, "height": base['height']}

    # 3. 默认手机壳
    return dict(DEFAULT_VIEWPORT)


# ============================================================
# Manifest 解析
# ============================================================

def parse_manifest(html) -> dict | None:
    pat = re.compile(
        r'<script[^>]*type=["\']application/canvas-manifest["\'][^>]*>(.*?)</script>',
        re.DOTALL,
    )
    m = pat.search(html)
    if not m:
        return None
    try:
        return json.loads(m.group(1).strip())
    except Exception as e:
        return {"_parse_error": str(e)}


# ============================================================
# 扫描单个 HTML（先幂等补丁 → 读 manifest → 构造 page dict）
# ============================================================

def scan_single_html(html_path: Path, warnings: list):
    """返回 page_dict 或 None。

    iframe 协议下不再抠 DOM outerHTML，只读 manifest 元数据；扫描前会幂等
    注入 canvasMode bootstrap，保证原型 HTML 可被画布 iframe 加载。
    """
    # 1. 先验 manifest 再补丁：顺序反过来会把非原型的辅助文件也注入一遍 bootstrap。
    #    一个几百字节的入口页 / 说明页没有 manifest、也不该进画布，
    #    却会被平白撑成 10KB 脏文件。
    html = html_path.read_text(encoding='utf-8')
    manifest = parse_manifest(html)
    if manifest is None:
        warnings.append(
            f"{html_path.name}: 未发现 canvas-manifest 块，本页跳过（请补 manifest）"
        )
        return None
    if isinstance(manifest, dict) and '_parse_error' in manifest:
        warnings.append(
            f"{html_path.name}: manifest JSON 解析失败：{manifest['_parse_error']}"
        )
        return None

    # 2. 确认是原型页后再幂等补丁（首次注入 bootstrap + patch CSS，同版本直接跳过）
    try:
        if patch_html(html_path):
            html = html_path.read_text(encoding='utf-8')
    except Exception as e:
        warnings.append(f"{html_path.name}: 补丁注入失败：{e}")

    page_meta = manifest.get('page', {})
    page_id = page_meta.get('id') or html_path.stem
    page = {
        "id": page_id,
        "name": page_meta.get('name', html_path.stem),
        "order": page_meta.get('order', 999),
        "sourceHtml": str(html_path.resolve()),
        "lastScannedAt": now_iso(),
        "missing": False,
        "viewport": resolve_viewport(manifest, html, html_path.name, warnings),
        "mainStates": [],
        "overlays": [],
        "triggers": [],
    }

    for frame in manifest.get('frames', []):
        key = frame.get('key')
        if not key:
            warnings.append(f"{html_path.name}: 跳过缺少 key 的 frame entry")
            continue
        kind = frame.get('kind')
        if kind == 'state':
            page['mainStates'].append({
                "key": key,
                "label": frame.get('label', key),
                "tag": frame.get('tag', ''),
            })
        elif kind == 'overlay':
            overlay_type = frame.get('overlayType', 'popup')
            # toast 是瞬时反馈，不在画布上单独占一帧（约定上不应进 manifest，这里做兜底）
            if overlay_type == 'toast':
                continue
            page['overlays'].append({
                "key": key,
                "label": frame.get('label', key),
                "kind": overlay_type,
            })
            for t in frame.get('triggers', []):
                page['triggers'].append({
                    "stateKey": t.get('fromStateKey'),
                    "overlayKey": key,
                    "action": t.get('action', ''),
                })
        else:
            warnings.append(
                f"{html_path.name}: 未知 kind={kind} (key={key})，已忽略"
            )

    return page


# ============================================================
# 模式判断 + 合并
# ============================================================

def detect_mode(input_path: Path, output_dir: Path):
    pages_path = output_dir / 'pages.json'
    has_pages = pages_path.exists()
    is_dir = input_path.is_dir()

    if not has_pages:
        return 'new-folder' if is_dir else 'new-single'
    if is_dir:
        return 'merge'

    try:
        existing = json.loads(pages_path.read_text(encoding='utf-8'))
    except Exception:
        return 'new-single'
    abs_in = str(input_path.resolve())
    for p in existing.get('pages', []):
        if p.get('sourceHtml') == abs_in:
            return 'update-page'
    return 'add-page'


def build_pages(input_path: Path, existing, mode, warnings):
    """返回 (pages_list, build_summary)。"""
    existing_pages = (existing or {}).get('pages', []) if existing else []
    existing_ids = set(p['id'] for p in existing_pages)
    existing_srcs = set(p.get('sourceHtml') for p in existing_pages if p.get('sourceHtml'))

    new_pages = []
    summary = {"new": 0, "updated": 0, "missing": 0, "kept": 0}

    if mode in ('new-folder', 'merge'):
        files = sorted(
            f for f in input_path.glob('*.html')
            if f.name.lower() not in FOLDER_SCAN_EXCLUDE
        )
        seen_srcs = set()
        for f in files:
            page = scan_single_html(f, warnings)
            if page is None:
                continue
            seen_srcs.add(page['sourceHtml'])
            if page['id'] in existing_ids or page['sourceHtml'] in existing_srcs:
                summary['updated'] += 1
            else:
                summary['new'] += 1
            new_pages.append(page)

        if mode == 'merge':
            input_dir_resolved = input_path.resolve()
            seen_ids = set(p['id'] for p in new_pages)
            for p in existing_pages:
                # 同 id 已被本轮扫描覆盖（即便老 sourceHtml 路径字符串已变，如目录改名），跳过老条目
                if p.get('id') in seen_ids:
                    continue
                src = p.get('sourceHtml')
                if not src:
                    new_pages.append(dict(p))
                    summary['kept'] += 1
                    continue
                if src in seen_srcs:
                    continue
                try:
                    src_parent = Path(src).resolve().parent
                except Exception:
                    src_parent = None
                if src_parent == input_dir_resolved:
                    p2 = dict(p)
                    p2['missing'] = True
                    new_pages.append(p2)
                    summary['missing'] += 1
                else:
                    new_pages.append(dict(p))
                    summary['kept'] += 1

    elif mode in ('new-single', 'add-page'):
        page = scan_single_html(input_path, warnings)
        if page is not None:
            new_pages.append(page)
            summary['new'] += 1
        if mode == 'add-page':
            seen = set(p['id'] for p in new_pages)
            for p in existing_pages:
                if p['id'] not in seen:
                    new_pages.append(p)
                    summary['kept'] += 1

    elif mode == 'update-page':
        page = scan_single_html(input_path, warnings)
        if page is None:
            return existing_pages, summary
        replaced_id = None
        for p in existing_pages:
            if p.get('sourceHtml') == page['sourceHtml']:
                replaced_id = p['id']
                break
        if replaced_id is None:
            replaced_id = page['id']
        page['id'] = replaced_id
        for p in existing_pages:
            if p['id'] == replaced_id:
                new_pages.append(page)
                summary['updated'] += 1
            else:
                new_pages.append(p)
                summary['kept'] += 1
    else:
        raise ValueError(f"unknown mode: {mode}")

    return new_pages, summary


# ============================================================
# 孤儿标注
# ============================================================

def handle_orphans(ann_obj, old_pages, new_pages, mode):
    """update-page / merge 触发；把已消失 frameKey、或整页源已移除（missing）关联的 annotation 移到 orphans。

    update-page 只换单页，missing 页不会出现，逻辑退化为「消失 frameKey 迁孤儿」。
    merge 多页合并时，某页源从输入目录消失会被标 missing（前端不再渲染），其关联标注若不迁孤儿就会
    静默隐身——这里一并处理，与 update-page 行为对齐。
    """
    if mode not in ('update-page', 'merge'):
        return ann_obj, 0

    # 非 missing 页记录当前可渲染的 frame key 集合；missing 页单列（整页迁孤儿）
    new_keys_per_page = {}
    missing_page_ids = set()
    for p in new_pages:
        if p.get('missing'):
            missing_page_ids.add(p['id'])
            continue
        keys = set(s['key'] for s in p.get('mainStates', [])) | \
               set(o['key'] for o in p.get('overlays', []))
        new_keys_per_page[p['id']] = keys

    kept = []
    new_orphans = list(ann_obj.get('orphans', []))
    moved = 0

    for ann in ann_obj.get('annotations', []):
        a = ann.get('anchor', {})
        if a.get('kind') != 'frame':
            kept.append(ann)
            continue
        pid = a.get('pageId')
        # 页源已移除（标 missing）：整页不再渲染，关联标注迁孤儿
        if pid in missing_page_ids:
            o = dict(ann)
            o['lostReason'] = f"页面 '{pid}' 的原型源已移除"
            o['lostAt'] = now_iso()
            new_orphans.append(o)
            moved += 1
            continue
        # 页未被本轮触及（merge 里别处目录的页 / update-page 里非更新页）：保留
        if pid not in new_keys_per_page:
            kept.append(ann)
            continue
        if a.get('frameKey') in new_keys_per_page[pid]:
            kept.append(ann)
        else:
            o = dict(ann)
            o['lostReason'] = f"frameKey '{a.get('frameKey')}' 已从页面 '{pid}' 移除"
            o['lostAt'] = now_iso()
            new_orphans.append(o)
            moved += 1

    ann_obj['annotations'] = kept
    ann_obj['orphans'] = new_orphans
    if moved:
        # 孤儿迁移是数据实质变更，顶层时间戳要跟着走，否则这份文件的 updatedAt
        # 还停在迁移之前，看起来像没动过。
        ann_obj['updatedAt'] = now_iso()
    return ann_obj, moved


# ============================================================
# 渲染 index.html
# ============================================================

def _compute_source_file(page, output_dir: Path) -> str:
    """根据 page.sourceHtml 计算相对 output_dir 的相对路径，用于 iframe src。"""
    src = page.get('sourceHtml')
    if not src:
        return ''
    try:
        rel = os.path.relpath(Path(src).resolve(), output_dir.resolve())
    except Exception:
        return src  # 跨盘符等极端场景下退回绝对路径
    return rel.replace(os.sep, '/')


CANVAS_IMAGE_DIR = 'canvas-images'


def sweep_canvas_images(output_dir, layout_data, warnings):
    """删掉 assets/canvas-images/ 下没被 layout 引用的图片。

    保留集按 basename 比对而不是整条路径：前端存的是 'assets/canvas-images/<hash>.webp'，
    但导入的旧数据里可能是别的写法，只认文件名不会因为路径前缀的变体而误删。

    只在 serverMode 下才可能有图片落到这个目录，而那种模式下 layout.json 就是权威版本，
    所以「不在 layout 里 = 没人引用」这个判断是成立的。
    """
    image_dir = output_dir / 'assets' / CANVAS_IMAGE_DIR
    if not image_dir.is_dir():
        return {"dir": None, "kept": 0, "removed": []}

    referenced = set()
    for sh in layout_data.get('shapes', []) or []:
        if not isinstance(sh, dict) or sh.get('kind') != 'image':
            continue
        src = sh.get('src')
        if isinstance(src, str) and src:
            referenced.add(src.rsplit('/', 1)[-1])

    removed = []
    for path in sorted(image_dir.iterdir()):
        if not path.is_file() or path.name in referenced:
            continue
        try:
            path.unlink()
            removed.append(path.name)
        except OSError as e:
            warnings.append(f"清理无引用图片 {path.name} 失败：{e}")

    return {
        "dir": str(image_dir),
        "kept": len(referenced),
        "removed": removed,
    }


def _resolve_demo_entry(output_dir: Path):
    """「演示」入口按站点里实际存在的产物解析，写进 pages.json 供前端渲染切换条。

    两种平台的演示壳同路径：demo/demo.html（APP 是手机框壳，中台是页面索引页）。
    没有则返回 None，前端不渲染切换条，不留死链。
    """
    if (output_dir / 'demo' / 'demo.html').is_file():
        return 'demo/demo.html'
    return None


def _load_json_or_die(path: Path, label: str, hint: str):
    """读 json；不存在返回 None；损坏时保留 .corrupt 副本、打印 JSON 错误并 exit 3。

    pages / annotations / layout 都是高代价人工或机器产物，绝不用空值覆盖坏文件。
    """
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as e:
        preserved = None
        try:
            corrupt_bak = path.with_suffix(path.suffix + f'.corrupt.{stamp_for_backup()}')
            shutil.copy2(path, corrupt_bak)
            preserved = str(corrupt_bak)
        except Exception:
            pass
        print(json.dumps({
            "error": f"{label} 解析失败：{e}",
            "hint": hint,
            "path": str(path),
            "preservedCopy": preserved,
        }, ensure_ascii=False))
        sys.exit(3)


def write_data_files(output_dir: Path, pages_data, ann_data, layout_data):
    """三段数据各写 json + js 镜像；镜像供 file:// 打开时 <script src> 读取。"""
    out = []
    for name, data in (('pages', pages_data), ('annotations', ann_data), ('layout', layout_data)):
        target = output_dir / f'{name}.json'
        mirror = write_json_with_mirror(target, data)
        out.extend([str(target), str(mirror)])
    return out


def copy_server_script(output_dir: Path) -> str:
    """把本地写服务拷进站点目录：启动器按相对路径引用它，站点目录拷到别的机器也能起。"""
    src = SCRIPT_DIR / 'canvas_server.py'
    dst = output_dir / 'canvas_server.py'
    shutil.copy2(src, dst)
    return str(dst)


CANVAS_ASSET_FILES = ('canvas.css', 'canvas.js')


def copy_canvas_assets(output_dir: Path) -> list[str]:
    """画布样式与逻辑从 skill 拷进 assets/，每次 build 覆盖：skill 里的版本是唯一源。"""
    assets = output_dir / 'assets'
    assets.mkdir(parents=True, exist_ok=True)
    out = []
    for name in CANVAS_ASSET_FILES:
        dst = assets / name
        shutil.copy2(SKILL_ROOT / 'references' / name, dst)
        out.append(str(dst))
    return out


def write_canvas_shell(output_dir: Path) -> str:
    """index.html 是模板的原样副本：壳里没有占位符，数据与逻辑都在运行时从相对路径加载。"""
    dst = output_dir / 'index.html'
    shutil.copy2(TEMPLATE_PATH, dst)
    return str(dst)


# ============================================================
# 备份
# ============================================================

def backup_if_exists(path: Path, backups: list):
    if path.exists():
        bak = path.with_suffix(path.suffix + f'.bak.{stamp_for_backup()}')
        shutil.copy2(path, bak)
        backups.append(str(bak))


# ============================================================
# Main
# ============================================================

def main():
    ap = argparse.ArgumentParser(description=(__doc__ or '').splitlines()[1])
    ap.add_argument('--input', required=True, help='文件夹或单 html 的绝对路径')
    ap.add_argument('--output', required=True, help='输出目录绝对路径（一般是 ./prototypes 站点根，三件套与 pages/ demo/ assets/ 同级）')
    ap.add_argument(
        '--theme',
        default=None,
        choices=['light', 'dark'],
        help='站点默认主题，写进 pages.json 的 viewDefaults；不传沿用已有值。查看者自己切过色时以其本机偏好为准',
    )
    ap.add_argument(
        '--locked',
        dest='locked',
        action='store_true',
        default=None,
        help='站点默认锁定标注：发只读评审副本时用，查看者仍可自行解锁',
    )
    ap.add_argument('--no-locked', dest='locked', action='store_false', help='取消站点默认锁定')
    ap.add_argument(
        '--force-mode',
        default=None,
        choices=['new-folder', 'new-single', 'merge', 'update-page', 'add-page'],
        help='强制指定模式（默认自动判断）',
    )
    args = ap.parse_args()

    input_path = Path(args.input).expanduser().resolve()
    output_dir = Path(args.output).expanduser().resolve()

    if not input_path.exists():
        print(json.dumps({"error": f"input not found: {input_path}"}, ensure_ascii=False))
        sys.exit(2)
    if input_path.is_file() and input_path.suffix.lower() != '.html':
        print(json.dumps({"error": f"input must be a directory or .html file: {input_path}"}, ensure_ascii=False))
        sys.exit(2)

    output_dir.mkdir(parents=True, exist_ok=True)
    pages_path = output_dir / 'pages.json'
    ann_path = output_dir / 'annotations.json'
    hidden_path = output_dir / 'hidden.json'
    layout_path = output_dir / 'layout.json'

    mode = args.force_mode or detect_mode(input_path, output_dir)

    existing = _load_json_or_die(pages_path, 'pages.json', '已保留坏文件副本，人工修复 JSON 后重跑。')
    old_pages_list = (existing or {}).get('pages', [])

    warnings = []
    new_pages_list, build_summary = build_pages(input_path, existing, mode, warnings)

    ann_data = _load_json_or_die(ann_path, 'annotations.json', '已保留坏文件副本，人工修复 JSON 后重跑；生成器不会用空标注覆盖，避免标注丢失。')
    if ann_data is None:
        ann_data = {"version": "1", "annotations": [], "orphans": []}
    ann_data.setdefault('annotations', [])
    ann_data.setdefault('orphans', [])
    ann_data.setdefault('version', '1')
    # updatedAt 是导入合并判定同 id 标注新旧的依据，缺字段的一侧一律判输。只在缺失时补，
    # 不覆盖已有值——落盘时间由写服务在每次 PUT 时盖，生成器不该把它往前推。
    ann_data.setdefault('updatedAt', now_iso())

    ann_data, orphans_added = handle_orphans(ann_data, old_pages_list, new_pages_list, mode)

    # hidden.json：评审主观隐藏。文件缺失时给空对象；损坏时保留 .corrupt 副本再 fail-fast，
    # 避免用空对象覆盖用户已有的隐藏配置。
    hidden_data = _load_json_or_die(hidden_path, 'hidden.json', '已保留坏文件副本，人工修复 JSON 后重跑；生成器不会用空对象覆盖，避免隐藏配置丢失。')
    if hidden_data is None:
        hidden_data = {"version": "1", "updatedAt": now_iso(), "pages": [], "frames": []}
    hidden_data.setdefault('pages', [])
    hidden_data.setdefault('frames', [])
    hidden_data.setdefault('version', '1')
    hidden_data.setdefault('updatedAt', now_iso())

    # layout.json：画布编排（实例坐标 + 图形）。损坏时保留 .corrupt 副本再 fail-fast，
    # 与 annotations / hidden 一致——编排是人工产物，不能用空布局覆盖。
    existing_layout = _load_json_or_die(layout_path, 'layout.json', '已保留坏文件副本，人工修复 JSON 后重跑；生成器不会用空布局覆盖，避免编排丢失。')

    layout_data, layout_summary = layout_mod.build_layout(
        new_pages_list, existing_layout, hidden_data
    )

    # 标注宿主绑定：先补 instanceId（老数据迁移），再把无宿主的迁孤儿。
    # 顺序不能反——反了会把本可补齐的老标注全判成孤儿。
    ann_data, inst_migrated = layout_mod.attach_instance_ids(ann_data, layout_data)
    ann_data, inst_orphaned = layout_mod.orphan_by_missing_instance(ann_data, layout_data)
    orphans_added += inst_orphaned

    visible = [p for p in new_pages_list if not p.get('missing')]
    initial_page = (
        sorted(visible, key=lambda p: p.get('order', 999))[0]['id']
        if visible else (new_pages_list[0]['id'] if new_pages_list else '')
    )
    for p in new_pages_list:
        if not p.get('missing'):
            p['sourceFile'] = _compute_source_file(p, output_dir)
    _prev_view = (existing or {}).get('viewDefaults') or {}
    pages_data = {
        "version": "1",
        "generatedAt": now_iso(),
        "project": output_dir.parent.name or 'PRD Canvas',
        "initialPage": initial_page,
        "demoEntry": _resolve_demo_entry(output_dir),
        # 站点默认视图偏好。不传参数就沿用上一次的值，重建不会把人设好的默认抹掉
        "viewDefaults": {
            "theme": args.theme or _prev_view.get('theme') or 'light',
            "locked": bool(_prev_view.get('locked', False)) if args.locked is None else bool(args.locked),
        },
        "pages": new_pages_list,
    }

    backups = []
    if mode not in ('new-folder', 'new-single') or pages_path.exists():
        for f in (pages_path, ann_path, layout_path):
            backup_if_exists(f, backups)

    data_files = write_data_files(output_dir, pages_data, ann_data, layout_data)

    # hidden.json 的职责由 layout.json 承接。首次构建吸收完它的配置后改名归档，
    # 避免两份语义重叠的数据并存（「隐藏」与「未添加」在画布上看不出区别）。
    # 已有 layout 时说明迁移早已发生，原样留着不动，等下次首次构建或人工清理。
    hidden_retired = None
    if existing_layout is None and hidden_path.exists():
        retired = hidden_path.with_suffix(hidden_path.suffix + f'.retired.{stamp_for_backup()}')
        shutil.move(str(hidden_path), str(retired))
        hidden_retired = str(retired)

    # vendor 资源本地化：从 skill 内置种子 references/vendor/ 复制到 assets/vendor/（幂等，
    # 种子版本号匹配则跳过）。本地 copy 不走网络；种子缺失或 copy 失败会 append warning，
    # 由 stdout 的 vendor / warnings 字段汇报，需老大跑 scripts/refresh_vendor_seed.py 修复。
    vendor_results = vendor_assets.ensure_vendor(output_dir, warnings)
    server_script = copy_server_script(output_dir)
    canvas_assets = copy_canvas_assets(output_dir)
    index_file = write_canvas_shell(output_dir)

    # 贴进画布的图片是二进制、会随 prototypes/ 进 git，删掉图形后磁盘上的文件不会自己走。
    # 这里按刚写盘的 layout.json 对账一次，清掉没人引用的，防止仓库被历史截图撑大。
    image_sweep = sweep_canvas_images(output_dir, layout_data, warnings)

    # dev-prd 清单：扫 prototypes/dev-prd/*.md 写 dev-prd-index.json，供画布「需求文档」分屏读取。
    # build 阶段只是兜底；lon-req-clarify 落盘新 PRD 时也会自行调 update_dev_prd_index.py 单独刷新。
    try:
        dev_prd_index_path = update_dev_prd_index.write_index(output_dir)
        dev_prd_index_summary = json.loads(dev_prd_index_path.read_text(encoding='utf-8'))
        dev_prd_index_info = {
            "path": str(dev_prd_index_path),
            "fileCount": len(dev_prd_index_summary.get("files", [])),
            "latest": dev_prd_index_summary.get("latest"),
        }
    except Exception as e:
        warnings.append(f"dev-prd-index.json 生成失败：{e}；画布的「需求文档」分屏将显示为空")
        dev_prd_index_info = {"path": None, "fileCount": 0, "latest": None, "error": str(e)}

    # 相关文档清单：建出 refs/ 并扫成 refs-index.json，供画布左上角「相关文档」区读取。
    # 本地起写服务时画布走实时扫描端点，这份索引是 file:// 与导出静态包那条路的数据源。
    try:
        update_refs_index.ensure_refs_dir(output_dir)
        refs_index_path = update_refs_index.write_index(output_dir)
        refs_index_summary = json.loads(refs_index_path.read_text(encoding='utf-8'))
        refs_index_info = {
            "path": str(refs_index_path),
            "fileCount": len(refs_index_summary.get("files", [])),
        }
    except Exception as e:
        warnings.append(f"refs-index.json 生成失败：{e}；画布的「相关文档」区将显示为空")
        refs_index_info = {"path": None, "fileCount": 0, "error": str(e)}

    out = {
        "mode": mode,
        "outputDir": str(output_dir),
        "summary": {
            "totalPages": len(new_pages_list),
            "totalStates": sum(len(p.get('mainStates', [])) for p in new_pages_list),
            "totalOverlays": sum(len(p.get('overlays', [])) for p in new_pages_list),
            "totalTriggers": sum(len(p.get('triggers', [])) for p in new_pages_list),
            "newPages": build_summary.get('new', 0),
            "updatedPages": build_summary.get('updated', 0),
            "missingPages": build_summary.get('missing', 0),
            "keptPages": build_summary.get('kept', 0),
            "orphansAdded": orphans_added,
            "annotationsBoundToInstance": inst_migrated,
            "hiddenPages": len(hidden_data.get('pages', [])),
            "hiddenFrames": len(hidden_data.get('frames', [])),
            "layoutFrames": len(layout_data['frames']),
            "layoutShapes": len(layout_data['shapes']),
            "layoutCreated": layout_summary['created'],
            "layoutRemoved": layout_summary['removed'],
            "layoutMigratedFromHidden": layout_summary['migratedFromHidden'],
        },
        "initialPage": pages_data['initialPage'],
        "indexFile": index_file,
        "pageOverview": [
            {
                "id": p['id'],
                "order": p.get('order'),
                "name": p.get('name'),
                "states": [s['label'] for s in p.get('mainStates', [])],
                "overlays": [f"{o['label']}({o['kind']})" for o in p.get('overlays', [])],
                "triggers": len(p.get('triggers', [])),
                "missing": p.get('missing', False),
            }
            for p in new_pages_list
        ],
        "warnings": warnings,
        "backups": backups,
        "hiddenRetired": hidden_retired,
        "vendor": vendor_results,
        "canvasImages": image_sweep,
        "devPrdIndex": dev_prd_index_info,
        "refsIndex": refs_index_info,
        "dataFiles": data_files,
        "serverScript": server_script,
        "canvasAssets": canvas_assets,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
