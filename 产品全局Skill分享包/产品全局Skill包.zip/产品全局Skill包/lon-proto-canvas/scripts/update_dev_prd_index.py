#!/usr/bin/env python3
"""update_dev_prd_index.py — 扫描 prototypes/dev-prd/*.md 写入 dev-prd-index.json。

画布右侧「需求文档」分屏的清单数据源。可由 build_canvas.py import 调用，
也可由 lon-req-clarify Phase 6 落盘新 PRD 后单独触发：

  python3 update_dev_prd_index.py <prototypes_dir>

dev-prd 目录约定文件名形如 `{产品名}-PRD-v{x.y.z}.md`，版本号按语义化降序排序；
无版本号的回落到 mtime 降序。

清单与每篇正文都同时写出 .js 镜像：file:// 下打开画布 fetch 不可用，分屏只能读镜像。
正文一篇一个镜像文件、由画布按需 <script src> 加载——dev-prd 会累积历史版本，
打成一包会让首屏白白拖着几百 KB 谁也没点开的旧版本。
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from canvas_server import write_json_with_mirror, write_mirror

INDEX_FILENAME = "dev-prd-index.json"
DEV_PRD_DIRNAME = "dev-prd"
MIRROR_SUFFIX = ".js"

# {产品名}-PRD-v{major}.{minor}[.{patch}].md  patch 可缺省
VERSION_RE = re.compile(r"-PRD-v(\d+)\.(\d+)(?:\.(\d+))?", re.IGNORECASE)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _parse_version(name: str) -> tuple[int, int, int] | None:
    m = VERSION_RE.search(name)
    if not m:
        return None
    major, minor, patch = m.group(1), m.group(2), m.group(3)
    return (int(major), int(minor), int(patch) if patch else 0)


def _product_name(stem: str) -> str:
    """剥掉 -PRD-vX.Y.Z 后缀，返回产品名；无版本号则原样返回 stem。"""
    return VERSION_RE.split(stem, maxsplit=1)[0] if VERSION_RE.search(stem) else stem


def scan(prototypes_dir: Path) -> dict:
    """扫描 <prototypes_dir>/dev-prd/*.md，返回 index 结构。dev-prd 不存在时 files 为空。"""
    dev_prd_dir = prototypes_dir / DEV_PRD_DIRNAME
    files: list[dict] = []

    if dev_prd_dir.is_dir():
        for md in sorted(dev_prd_dir.glob("*.md")):
            stem = md.stem
            version_tuple = _parse_version(stem)
            mtime = md.stat().st_mtime
            files.append({
                "file": md.name,
                "name": stem,
                "product": _product_name(stem),
                "version": ".".join(str(x) for x in version_tuple) if version_tuple else None,
                "versionTuple": list(version_tuple) if version_tuple else None,
                "mtime": mtime,
                "mtimeIso": datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat(timespec="seconds"),
                "size": md.stat().st_size,
            })

    # 同时按版本号降序、再按 mtime 降序（无版本号的项靠 mtime 排到对应位置）
    files.sort(
        key=lambda f: (
            f["versionTuple"] is not None,
            f["versionTuple"] or [0, 0, 0],
            f["mtime"],
        ),
        reverse=True,
    )

    latest = files[0]["file"] if files else None
    return {
        "version": "1",
        "generatedAt": _now_iso(),
        "devPrdDir": DEV_PRD_DIRNAME,
        "latest": latest,
        "files": files,
    }


def write_content_mirrors(prototypes_dir: Path, index: dict) -> list[Path]:
    """给 index 里每篇 PRD 正文写 dev-prd/<文件名>.js 镜像，并扫掉没有对应 md 的孤儿镜像。

    取数键用站点内相对路径 dev-prd/<文件名>，与画布 loadMirror 拼 script src 的 name 同源。
    孤儿要扫：md 改名或删版本后留下的镜像既不会被任何清单引用，又会跟着导出包一路带走。
    """
    dev_prd_dir = prototypes_dir / DEV_PRD_DIRNAME
    if not dev_prd_dir.is_dir():
        return []

    written: list[Path] = []
    for entry in index.get("files", []):
        md = dev_prd_dir / entry["file"]
        if not md.is_file():
            continue
        mirror = md.with_name(md.name + MIRROR_SUFFIX)
        key = f"{DEV_PRD_DIRNAME}/{entry['file']}"
        written.append(write_mirror(mirror, key, md.read_text(encoding="utf-8")))

    keep = {p.name for p in written}
    for stale in dev_prd_dir.glob(f"*.md{MIRROR_SUFFIX}"):
        if stale.name not in keep:
            stale.unlink()
    return written


def write_index(prototypes_dir: Path) -> Path:
    """扫描并写入 <prototypes_dir>/dev-prd-index.json（含 .js 镜像）与各篇正文镜像，返回 json 路径。"""
    prototypes_dir = prototypes_dir.expanduser().resolve()
    index = scan(prototypes_dir)
    out = prototypes_dir / INDEX_FILENAME
    write_json_with_mirror(out, index)
    write_content_mirrors(prototypes_dir, index)
    return out


def main():
    if len(sys.argv) < 2:
        print("usage: update_dev_prd_index.py <prototypes_dir>", file=sys.stderr)
        sys.exit(2)
    prototypes_dir = Path(sys.argv[1])
    if not prototypes_dir.exists():
        print(json.dumps(
            {"error": f"prototypes_dir not found: {prototypes_dir}"},
            ensure_ascii=False,
        ))
        sys.exit(2)
    out = write_index(prototypes_dir)
    index = json.loads(out.read_text(encoding="utf-8"))
    print(json.dumps({
        "indexPath": str(out),
        "fileCount": len(index["files"]),
        "latest": index["latest"],
        "generatedAt": index["generatedAt"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
