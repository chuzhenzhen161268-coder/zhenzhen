#!/usr/bin/env python3
"""
export_site.py — 把站点目录导出成可托管到任意静态服务的干净静态包。

  python3 export_site.py --site ./prototypes --out ./dist/prototypes [--clean]

剔除：本地写服务、启动器、备份 / 损坏 / 归档副本、临时文件、图标缓存、遗留的 hidden.json、
      系统垃圾。
校验：pages.json 的 sourceFile、layout.json 里图片的 src、index.html 引用的画布资产，
      必须都在本次拷贝的文件集合里，且在输出目录里路径大小写完全一致地存在
      （对象存储与多数 CDN 大小写敏感；只查磁盘存在会被不带 --clean 时输出目录里
      残留的上一轮文件糊弄过去）。
报告：stdout 一段 JSON（文件数、总字节、最大文件、含非 ASCII 字符的路径、剔除清单、
      缺失引用、相关文档对账 warning、读取错误）；有缺失引用或读取错误时退出码 1。
      不硬编码任何托管平台的阈值，限制由发布工具自己判断。

两条前提，不成立时校验结论会失真：
  - 剔除 assets/icons/ 的前提是图标已 inline 进各页 HTML，那个目录只是下载缓存层。
    若某一版生成器改成运行时 <img src="assets/icons/..."> 引用，这里必须同步放行。
  - check_references 只查上面列出的三处引用源，不解析 pages/*.html 自身引用的图片、
    字体、脚本。单页原型自带的资源由生成端保证内联或同目录随迁。
"""
from __future__ import annotations
import argparse
import json
import os
import re
import shutil
import sys
from pathlib import Path, PurePosixPath

# 目录名与后缀跟着扫描端走，两处各写一份迟早对不上
from canvas_server import REFS_DIR_NAME, REFS_SUFFIXES

# hidden.json 是生成器首次构建时吸收进 layout.json 后即归档的遗留输入，画布运行时不读它
EXCLUDE_NAMES = {"canvas_server.py", "hidden.json", ".DS_Store", "Thumbs.db"}
EXCLUDE_DIR_NAMES = {"__pycache__"}
EXCLUDE_SUFFIXES = (".command", ".bat", ".tmp", ".pyc")
EXCLUDE_INFIXES = (".bak.", ".corrupt.", ".retired.")
EXCLUDE_DIRS = (PurePosixPath("assets/icons"),)   # 图标缓存层，实际已 inline 进 HTML
ASSET_REF_RE = re.compile(r'(?:href|src)="(assets/canvas\.(?:css|js))"')


def should_exclude(rel: PurePosixPath) -> bool:
    if rel.name in EXCLUDE_NAMES:
        return True
    if any(part in EXCLUDE_DIR_NAMES for part in rel.parts):
        return True
    if rel.suffix in EXCLUDE_SUFFIXES:
        return True
    if any(infix in rel.name for infix in EXCLUDE_INFIXES):
        return True
    return any(rel == d or d in rel.parents for d in EXCLUDE_DIRS)


def copy_site(site: Path, out: Path, clean: bool) -> list[str]:
    if clean and out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    copied: list[str] = []
    for path in sorted(p for p in site.rglob("*") if p.is_file()):
        rel = PurePosixPath(path.relative_to(site).as_posix())
        if should_exclude(rel):
            continue
        dst = out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)
        copied.append(str(rel))
    return copied


def exists_exact(root: Path, rel: str) -> bool:
    """逐段 listdir 比对：macOS / Windows 的文件系统大小写不敏感，Path.exists 会放过大小写错误。"""
    cur = root
    for part in PurePosixPath(rel).parts:
        if not cur.is_dir() or part not in os.listdir(cur):
            return False
        cur = cur / part
    return cur.is_file()


def _read_json(path: Path, errors: list[str]):
    """文件不存在返回 None（合法：老站点可能没有 layout.json）；解析失败也返回 None，
    但记一条错误。两者混为一谈的话，一份坏掉的 pages.json 会静默变成「零引用」，
    报告照样是「0 缺失」——正是最需要拦住的那种情况。"""
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        errors.append(f"{path.name} 解析失败：{e}")
        return None


def check_references(out: Path, copied: list[str], errors: list[str] | None = None) -> list[str]:
    """引用必须同时满足两个条件才算有效：在本次 copied（site 现场 walk 出来的大小写精确
    路径集合）里，且在 out 里 exists_exact 精确存在。只查 exists_exact 会在不带 --clean
    时被 out 目录里残留的上一轮拷贝糊弄过去——那些文件在磁盘上确实存在，但已经不是这次
    从 site 拷过来的了。"""
    if errors is None:
        errors = []
    copied_set = set(copied)
    refs: list[str] = []
    pages = _read_json(out / "pages.json", errors) or {}
    for p in pages.get("pages", []) or []:
        if isinstance(p, dict) and not p.get("missing") and p.get("sourceFile"):
            refs.append(p["sourceFile"])
    layout = _read_json(out / "layout.json", errors) or {}
    for sh in layout.get("shapes", []) or []:
        if isinstance(sh, dict) and sh.get("kind") == "image" and isinstance(sh.get("src"), str):
            refs.append(sh["src"])
    index = out / "index.html"
    if index.is_file():
        refs.extend(ASSET_REF_RE.findall(index.read_text(encoding="utf-8")))
    return sorted({r for r in refs if r not in copied_set or not exists_exact(out, r)})


def check_refs_index(out: Path, errors: list[str]) -> list[str]:
    """refs/ 里的 HTML 与 refs-index.json 对账，返回 warning 列表。

    索引是静态包里唯一的相关文档清单来源（本地写服务那条实时扫描的路在这里没有），
    两边对不上意味着发出去的包要么少列文档、要么点出 404。只报不改：这里的职责是
    拷贝与校验，重新生成索引是画布生成那一棒的事。
    """
    refs_dir = out / REFS_DIR_NAME
    on_disk = set()
    if refs_dir.is_dir():
        on_disk = {p.name for p in refs_dir.iterdir()
                   if p.is_file() and p.suffix.lower() in REFS_SUFFIXES}
    index = _read_json(out / "refs-index.json", errors)
    if not isinstance(index, dict):
        if on_disk:
            return [f"refs/ 下有 {len(on_disk)} 篇文档，但 refs-index.json 缺失或损坏，"
                    "画布的「相关文档」区会是空的；重跑一次画布生成"]
        return []
    listed = {f.get("file") for f in index.get("files", []) or [] if isinstance(f, dict)}
    warnings = [f"refs/{name} 不在 refs-index.json 里，画布不会列出它；重跑一次画布生成"
                for name in sorted(on_disk - listed)]
    warnings += [f"refs-index.json 列了 refs/{name}，但包里没有这个文件，点开会 404"
                 for name in sorted(listed - on_disk)]
    return warnings


def build_report(out: Path, copied: list[str], excluded: list[str], missing: list[str],
                 errors: list[str], warnings: list[str]) -> dict:
    sizes = {rel: (out / rel).stat().st_size for rel in copied}
    largest = sorted(sizes.items(), key=lambda kv: kv[1], reverse=True)[:10]
    return {
        "outDir": str(out),
        "fileCount": len(copied),
        "totalBytes": sum(sizes.values()),
        "largest": [{"path": p, "bytes": b} for p, b in largest],
        "nonAsciiPaths": [rel for rel in copied if not rel.isascii()],
        "excluded": excluded,
        "missingRefs": missing,
        "warnings": warnings,
        "errors": errors,
        "files": copied,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="导出可托管的干净静态包")
    ap.add_argument("--site", required=True, help="站点目录（一般是 ./prototypes）")
    ap.add_argument("--out", required=True, help="输出目录（一般是 ./dist/prototypes）")
    ap.add_argument("--clean", action="store_true", help="先清空输出目录")
    args = ap.parse_args()

    site = Path(args.site).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    if not site.is_dir():
        print(json.dumps({"error": f"站点目录不存在：{site}"}, ensure_ascii=False))
        return 2
    if out == site or site in out.parents or out in site.parents:
        print(json.dumps({"error": "输出目录不能是站点目录、站点目录的子目录，也不能是站点目录的祖先目录"}, ensure_ascii=False))
        return 2

    excluded = sorted(
        str(PurePosixPath(p.relative_to(site).as_posix()))
        for p in site.rglob("*") if p.is_file() and should_exclude(PurePosixPath(p.relative_to(site).as_posix()))
    )
    errors: list[str] = []
    copied = copy_site(site, out, clean=args.clean)
    missing = check_references(out, copied, errors)
    warnings = check_refs_index(out, errors)
    print(json.dumps(build_report(out, copied, excluded, missing, errors, warnings), ensure_ascii=False, indent=2))
    return 1 if (missing or errors) else 0


if __name__ == "__main__":
    raise SystemExit(main())
