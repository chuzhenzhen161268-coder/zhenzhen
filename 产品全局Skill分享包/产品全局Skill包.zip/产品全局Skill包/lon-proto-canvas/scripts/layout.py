#!/usr/bin/env python3
"""layout.json 的生成与合并。

layout.json 是「画布上有什么」的唯一真相源：frames 是实例数组（同一个
pageId#frameKey 可出现多次，各有独立 id 与坐标），shapes 是画布图形对象。

与 pages.json 的分工：pages.json 是机器扫描结果（原型里存在哪些页面与状态），
layout.json 是人的编排意图（把哪些搬上画布、摆在哪）。两者生命周期不同，
所以分文件存放。
"""
from __future__ import annotations

import datetime
import hashlib

# 画布排布常量。CAPTION_H 是卡片上方标题行占位；GAP_X / GAP_Y 是卡片间与页间的呼吸区。
# 卡片本身的宽高不是常量：按页面的视口档位取（pages.json 的 page.viewport，
# 由 build_canvas.py 的 resolve_viewport 写入），与 canvas-template.html 的
# --frame-w / --frame-h 同源。缺字段的旧 pages.json 回退手机壳。
FALLBACK_VIEWPORT = (375, 812)
GAP_X = 48
GAP_Y = 120
CAPTION_H = 24

LAYOUT_VERSION = "2"


def now_iso() -> str:
    """毫秒精度 ISO 时间戳，格式与前端 nowIso()（`new Date().toISOString()`）对齐。

    updatedAt 字段在前端做字符串大小比较，仲裁 inline / localStorage / 服务端三级
    来源；两侧精度不一致（秒级 vs 毫秒级）会导致同一秒内的比较结果按字典序而非时间序
    判定，得出错误的仲裁结果。
    """
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def _as_list(value) -> list:
    """非 list 值一律当空列表处理。

    layout.json 由 canvas_server.py 的 PUT /api/canvas/layout 接口写盘，服务端只做
    最小形状校验；existing_layout 里的 frames / shapes 仍可能是历史遗留脏数据或校验
    上线前写入的畸形值（如显式 null）。这里做防御性取值，避免 `.get(key, [])` 对
    「键存在但值是 None」的情况不生效（返回 None 而非默认值）而在下面的 for 循环里炸出
    TypeError。
    """
    return value if isinstance(value, list) else []


def make_instance_id(page_id: str, frame_key: str, seq: int) -> str:
    """确定性实例 id。

    用哈希而非随机数，是为了让 build 可重跑幂等、测试可断言。前端手动添加实例
    时用随机 id，两者只需保证不撞车，不需要同一套算法。
    """
    raw = f"{page_id}#{frame_key}#{seq}"
    return "fi-" + hashlib.sha1(raw.encode("utf-8")).hexdigest()[:6]


def ordered_frame_keys(page: dict) -> list[str]:
    """复刻前端的 frame 排布顺序：每个主状态后紧跟它触发的浮层，未关联浮层殿后。

    这个顺序决定首次铺开的坐标，必须与前端的 frame 排布一致，否则画布视觉错位。
    """
    triggers = page.get('triggers', [])
    overlay_keys = {o['key'] for o in page.get('overlays', [])}
    used: set[str] = set()
    out: list[str] = []

    for s in page.get('mainStates', []):
        out.append(s['key'])
        for t in triggers:
            if t.get('stateKey') != s['key']:
                continue
            ok = t.get('overlayKey')
            if ok in used or ok not in overlay_keys:
                continue
            used.add(ok)
            out.append(ok)

    for o in page.get('overlays', []):
        if o['key'] not in used:
            out.append(o['key'])

    return out


def _hidden_keys(hidden_data: dict, pages: list[dict]) -> set[str]:
    """把 hidden.json 的 pages / frames 两级配置摊平成 'pageId#frameKey' 集合。"""
    out: set[str] = set(hidden_data.get('frames', []))
    hidden_pages = set(hidden_data.get('pages', []))
    for p in pages:
        if p['id'] not in hidden_pages:
            continue
        for key in ordered_frame_keys(p):
            out.add(f"{p['id']}#{key}")
    return out


def page_viewport(page: dict | None) -> tuple[int, int]:
    """页面的视口档位 (宽, 高)。字段缺失或非法时回退手机壳。"""
    vp = (page or {}).get('viewport') or {}
    w, h = vp.get('width'), vp.get('height')
    return (
        w if isinstance(w, (int, float)) and w > 0 else FALLBACK_VIEWPORT[0],
        h if isinstance(h, (int, float)) and h > 0 else FALLBACK_VIEWPORT[1],
    )


def _viewport_map(pages_list: list[dict]) -> dict:
    """pageId → (宽, 高)，供按实例查所属页面的卡片尺寸。"""
    return {p['id']: page_viewport(p) for p in pages_list if isinstance(p, dict) and p.get('id')}


def _anchor_xy(x: float, y: float, anchor: str | None, size: tuple[int, int]) -> dict:
    """卡片四个边中点的绝对坐标。size 是该卡片的视口档位 (宽, 高)。"""
    fw, fh = size
    h = fh + CAPTION_H
    if anchor == 'top':
        return {"x": x + fw / 2, "y": y}
    if anchor == 'bottom':
        return {"x": x + fw / 2, "y": y + h}
    if anchor == 'left':
        return {"x": x, "y": y + h / 2}
    return {"x": x + fw, "y": y + h / 2}


def detach_arrows(shapes: list, frames: list, removed_ids: set, viewports: dict | None = None) -> list:
    """引用了已删实例的箭头端点降级为绝对坐标，箭头本身保留。

    坐标按视口档位的基准尺寸估算：Python 侧读不到 iframe 的自适应渲染高度，
    结果与前端 detachArrowsFromHost 用 offsetHeight 算出的值可能差几十像素。
    降级是一次性的，之后用户直接拖端点就能校正，不值得为此把渲染高度回写进 layout.json。

    viewports 是 pageId → (宽, 高)；缺省或查不到该页时按手机壳算。
    """
    if not removed_ids:
        return list(shapes)
    viewports = viewports or {}
    pos = {
        f.get('id'): (f.get('x') or 0, f.get('y') or 0,
                      viewports.get(f.get('pageId'), FALLBACK_VIEWPORT))
        for f in frames
        if isinstance(f, dict) and f.get('id') in removed_ids
    }
    out = []
    for sh in shapes:
        if not isinstance(sh, dict) or sh.get('kind') != 'arrow':
            out.append(sh)
            continue
        new_sh = dict(sh)
        for key in ('from', 'to'):
            end = new_sh.get(key)
            if not isinstance(end, dict):
                continue
            iid = end.get('instanceId')
            # 自由端没有 instanceId，取出来是 None；removed_ids 里可能也有个 None
            # （被删的 frame 字典缺 id 键），不先排空值会把自由端判成命中，
            # 坐标被覆盖成另一张卡片的锚点
            if not iid or iid not in removed_ids:
                continue
            # 命中时 pos 里必有这个 id：removed_ids 本就是从 frames 里挑出来的。
            # 取不到说明调用方给的两份数据不配套，宁可炸出来也不要兜底成 (0, 0)——
            # 那会把箭头端点静默塌到画布原点。
            x, y, size = pos[iid]
            new_sh[key] = _anchor_xy(x, y, end.get('anchor'), size)
        out.append(new_sh)
    return out


def build_layout(
    pages_list: list[dict],
    existing_layout: dict | None,
    hidden_data: dict,
) -> tuple[dict, dict]:
    """生成或合并 layout.json。

    首次（existing_layout 为 None）全量铺开，hidden.json 里标记过的跳过并计入
    migratedFromHidden；已有 layout 时只做减法（清理 pages.json 中已消失的
    frameKey 与 missing 页的实例），绝不自动新增——画布上有什么由用户决定。
    """
    live_keys: set[str] = set()
    for p in pages_list:
        if p.get('missing'):
            continue
        for key in ordered_frame_keys(p):
            live_keys.add(f"{p['id']}#{key}")

    if existing_layout is None:
        hidden = _hidden_keys(hidden_data, pages_list)
        frames = []
        migrated = 0
        # 一页一行横向铺开。行高与列距按该页自己的视口档位走：手机页与中台页
        # 在同一张画布上并排时，中台那行不会被按 375 的间距挤成重叠。
        y = 0
        for p in sorted(pages_list, key=lambda x: x.get('order') or 0):
            if p.get('missing'):
                continue
            fw, fh = page_viewport(p)
            x = 0
            placed_any = False
            for seq, key in enumerate(ordered_frame_keys(p)):
                if f"{p['id']}#{key}" in hidden:
                    migrated += 1
                    continue
                frames.append({
                    "id": make_instance_id(p['id'], key, seq),
                    "pageId": p['id'],
                    "frameKey": key,
                    "x": x,
                    "y": y,
                })
                x += fw + GAP_X
                placed_any = True
            if placed_any:
                y += fh + CAPTION_H + GAP_Y
        return (
            {
                "version": LAYOUT_VERSION,
                "updatedAt": now_iso(),
                "frames": frames,
                "shapes": [],
            },
            {"created": len(frames), "removed": 0, "migratedFromHidden": migrated},
        )

    existing_frames = _as_list(existing_layout.get('frames'))
    existing_shapes = _as_list(existing_layout.get('shapes'))
    kept = [
        f for f in existing_frames
        if f"{f.get('pageId')}#{f.get('frameKey')}" in live_keys
    ]
    removed = len(existing_frames) - len(kept)
    kept_ids = {f.get('id') for f in kept if isinstance(f, dict)}
    removed_ids = {
        f.get('id') for f in existing_frames
        if isinstance(f, dict) and f.get('id') not in kept_ids
    }
    shapes = detach_arrows(existing_shapes, existing_frames, removed_ids, _viewport_map(pages_list))
    # 一个字节都没变时沿用旧 updatedAt：file:// 模式下前端靠 updatedAt 做字符串大小比较
    # 仲裁 inline / localStorage 两级来源，时间戳被无谓刷新会让 localStorage 里的用户编排
    # （拖拽位置、增删实例）在下次 build 后被判定为「更旧」而永久丢失。
    unchanged = kept == existing_frames and shapes == existing_shapes
    return (
        {
            "version": LAYOUT_VERSION,
            "updatedAt": existing_layout.get('updatedAt') if unchanged else now_iso(),
            "frames": kept,
            "shapes": shapes,
        },
        {"created": 0, "removed": removed, "migratedFromHidden": 0},
    )


def attach_instance_ids(ann_obj: dict, layout_data: dict) -> tuple[dict, int]:
    """给缺 instanceId 的 frame 类标注补齐宿主实例。

    老标注只有 pageId + frameKey，多实例模型下需要指定挂在哪个实例上。同一
    frameKey 有多个实例时挂第一个——老数据本来就没有实例概念，用户可在孤儿
    抽屉重新挂载调整。配不上宿主的留空，交给 orphan_by_missing_instance 处理。
    """
    first_by_key: dict[str, str] = {}
    for f in layout_data.get('frames', []):
        key = f"{f.get('pageId')}#{f.get('frameKey')}"
        first_by_key.setdefault(key, f.get('id'))

    migrated = 0
    for ann in ann_obj.get('annotations', []):
        a = ann.get('anchor', {})
        if a.get('kind') != 'frame' or a.get('instanceId'):
            continue
        inst = first_by_key.get(f"{a.get('pageId')}#{a.get('frameKey')}")
        if not inst:
            continue
        a['instanceId'] = inst
        migrated += 1

    return ann_obj, migrated


def orphan_by_missing_instance(ann_obj: dict, layout_data: dict) -> tuple[dict, int]:
    """宿主实例已不在画布上的标注迁入 orphans[]。

    覆盖两种情况：用户从添加面板删掉了实例，以及 attach_instance_ids 没能配上
    宿主的老标注。两者的共同点是标注失去了渲染位置——不迁孤儿就会静默隐身，
    用户以为标注丢了。
    """
    live_ids = {f.get('id') for f in layout_data.get('frames', [])}
    kept = []
    new_orphans = list(ann_obj.get('orphans', []))
    moved = 0

    for ann in ann_obj.get('annotations', []):
        a = ann.get('anchor', {})
        if a.get('kind') != 'frame':
            kept.append(ann)
            continue
        inst = a.get('instanceId')
        if inst and inst in live_ids:
            kept.append(ann)
            continue
        o = dict(ann)
        o['lostReason'] = (
            f"宿主实例 '{inst}' 已不在画布上"
            if inst
            else f"未能在画布上找到 '{a.get('pageId')}#{a.get('frameKey')}' 的实例"
        )
        o['lostAt'] = now_iso()
        new_orphans.append(o)
        moved += 1

    ann_obj['annotations'] = kept
    ann_obj['orphans'] = new_orphans
    return ann_obj, moved
