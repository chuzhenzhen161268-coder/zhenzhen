#!/usr/bin/env python3
"""update_refs_index.py — 扫描 prototypes/refs/*.html 写入 refs-index.json。

画布左上角「相关文档」区的清单数据源。独立单文件，可由 build_canvas.py import 调用，
也可在往 refs/ 里加完文档后单独触发：

  python3 update_refs_index.py <prototypes_dir>

扫描规则（目录名、收哪些后缀、展示名怎么取）与本地写服务的实时端点共用一份实现，
在 canvas_server.scan_refs——两处各写一份，服务在与不在会看到两份不同的清单。

清单同时写出 refs-index.js 镜像：file:// 下打开画布 fetch 不可用，那条路只能读镜像。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from canvas_server import REFS_DIR_NAME, scan_refs, write_json_with_mirror

INDEX_FILENAME = "refs-index.json"


def scan(prototypes_dir: Path) -> dict:
    """扫描 <prototypes_dir>/refs/*.html，返回 index 结构。refs 不存在时 files 为空。"""
    return scan_refs(prototypes_dir)


def ensure_refs_dir(prototypes_dir: Path) -> Path:
    """建出空的 refs/：跑完画布生成就有地方放文档，不用先猜目录名。"""
    refs_dir = prototypes_dir / REFS_DIR_NAME
    refs_dir.mkdir(parents=True, exist_ok=True)
    return refs_dir


def write_index(prototypes_dir: Path) -> Path:
    """扫描并写入 <prototypes_dir>/refs-index.json（含 .js 镜像），返回 json 路径。"""
    prototypes_dir = prototypes_dir.expanduser().resolve()
    index = scan(prototypes_dir)
    out = prototypes_dir / INDEX_FILENAME
    write_json_with_mirror(out, index)
    return out


def main():
    if len(sys.argv) < 2:
        print("usage: update_refs_index.py <prototypes_dir>", file=sys.stderr)
        sys.exit(2)
    prototypes_dir = Path(sys.argv[1])
    if not prototypes_dir.exists():
        print(json.dumps(
            {"error": f"prototypes_dir not found: {prototypes_dir}"},
            ensure_ascii=False,
        ))
        sys.exit(2)
    ensure_refs_dir(prototypes_dir)
    out = write_index(prototypes_dir)
    index = json.loads(out.read_text(encoding="utf-8"))
    print(json.dumps({
        "indexPath": str(out),
        "refsDir": index["refsDir"],
        "fileCount": len(index["files"]),
        "generatedAt": index["generatedAt"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
