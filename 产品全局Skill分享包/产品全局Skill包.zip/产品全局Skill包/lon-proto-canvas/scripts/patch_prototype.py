#!/usr/bin/env python3
"""patch_prototype.py — 向原型 HTML 幂等注入 canvasMode bootstrap + patch CSS

iframe 化的 lon-proto-canvas 画布通过 `?canvasMode=1#<frameKey>` 加载原型 HTML，
原型内必须有一段 bootstrap 脚本：解析 URL → 切换到指定 frame → 注入 patch CSS
（解开 height/overflow 约束）→ postMessage 回报 scrollHeight 给父画布 → 内置「选元素 picker」桥接。

picker 桥接必须内置而非由父画布注入：file:// 下每个文件是独立 origin，父画布拿不到
iframe.contentDocument（Chromium 静默返回 null），注入路径必然失败，而评审画布的常态就是
本地双击打开。父画布保留的 injectBridge 只是 http:// 同源场景的兜底，两边靠 __pickerBridge 去重。

存量 HTML 还没埋这段，本脚本负责一次性补丁；通过 `data-canvas-mode-bootstrap` 版本
标记（见 CURRENT_VERSION）保证幂等。lon-proto-builder 新生成的 HTML 模板已内置同样的块，
新文件不会被二次注入。

用法：
  CLI：python3 patch_prototype.py <prototype-dir-or-file>
  Module：from patch_prototype import patch_html; patch_html(Path("01.html"))

输出（CLI）：JSON `{"patched": N, "skipped": M, "files": [...]}` 到 stdout
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import List, Tuple

# ---------------------------------------------------------------------------
# 注入内容：canvasMode patch CSS + bootstrap 脚本
# ---------------------------------------------------------------------------

PATCH_CSS = """<style data-canvas-mode-bootstrap="19">
html[data-canvas-mode="1"],
html[data-canvas-mode="1"] body {
  height: auto !important;
  min-height: 100vh;
  overflow: visible !important;
}
html[data-canvas-mode="1"] body { display: block !important; }
/* mark / remount 模式的 iframe 内表现。注意：平铺态起父画布就给 iframe 设了 pointer-events:none，
   光标与选区已由父文档接管，本段在当前实现下几乎不会生效；留着是兜底——万一 picker 异常退出
   残留了 inline pointer-events:auto，crosshair 仍能提示「这里点了也是打钉，不是操作原型」。 */
html[data-canvas-mode="1"][data-mark-active="1"],
html[data-canvas-mode="1"][data-mark-active="1"] * {
  cursor: crosshair !important;
  user-select: none !important;
  -webkit-user-select: none !important;
}
</style>"""

BOOTSTRAP_JS = r"""<script data-canvas-mode-bootstrap="19">
(function () {
  var p = new URLSearchParams(location.search);
  if (p.get('canvasMode') !== '1') return;
  document.documentElement.setAttribute('data-canvas-mode', '1');

  function readManifest() {
    var s = document.querySelector('script[type="application/canvas-manifest"]');
    if (!s) return null;
    try { return JSON.parse(s.textContent.trim()); } catch (e) { return null; }
  }

  function getFrameKey() {
    var h = (location.hash || '').replace(/^#/, '');
    if (!h) return null;
    var m = h.match(/^frame=(.+)$/);
    return m ? decodeURIComponent(m[1]) : decodeURIComponent(h);
  }

  function activate(frameKey) {
    if (!frameKey) return;
    var manifest = readManifest();
    var frames = (manifest && manifest.frames) || [];
    var target = null;
    for (var i = 0; i < frames.length; i++) {
      if (frames[i].key === frameKey) { target = frames[i]; break; }
    }
    if (!target) return;
    if (target.kind === 'state') {
      var group = [];
      for (var j = 0; j < frames.length; j++) {
        if (frames[j].kind === 'state') group.push(frames[j].key);
      }
      if (typeof window.switchFrame === 'function') {
        window.switchFrame(frameKey, group);
      } else {
        for (var k = 0; k < group.length; k++) {
          var el = document.querySelector('[data-frame="' + group[k] + '"]');
          if (el) el.hidden = (group[k] !== frameKey);
        }
      }
    } else if (target.kind === 'overlay') {
      var triggers = target.triggers || [];
      if (triggers[0] && triggers[0].fromStateKey) activate(triggers[0].fromStateKey);
      if (typeof window.toggleOverlay === 'function') {
        window.toggleOverlay(frameKey, true);
      } else {
        var oel = document.querySelector('[data-frame="' + frameKey + '"]');
        if (oel) oel.hidden = false;
      }
    }
  }

  function disableInteractions() {
    // 与画布「选元素 picker」工具协调：picker 模式打开时让路，关闭时恢复拦截
    window.__canvasPickerActive = false;
    window.addEventListener('message', function (e) {
      var d = e.data || {};
      if (d.type === 'picker:setActive') {
        // picker 选元素：放行点击命中子元素，bootstrap 这一层处理一致
        window.__canvasPickerActive = !!d.active;
        // 同步切换 data-picker-active：picker 模式下让外层 stage 的 .mark-active 失效，
        // e.target 能命中具体子元素（button/div），而不是停在 html 顶层
        if (d.active) {
          document.documentElement.setAttribute('data-picker-active', '1');
        } else {
          document.documentElement.removeAttribute('data-picker-active');
        }
      } else if (d.type === 'mark:setActive') {
        // mark / remount 模式：让 PATCH_CSS 的 cursor:crosshair + user-select:none 生效
        if (d.active) {
          document.documentElement.setAttribute('data-mark-active', '1');
        } else {
          document.documentElement.removeAttribute('data-mark-active');
        }
      }
    });

    function swallow(e) {
      if (window.__canvasPickerActive) {
        // picker 态要把 click 让给 bridge 上报选中元素，但 <a> 跳转 / form 提交必须仍然掐掉——
        // 一旦真跳走，iframe 就脱离了 canvasMode（新 URL 没有 ?canvasMode=1），整帧变成活页面。
        // 只 preventDefault、不掐传播：bridge 的 capture 监听要收得到这次 click。
        if (e.type === 'click' || e.type === 'submit') e.preventDefault();
        return;
      }
      // keydown 放行 cmd/ctrl + C / A：复制 + 全选是文字可选语义的硬前提
      if (e.type === 'keydown') {
        var meta = e.metaKey || e.ctrlKey;
        var k = (e.key || '').toLowerCase();
        if (meta && (k === 'c' || k === 'a')) return;
      }
      e.preventDefault();
      // capture 阶段 stopImmediatePropagation 会终止 target phase 的行内 onclick
      e.stopImmediatePropagation();
    }
    // wheel 不锁死，而是转发给父画布做平移/缩放：画布里 iframe 是静态快照、自身无需滚动，
    // 鼠标悬在 iframe 上时把滚轮中继出去，否则那片区域就成了滚动死区（picker 态一并转发，不影响选元素）
    function forwardWheel(e) {
      e.preventDefault();
      e.stopImmediatePropagation();
      try {
        parent.postMessage({
          type: 'canvas-wheel',
          deltaX: e.deltaX, deltaY: e.deltaY, deltaMode: e.deltaMode,
          ctrlKey: e.ctrlKey, metaKey: e.metaKey,
          clientX: e.clientX, clientY: e.clientY
        }, '*');
      } catch (err) {}
    }
    // 全交互拦截：click/submit + pointerup/touchend 触屏兜底 + keydown 键盘兜底 + contextmenu 右键菜单兜底
    ['click', 'submit', 'pointerup', 'touchend', 'keydown', 'contextmenu']
      .forEach(function (ev) { document.addEventListener(ev, swallow, true); });
    // touchmove 必须显式 passive:false：document 级浏览器默认 passive=true，preventDefault 会被静默忽略，
    // 导致 iframe 内背景滚动锁不住（浮层下面的 state 仍可滑）
    document.addEventListener('touchmove', swallow, { capture: true, passive: false });
    // wheel 同样 passive:false，由 forwardWheel 接管：先拦 iframe 自身滚动，再中继给父画布
    document.addEventListener('wheel', forwardWheel, { capture: true, passive: false });

    // 静默后续启动的定时器/动画/跳转（已经发生的同步代码不可回收，是接受的取舍）
    window.setInterval = function () { return 0; };
    window.requestAnimationFrame = function () { return 0; };
    try {
      history.pushState = function () {};
      history.replaceState = function () {};
      if (window.location && typeof window.location.assign === 'function') {
        window.location.assign = function () {};
        window.location.replace = function () {};
      }
    } catch (e) {}
  }

  // 选元素 picker 的桥接：内置在 bootstrap 里，而不是由父画布注入。
  // 父画布的 injectBridge 走 iframe.contentDocument 塞 <script>，但 file:// 下每个文件都是
  // 独立 origin，contentDocument 恒为 null（Chromium 静默返回 null 而非抛错），脚本永远进不来。
  // 评审画布的常态就是本地双击打开，所以 picker 必须自带一份；父画布那份保留作同源（http://）
  // 兜底，两边靠 window.__pickerBridge 去重，谁先到谁生效。
  function setupPicker() {
    if (window.__pickerBridge) return;
    window.__pickerBridge = true;
    var HL_ID = '__picker_hl__';
    var active = false;

    function ensureHl() {
      var hl = document.getElementById(HL_ID);
      if (!hl) {
        hl = document.createElement('div');
        hl.id = HL_ID;
        hl.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483646;border:2px solid #F93838;'
          + 'background:rgba(249,56,56,0.08);transition:all .08s;display:none;box-sizing:border-box;border-radius:2px;';
        document.documentElement.appendChild(hl);
      }
      return hl;
    }

    function cssPath(el) {
      if (!(el instanceof Element)) return '';
      var parts = [];
      while (el && el.nodeType === 1 && parts.length < 6) {
        var seg = el.nodeName.toLowerCase();
        if (el.id) { seg += '#' + el.id; parts.unshift(seg); break; }
        if (el.className && typeof el.className === 'string') {
          var cls = el.className.trim().split(/\s+/).filter(function (c) {
            return c && c.indexOf('__picker') !== 0;
          }).slice(0, 2).join('.');
          if (cls) seg += '.' + cls;
        }
        var parent = el.parentNode;
        if (parent && parent.nodeType === 1) {
          var sib = Array.prototype.slice.call(parent.children).filter(function (x) {
            return x.nodeName === el.nodeName;
          });
          if (sib.length > 1) seg += ':nth-of-type(' + (sib.indexOf(el) + 1) + ')';
        }
        parts.unshift(seg);
        el = el.parentElement;
      }
      return parts.join(' > ');
    }

    function metaFor(el) {
      var r = el.getBoundingClientRect();
      var text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80);
      var html = el.outerHTML || '';
      if (html.length > 240) html = html.slice(0, 240) + '...';
      return {
        frameKey: getFrameKey(),
        tag: el.nodeName.toLowerCase(),
        selector: cssPath(el),
        text: text,
        html: html,
        rect: { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) }
      };
    }

    function setHl(el) {
      var hl = ensureHl();
      if (!el) { hl.style.display = 'none'; return; }
      var r = el.getBoundingClientRect();
      hl.style.display = 'block';
      hl.style.left = r.left + 'px';
      hl.style.top = r.top + 'px';
      hl.style.width = r.width + 'px';
      hl.style.height = r.height + 'px';
    }

    document.addEventListener('mouseover', function (e) {
      if (!active) return;
      var el = e.target;
      if (!el || el.id === HL_ID) return;
      setHl(el);
    }, true);
    document.addEventListener('click', function (e) {
      if (!active) return;
      var el = e.target;
      if (!el || el.id === HL_ID) return;
      e.preventDefault();
      e.stopPropagation();
      try { parent.postMessage({ type: 'picker:select', payload: metaFor(el) }, '*'); } catch (err) {}
    }, true);
    document.addEventListener('mouseleave', function () { if (active) setHl(null); }, true);

    window.addEventListener('message', function (e) {
      var d = e.data || {};
      if (d.type === 'picker:setActive') {
        active = !!d.active;
        if (!active) setHl(null);
      }
    });

    try { parent.postMessage({ type: 'picker:bridgeReady', frameKey: getFrameKey() }, '*'); } catch (e) {}
  }

  // 测量期间的自屏蔽标志：中和 min-height 会瞬时改动 body 尺寸，不挡住 ResizeObserver 就会自触发下一轮
  var measuring = false;

  // 内容自然高度：必须与 iframe 当前视口高度解耦。父画布把上报值回填成 iframe 高度，
  // 而页面里任何「跟视口等高」的撑满约束（min-h-screen / min-height:100vh）都会让下一次
  // scrollHeight 再高出同一个固定偏移，构成无限放大的正反馈（实测能涨到 17000px+）。
  // 所以测量前把这类约束临时中和，只留内容真正撑出来的高度；下限由父画布按视口档位补。
  function naturalHeight() {
    var body = document.body;
    if (!body) return document.documentElement.scrollHeight;
    var vpH = window.innerHeight;
    var touched = [];
    function neutralize(el) {
      var cs;
      try { cs = getComputedStyle(el); } catch (e) { return; }
      var mh = parseFloat(cs.minHeight);
      // 只中和跟视口等高的那一类；min-height:400px 这种固定值是内容自己的诉求，不能动
      if (!mh || Math.abs(mh - vpH) > 1) return;
      touched.push([el, el.style.getPropertyValue('min-height'), el.style.getPropertyPriority('min-height')]);
      el.style.setProperty('min-height', '0', 'important');
    }
    measuring = true;
    try {
      neutralize(document.documentElement);
      neutralize(body);
      var all = body.getElementsByTagName('*');
      for (var i = 0; i < all.length; i++) neutralize(all[i]);
      return Math.max(document.documentElement.scrollHeight, body.scrollHeight);
    } finally {
      for (var k = 0; k < touched.length; k++) {
        var t = touched[k];
        if (t[1]) t[0].style.setProperty('min-height', t[1], t[2]);
        else t[0].style.removeProperty('min-height');
      }
      measuring = false;
    }
  }

  function reportHeight() {
    // 只报真实内容高度、不设下限：视口档位（APP 手机壳 812 / 中台宽屏 800）由父画布按
    // pages.json 的 viewport clamp，同一份 bootstrap 才能同时服务两种原型
    var h = naturalHeight();
    try {
      parent.postMessage({ type: 'canvas-frame-ready', frameKey: getFrameKey(), height: h }, '*');
    } catch (e) {}
  }

  function boot() {
    // 保存原 rAF 引用：必须在 disableInteractions 覆盖之前，供 ResizeObserver 节流用
    var origRAF = window.requestAnimationFrame.bind(window);
    activate(getFrameKey());
    disableInteractions();
    setupPicker();
    var report = reportHeight;
    report();
    setTimeout(report, 250);
    setTimeout(report, 1200);
    window.addEventListener('load', report);
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(report).catch(function(){});
    }
    // 持续监听 body 尺寸变化（图片/字体异步加载撑高后回报）
    if (window.ResizeObserver) {
      var pending = false;
      var ro = new ResizeObserver(function () {
        if (pending || measuring) return;
        pending = true;
        origRAF(function () { pending = false; report(); });
      });
      if (document.body) ro.observe(document.body);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  window.addEventListener('hashchange', function () {
    activate(getFrameKey());
    setTimeout(reportHeight, 100);
  });
})();
</script>"""

CURRENT_VERSION = '19'
MARKER_RE = re.compile(r'data-canvas-mode-bootstrap=["\'](\d+)["\']')
MANIFEST_RE = re.compile(
    r'<script[^>]*type=["\']application/canvas-manifest["\']',
    re.IGNORECASE,
)
BODY_CLOSE_RE = re.compile(r'</body\s*>', re.IGNORECASE)
LEGACY_STYLE_RE = re.compile(
    r'<style[^>]*data-canvas-mode-bootstrap=["\']\d+["\'][^>]*>.*?</style>\s*',
    re.IGNORECASE | re.DOTALL,
)
LEGACY_SCRIPT_RE = re.compile(
    r'<script[^>]*data-canvas-mode-bootstrap=["\']\d+["\'][^>]*>.*?</script>\s*',
    re.IGNORECASE | re.DOTALL,
)


def patch_html(path: Path) -> bool:
    """幂等向 HTML 注入 canvasMode bootstrap + patch CSS。

    注入位置优先在 `<script type="application/canvas-manifest">` 块之前；如果没有 manifest
    则在 `</body>` 之前；都没有则在文件末尾追加（兜底）。

    幂等策略：marker 带版本号。命中当前版本则跳过；命中旧版本则先剥离旧块再注入新版。

    返回：True 表示真注入了（首次注入或升级覆盖）；False 表示已是当前版本跳过。
    """
    html = path.read_text(encoding='utf-8')
    found = {m.group(1) for m in MARKER_RE.finditer(html)}
    if found and found == {CURRENT_VERSION}:
        return False

    if found:
        # 命中旧版（或新旧混杂）：先剥掉所有 bootstrap 风格/脚本块再走正常注入
        html = LEGACY_SCRIPT_RE.sub('', html)
        html = LEGACY_STYLE_RE.sub('', html)

    injection = '\n' + PATCH_CSS + '\n' + BOOTSTRAP_JS + '\n'

    m = MANIFEST_RE.search(html)
    if m:
        new_html = html[:m.start()] + injection + html[m.start():]
    else:
        bm = BODY_CLOSE_RE.search(html)
        if bm:
            new_html = html[:bm.start()] + injection + html[bm.start():]
        else:
            new_html = html + injection

    path.write_text(new_html, encoding='utf-8')
    return True


def patch_directory(target: Path, exclude_names: Tuple[str, ...] = ('demo.html', 'index.html')) -> List[Tuple[Path, bool]]:
    """对目录内所有 .html 调 patch_html，返回 [(path, patched_bool), ...]"""
    if target.is_file():
        files = [target]
    else:
        files = sorted(target.glob('*.html'))
    files = [f for f in files if f.name.lower() not in exclude_names]
    return [(f, patch_html(f)) for f in files]


def main() -> None:
    if len(sys.argv) < 2:
        print('usage: patch_prototype.py <prototype-dir-or-file>', file=sys.stderr)
        sys.exit(2)
    target = Path(sys.argv[1]).expanduser().resolve()
    if not target.exists():
        print(f'not found: {target}', file=sys.stderr)
        sys.exit(1)

    results = patch_directory(target)
    patched = [str(p) for p, ok in results if ok]
    skipped = [str(p) for p, ok in results if not ok]
    print(json.dumps({
        'patched': len(patched),
        'skipped': len(skipped),
        'patchedFiles': patched,
        'skippedFiles': skipped,
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
