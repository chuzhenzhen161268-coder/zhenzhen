#!/usr/bin/env python3
"""refresh_vendor_seed.py — 把画布依赖的前端库下载到 skill 的 references/vendor/ 作为种子。

build_canvas.py 跑画布时只做本地 copy（references/vendor/ → <output>/assets/vendor/），
不走任何网络。本脚本是种子来源，仅在升级依赖版本时手动执行：

  python3 refresh_vendor_seed.py            # 已存在直接跳过
  python3 refresh_vendor_seed.py --force    # 删旧种子重新下

执行后老大需要 git add references/vendor/ 提交，种子才会随 skill 仓库分发。

体积控制：FontAwesome 的 webfonts/ 只保留 .woff2（砍 ttf/woff/eot/otf/svg），
现代浏览器全覆盖，体积从 ~7 MB 压到 ~1 MB；mermaid.min.js ~3 MB 全留。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
SEED_ROOT = SKILL_ROOT / "references" / "vendor"
REGISTRY = "https://registry.npmjs.org"

# 与 vendor_assets.VENDOR_DIRS 对齐；新增/删除一个库时两处同步
VENDORS = [
    {
        "dir": "fontawesome",
        "pkg": "@fortawesome/fontawesome-free",
        "version": "6.7.2",
        # all.min.css 的 @font-face 指向 ../webfonts/，css + webfonts 一起取
        "include": ["package/css/all.min.css", "package/webfonts/"],
        # webfonts/ 下只保留这些后缀，其余字体格式剔除以省体积
        "font_ext_keep": {".woff2"},
    },
    {
        "dir": "mermaid",
        "pkg": "mermaid",
        "version": "latest",  # 11.x 最新
        "include": ["package/dist/mermaid.min.js"],
        "font_ext_keep": None,
    },
]

STRIP = "package/"
FONT_EXT_ALL = {".ttf", ".woff", ".woff2", ".eot", ".otf", ".svg"}


def _resolve_tarball(pkg: str, version: str):
    url = f"{REGISTRY}/{pkg.replace('/', '%2F')}"
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.npm.install-v1+json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        meta = json.load(r)
    if version != "latest" and version in meta.get("versions", {}):
        v = version
    else:
        v = meta["dist-tags"]["latest"]
    return meta["versions"][v]["dist"]["tarball"], v


def _extract(tarball_url: str, includes, dest: Path, font_keep):
    fd, tmp = tempfile.mkstemp(suffix=".tgz")
    os.close(fd)
    n = 0
    try:
        with urllib.request.urlopen(tarball_url, timeout=180) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
        with tarfile.open(tmp) as tar:
            for m in tar.getmembers():
                if not m.isfile():
                    continue
                name = m.name
                if name.endswith(".map"):
                    continue
                hit = False
                for inc in includes:
                    if (inc.endswith("/") and name.startswith(inc)) or name == inc:
                        hit = True
                        break
                if not hit:
                    continue
                # 字体白名单：只对 webfonts/ 下的已知字体后缀生效，避免误删 css
                if font_keep and "/webfonts/" in name:
                    ext = os.path.splitext(name)[1].lower()
                    if ext in FONT_EXT_ALL and ext not in font_keep:
                        continue
                rel = name[len(STRIP):] if name.startswith(STRIP) else name
                out = dest / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                src = tar.extractfile(m)
                if src is None:
                    continue
                with src, open(out, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                n += 1
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    return n


def main():
    force = "--force" in sys.argv[1:]
    SEED_ROOT.mkdir(parents=True, exist_ok=True)
    results = []
    for v in VENDORS:
        dest = SEED_ROOT / v["dir"]
        if dest.exists():
            if not force:
                ver_file = dest / ".seed-version"
                ver = ver_file.read_text(encoding="utf-8").strip() if ver_file.exists() else "?"
                results.append({"dir": v["dir"], "version": ver, "status": "exists", "hint": "用 --force 重新下载"})
                continue
            shutil.rmtree(dest)
        try:
            tarball, ver = _resolve_tarball(v["pkg"], v["version"])
            n = _extract(tarball, v["include"], dest, v.get("font_ext_keep"))
            if n == 0:
                raise RuntimeError("tarball 命中 0 个文件（include 规则可能失配）")
            (dest / ".seed-version").write_text(ver, encoding="utf-8")
            results.append({"dir": v["dir"], "version": ver, "files": n, "status": "downloaded"})
        except Exception as e:
            results.append({"dir": v["dir"], "version": v["version"], "status": "failed", "reason": str(e)})
    print(json.dumps({"seedRoot": str(SEED_ROOT), "results": results}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
