#!/usr/bin/env python3
"""vendor_assets.py — 把 skill 内置种子 references/vendor/ 复制到 <output_dir>/assets/vendor/。

种子由 scripts/refresh_vendor_seed.py 在升级依赖时离线维护（npm 下载）；build_canvas.py 跑画布
时本模块只做本地 copy，不走任何网络。

幂等：目标目录写 .vendor-ok 标记（含种子版本号）；与种子版本一致则跳过，种子升级了重新 copy。

CLI（独立验证用）：
  python3 vendor_assets.py <output_dir>          # 按种子刷到 <output_dir>/assets/vendor/
  python3 vendor_assets.py <output_dir> --force  # 忽略 .vendor-ok 强制重 copy
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
SEED_ROOT = SKILL_ROOT / "references" / "vendor"

# 与 refresh_vendor_seed.VENDORS 对齐；新增/删除一个库时两处同步
VENDOR_DIRS = ["fontawesome", "mermaid"]


def _read_seed_version(seed_dir: Path) -> str:
    f = seed_dir / ".seed-version"
    if not f.exists():
        return "?"
    try:
        return f.read_text(encoding="utf-8").strip() or "?"
    except Exception:
        return "?"


def ensure_vendor(output_dir, warnings: list, force: bool = False):
    """把 SEED_ROOT 下每个库 copy 到 output_dir/assets/vendor/<dir>。失败 append warning，不抛。

    返回 [{dir, version, status}]。status: copied / skipped / missing-seed / failed
    """
    if not SEED_ROOT.exists():
        warnings.append(
            f"vendor 种子目录缺失：{SEED_ROOT}；请在 skill 仓库下跑 "
            "`python3 scripts/refresh_vendor_seed.py` 重新下载并提交"
        )
        return [{"dir": d, "version": "?", "status": "missing-seed"} for d in VENDOR_DIRS]

    vendor_root = Path(output_dir) / "assets" / "vendor"
    results = []
    for d in VENDOR_DIRS:
        src = SEED_ROOT / d
        dest = vendor_root / d
        ok_mark = dest / ".vendor-ok"
        seed_ver = _read_seed_version(src)

        if not src.exists():
            warnings.append(
                f"vendor 种子子目录缺失：{src}；请跑 `python3 scripts/refresh_vendor_seed.py --force`"
            )
            results.append({"dir": d, "version": "?", "status": "missing-seed"})
            continue

        if not force and ok_mark.exists():
            try:
                cur = ok_mark.read_text(encoding="utf-8").strip()
            except Exception:
                cur = "?"
            if cur == seed_ver and cur != "?":
                results.append({"dir": d, "version": cur, "status": "skipped"})
                continue
            # 种子版本号变化（升级或种子重新生成），重新 copy
        try:
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(src, dest)
            ok_mark.write_text(seed_ver, encoding="utf-8")
            results.append({"dir": d, "version": seed_ver, "status": "copied"})
        except Exception as e:
            warnings.append(
                f"vendor 资源 {d} 复制失败：{e}；画布的"
                f"{'图标' if d == 'fontawesome' else '流程图'}功能将不可用"
            )
            results.append({"dir": d, "version": seed_ver, "status": "failed"})
    return results


def main():
    if len(sys.argv) < 2:
        print("usage: vendor_assets.py <output_dir> [--force]", file=sys.stderr)
        sys.exit(2)
    output_dir = Path(sys.argv[1]).expanduser().resolve()
    force = "--force" in sys.argv[2:]
    warnings = []
    results = ensure_vendor(output_dir, warnings, force=force)
    print(json.dumps({
        "seedRoot": str(SEED_ROOT),
        "vendorRoot": str(output_dir / "assets" / "vendor"),
        "results": results,
        "warnings": warnings,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
