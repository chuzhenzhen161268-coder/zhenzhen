---
name: lon-proto-canvas
description: 用户说「全 PRD 画布 / 原型评审画布 / 加一页到画布 / 更新某页画布」，或要把整套原型平铺成一张图做评审时触发；`/lon-proto-canvas` 命令应触发。
---

# Lon PRD Canvas

多页原型的可标注评审画布生成器。读入原型路径，调度 `scripts/build_canvas.py` 扫描 / 合并 / 渲染，输出静态包到 `./prototypes/`。

## Overview

业务/产品评审原型时（APP 手机壳与中台宽屏都支持，按页自动识别视口），需要一张可自由摆放的画布：通过底部「+」添加面板把任意页面的状态 / 浮层放上画布成为一个实例（同一 frame 可添加多个实例，各自独立拖拽定位、独立打标注），编排坐标持久化到 `layout.json` 可团队共享；画布上任意位置打标注 + 写富文本备注；画布上可用图形 / 箭头 / 便签 / 文字画流程与批注：`R` 出基础几何面板、`F` 出流程符号面板，两个面板共 24 种轮廓，选中图形后浮条上的切换器可原尺寸换成任意一种；选中的节点四边浮出连接点，点一下就在那个方向落一个同型节点并自动连线，拖出去则直接拉一条线；箭头支持直角折线路由、可拖折点，双击线可在中段写「是 / 否」这类分支标签，端点吸附卡片与图形边并跟随其移动；拖拽卡片与图形时有对齐参考线辅助，空白处拖框或按住 `Shift` 点选可多选、整组拖动与删除，图形与 frame 实例一起存进 `layout.json`；截图可直接 `Cmd/Ctrl+V` 粘贴或拖进画布，图片落盘到站点目录随编排一起分享；右侧吸边「需求文档」分屏可切换查阅 `dev-prd/` 下的研发交付 PRD；左上角「相关文档」区列出 `refs/` 里放的独立 HTML（竞品调研、埋点方案这类评审时要对照的材料），点开走新标签页。

输出静态包平铺到 `./prototypes/`（原型站点根），起一次静态服务就能同时访问原型、demo、画布：

```
./prototypes/
  index.html          # 本技能产出：画布壳（零占位符）
  assets/canvas.css   # 本技能产出：画布样式
  assets/canvas.js    # 本技能产出：画布逻辑
  pages.json / .js    # 本技能产出：页面 + 状态 + 浮层数据（.js 是 file:// 用的镜像）
  annotations.json / .js   # 本技能产出：标注
  layout.json / .js   # 本技能产出：画布编排（frame 实例坐标 + 图形）
  dev-prd-index.json / .js # 本技能产出：PRD 文档清单（.js 是 file:// 用的镜像）
  refs-index.json / .js    # 本技能产出：相关文档清单（.js 是 file:// 用的镜像）
  canvas_server.py    # 本技能产出：本地写服务（发布时剔除）
  refs/               # 本技能建目录，文档由用户手动放入
  dev-prd/            # 其他技能产出的 PRD；本技能在其中写 <文件名>.md.js 正文镜像
  pages/ demo/ assets/   # 其他技能产出
```

## When to Use

**Use when:**
- 需要在一张画布上查看整套原型的所有页面、状态、浮层
- 产品/业务评审需要在原型上打标注反馈
- 要在原型和需求文档之间快速切换对照
- 需要追踪评审标注的孤儿状态（页面删除后的历史标注）

**Do NOT use when:**
- 只需要查看单个原型页面（直接打开 `pages/*.html`）
- 需要交互演示（用 `demo/demo.html`）
- 还没有任何原型文件（先生成原型）

## Quick Reference

| 场景 | 命令 | 脚本自动识别模式 |
|------|------|-----------------|
| 首次生成整套画布 | `/lon-proto-canvas ./prototypes/pages/` | new-folder |
| 首次生成单页画布 | `/lon-proto-canvas ./prototypes/pages/01-登录.html` | new-single |
| 更新某页内容 | 修改 HTML 后重跑 | update-page |
| 追加新页 | 添加新 HTML 后重跑 | add-page / merge |
| 合并多次修改 | 批量改动后重跑 | merge |

**模式判定**：脚本读 `output_dir/pages.json` 自动识别，无需手工指定。仅在脚本误判或用户显式要求时才加 `--force-mode <模式>`。

## Workflow

### Phase 0：校验入参

1. `Codex terminal ls` 确认输入路径存在
2. 解析输出目录：用户给定 或 CWD 下的 `./prototypes/`
3. 转换为绝对路径（脚本要求）
4. 若项目根存在 `product-manifest.json`，核对页面名称、顺序与 `pages` 清单；正式版本和产品名称不得从旧画布数据反向覆盖

### Phase 1：调用 build_canvas.py

```bash
python3 <skill-dir>/scripts/build_canvas.py \
  --input  <绝对路径> \
  --output <绝对路径>
```

脚本一次性完成：
- 幂等补丁每个源 HTML（注入 canvasMode bootstrap）
- 读 `<script type="application/canvas-manifest">` 块的元数据（详见 `references/input-manifest-spec.md`）
- 合并 pages.json（5 种模式自动判断）
- 处理孤儿标注（消失的 frameKey / 整页移除 → 迁到 `orphans[]`）
- 拷贝画布壳与 `assets/canvas.css` / `canvas.js`，三段数据各写 json + js 镜像，拷入 `canvas_server.py`
- 解析每页视口档位（manifest `page.viewport` > `<meta name="viewport">` 嗅探 > mobile 默认）写进 pages.json
- 按输出目录实际产物解析「演示」入口（有 `demo/demo.html` 则指向它，否则不渲染）
- 从 skill 内置种子 `references/vendor/` 复制前端库到 `assets/vendor/`（本地 copy 不走网络，幂等）
- 扫 `output/dev-prd/*.md` 写 `output/dev-prd-index.json`（+ js 镜像）与每篇正文的 `.md.js` 镜像
- 建出 `output/refs/` 并扫成 `output/refs-index.json`（+ js 镜像）
- 备份已存在的输出文件（`.bak.{时间戳}`）

### Phase 2：读 stdout JSON + 复述

脚本 stdout 输出结构化 JSON（schema 详见 `references/output-contract.md`）。

**强制自检**：
- `warnings` 非空 → 列入复述「提醒」块
- `totalPages` 必须等于项目清单或实际原型页面数，`layoutFrames` 不得因重建意外归零
- 逐页检查 `sourceFile` 存在、iframe 引用存在、视口宽高大于 0；中台页至少检查设计基准宽度
- 对每个首要 frame 执行可见性冒烟检查：页面内容高度、可见文本或截图不得为空；仅验证 JSON 数量不能判定画布成功
- `annotations` 的有效绑定数、`orphans` 数量和构建前后一致性必须复述；新增逻辑注释后确保对应 `instanceId` 存在

按 `references/output-contract.md` 定义的格式向用户复述结果。

## Common Mistakes

| 错误 | 症状 | 修复 |
|------|------|------|
| 源 HTML 缺 manifest | warning: 页面跳过 | 补 manifest（见 `references/input-manifest-spec.md`） |
| 浮层显示在错误状态下 | iframe 底层不对 | 在 manifest 的浮层 frame 补 `triggers[0].fromStateKey` |
| 新 PRD 不出现在分屏 | 文档选择器没有新文件 | 点「刷新」按钮或重跑本技能 |
| 新文档不出现在「相关文档」 | 左上角列表没有刚放进去的文件 | 点该区的「刷新」；`file://` 或静态包下必须重跑本技能刷新 `refs-index.json` |
| 画布样式错乱 | bootstrap 版本过旧 | 运行 `patch_prototype.py` 升级 |
| 卡片存在但页面内容空白 | iframe 使用百分比高度且画布模式把页面高度改为 auto，或 iframe 引用文件名错误 | 使用明确的视口高度或原生完整页 frame；校验 iframe 实际矩形与目标文件存在 |
| 中台页在画布上被压成手机布局 | 该页 `viewport` 没解析出宽屏 | 确认源 HTML 有 `<meta name="viewport" content="width=1280">`，或在 manifest 补 `page.viewport: "desktop"` 后重跑 |
| 「演示」点开 404 | 站点缺 `demo/demo.html` | 让 lon-proto-builder 补生成演示壳；没有演示壳时该按钮本就不该渲染 |
| 服务不允许静态 GET json | 画布显示「画布无法加载」或标注为空 | 读路径是静态 GET `pages.json` / `annotations.json` / `layout.json`；换服务时先 `curl` 验证三个文件返回 200 |
| 打开旧站点弹出「检测到旧版画布的标注 / 编排数据」 | 早先在 `file://` 或纯静态服务下评审过，数据只存在本机浏览器 | 确认下载得到 `legacy-canvas-state-*.json`，回到写服务模式的画布用「导入」合并 |
| 打开画布顶部出现「静态副本」横幅 | 站点没带写服务 | 本地评审用 `lan-launcher --canvas-api` 起站点目录（build 已放好 `canvas_server.py`）；托管副本本来就是只读，改动请导出后在本地导入 |
| iframe 在画布上还能点、能 hover 变手型 | 该帧 bootstrap 版本过旧，或 picker 异常退出残留了 inline `pointer-events:auto` | 重跑本技能升级 bootstrap；再点一次「选元素」正常关闭它 |
| 「选元素」点不中任何东西 | 桥接没就位——旧版 bootstrap 依赖父画布跨 origin 注入，`file://` 下必然失败 | 重跑本技能把 bootstrap 升到内置 picker 的版本 |
| 目录里的入口页/跳转页被撑成 10KB | 扫描器先补丁后验 manifest（已修） | 用当前版本 `build_canvas.py` 重跑；非原型文件应进 `FOLDER_SCAN_EXCLUDE` |
| 交付中心把画布当作可点击演示 | 画布 iframe 默认冻结，用户无法体验原型交互 | 可点击演示链接到 `demo/demo.html`；画布只用于状态总览、评审与标注 |

## 画布核心能力

### 视口档位（APP / 中台自动识别）

iframe 的宽度**就是**原型内部的 CSS 视口宽度——`<meta name="viewport">` 在 iframe 里不生效。所以画布按页记录视口，1280 的中台页不会被塞进 375 的手机壳按手机断点重排。

- **来源三级回退**：manifest `page.viewport` > 源 HTML `<meta name="viewport" content="width=1280">` 嗅探 > `mobile` 默认。内置档位 `mobile` 375×812 / `desktop` 1280×800
- **通常零配置**：lon-proto-builder 中台模式骨架自带 `width=1280`，嗅探即可命中，存量原型重跑一次就修好
- **height 是下限不是定高**：state frame 按 iframe 回报的真实内容高撑开，overlay frame 固定按档位高展示
- **首屏自动 fit**：按画布上最宽的那个实例缩放到看得全整页。APP（375）算下来恒为 1；中台在小屏上自动缩
- 详见 `references/scan-rules.md` §1.1

### 演示入口（总览 / 演示切换条）

左上角切换条的「演示」按目录里实际存在的产物解析，不写死：

| 输出目录里存在 | 演示指向 |
|---------------|---------|
| `demo/demo.html` | 演示壳（APP 手机框 / 中台页面索引，两模式同路径） |
| 没有 | 整条 nav 不渲染，不留死链 |

统一 `target="_blank"`：画布的缩放 / 滚动位置 / 未提交的标注草稿只活在当前标签页。

### 需求文档分屏（右侧吸边）

右侧吸边「需求文档」按钮 → 展开 markdown 预览分屏：
- **数据源**：`./prototypes/dev-prd-index.json`（按语义化版本号降序）
- **内容源**：`./prototypes/dev-prd/*.md`
- **file:// 取数**：清单与正文各有 `.js` 镜像，双击 HTML 打开时 fetch 不可用，分屏改读镜像；
  正文一篇一个镜像、切换文档时才按需加载
- **默认展示最新版本**：清单 `latest` 字段，localStorage 记住上次选择
- **格式兼容**：mermaid 代码块 + 图片相对路径 + 表格/列表
- **分屏宽度**：默认 `40vw`，可拖拽 resizer（`320px – 65vw`），持久化到 localStorage
- **清单更新**：研发交付 PRD 落盘后会单独刷新，build_canvas.py 全量重建时也会刷新

### 相关文档（左上角）

评审时要对照的独立 HTML 材料放进 `./prototypes/refs/`，画布左上角「总览 / 演示」下方就会列出来：

- **收哪些**：`refs/` 下的 `.html` / `.htm`，不递归子目录；其他格式忽略
- **展示名**：读文档的 `<title>`，没有则用文件名。想固定顺序就给文件名加 `01-` 这类前缀（按文件名升序）
- **打开方式**：`target="_blank"` 新标签页，与「演示」同一策略——画布的缩放 / 滚动位置 / 未提交的标注草稿只活在当前标签页
- **清单来源**：起了本地写服务时走实时扫描，文档扔进 `refs/` 刷新页面即可见；`file://` 与导出的静态包读构建期落盘的 `refs-index.json`（所以静态包发出去前要重跑一次本技能，否则新文档不在清单里，`export_site.py` 会就此报 warning）
- **一篇都没有时整块不渲染**，左上角只剩切换条；折叠状态记在本机

### 指针权（卡片是静态快照）

画布上的 iframe 是**静态快照，不是可操作页面**：`.frame iframe { pointer-events: none }` 让鼠标事件根本不进 iframe，hover 高亮、`cursor:pointer`、输入框聚焦全部失效，指针落在画布容器上供拖拽卡片；iframe 内 bootstrap 的 capture 拦截负责键盘、以及 picker 放行期间的 `<a>` 跳转 / form 提交。

只靠 bootstrap 拦截不够——事件被吞了但视觉照样响应，中台原型单页上百个 `cursor:pointer` 元素看着完全可点、点下去毫无反馈，必须在父层就断掉。

指针权是个三态开关，默认态之外还有两个临时态把它还给 iframe：「选元素」开启期间（供 picker 拾取 DOM）、按住 `Option/Alt` 期间（供选中复制原型内的文字）。所以取原型文案有两条路：按住 Option 直接拖选，或用「选元素」（它带复制）。

### 选元素（picker）提取反馈

「选元素」按钮 → 跨 iframe 拾取模式：在任意状态/浮层 iframe 里点选 DOM 元素累积成一组，每条配修改指令，统一复制成带 selector 的 prompt，回灌给下游原型改稿。开启时 inline 设 `pointer-events:auto` 覆盖平铺冻结，关闭时清回。

桥接脚本内置在原型自带的 bootstrap 里，**不能靠父画布注入**：`file://` 下每个文件是独立 origin，`iframe.contentDocument` 恒为 `null`（Chromium 静默失败），而评审画布的常态就是本地双击打开。父画布的 `injectBridge` 只是 `http://` 同源兜底。

与「注释」并行但目的不同：
- 注释 = 人看的评审批注（画布坐标打图钉 + 富文本备注）
- 选元素 = AI 看的改稿反馈（元素 selector + 指令）

### 添加面板（把 frame 放上画布）

底部工具条「+」按钮 → 展开右侧面板，按页面 + frame（状态 / 浮层）两级列出整套原型：

- 每个 frame 一个 `+`，点一次往画布加一个实例；同一个 frame 可以添加多次，各实例独立拖动、独立打标注
- 已添加的实例列在对应 frame 下方，带定位按钮（画布平移过去并高亮）与移除按钮
- 点画布上的卡片即选中（描边高亮），选中后按 `Delete` 把它移出画布，等同面板里的移除按钮
- 实例上有标注时，行内显示标注条数；移除前弹确认框告知条数，确认后标注迁入孤儿区，可在孤儿抽屉重新挂载
- 画布上一个实例都没有的 frame 打 NEW 徽标
- 编排持久化到 `prototypes/layout.json`（走本地写服务）；无写 API 时进静态模式，改动只在内存
- **API 契约**：写入 `PUT /api/canvas/layout`，payload `{version, frames, shapes}`（`updatedAt` 由服务端盖），字段规则见 `references/output-contract.md`

### 选中与多选

卡片与图形同住一个选中集合，拖动与 `Delete` 作用的都是这个集合：

- **框选**：`select` 工具下从空白处拖出一个框，与框相交的卡片 / 图形 / 连线全部选中，不要求把对象整个框住；起手落在对象上则是拖那个对象
- **Shift 点击**：点中的对象加进集合，再点一次摘出去；`Shift` + 框选是在现有选中之上追加
- **整组拖动**：拖组内任意一个成员，整组同位移、组内相对位置不变；对齐参考线只跟组外的对象比
- **整组删除**：`Delete` / `Backspace` 删掉整个集合；卡片上的标注合并成一次确认、一步撤销
- **方向键微移**：`1px`，按住 `Shift` 走 `10px`；连按一串合并成一步撤销
- `Cmd/Ctrl+A` 全选画布上的卡片与图形，`Esc` 取消选中
- `Cmd/Ctrl+C` / `Cmd/Ctrl+V` 复制粘贴选中的卡片与图形：副本落在鼠标处、组内相对位置不变，整次粘贴一步撤销；连线两端都在选中范围内时跟着改挂副本，只选中一端时那端就地断开成自由端。同时写系统剪贴板，可粘到另一个画布标签页去（对方站点没有的页面对应的卡片会被跳过并提示）
- 多选时成员各自描边，外面再套一个虚线整组框；八向缩放手柄、四边连接点、形状浮条只服务单选，多选期间自动收起

### 评审标注（图钉 + 富文本批注）

画布坐标或 frame 上打图钉，配富文本备注，供评审传阅：
- 标注持久化到 `prototypes/annotations.json`（走本地写服务），可 git 提交与团队共享
- 读路径：启动时静态 GET `annotations.json`（`file://` 下改读 `annotations.js` 镜像）；改 `annotations.json` 后刷新即生效
- **API 契约**：写入 `PUT /api/canvas/annotations`，payload `{version, annotations, orphans}`；服务端盖 `updatedAt` 并同步写 `.js` 镜像
- 工具栏常驻保存状态：已保存 / 保存中 / 保存失败重试中 / 静态副本；有未落盘改动时关闭页面会被拦一次

### 贴图

`Cmd/Ctrl+V` 粘贴截图、或把图片文件拖进画布，落成一个可拖拽可缩放的图形（缩放锁原始比例，可当箭头端点的宿主）。同一个 `Cmd/Ctrl+V` 也接画布对象：剪贴板里是图片就贴图，是复制走的卡片 / 图形就贴对象。落盘前长边超 1600px 的会等比缩小并转 webp；尺寸与体积都在预算内的小图保留原始编码，不做有损重压。

图片二进制走 `POST /api/canvas/image` 落到 `assets/canvas-images/`，按内容 sha256 命名，`layout.json` 里只存相对路径——图片因此随站点目录一起分享与提交，别人打开就能看到。build 时会按 layout 的引用对账，清掉没人引用的文件。

贴图依赖写服务：站点没带 `--canvas-api` 起、或站点里的 `canvas_server.py` 是不含该端点的旧版时，画布会拦下粘贴并提示。

### 锁定与撤销

右上「锁定标注」冻结一切内容变更：frame 与图形的拖拽 / 方向键微移、图形绘制 / 缩放 / 文本编辑、标注新建 / 编辑 / 删除 / 图钉拖拽、添加面板的增删实例、孤儿抽屉的删除与重挂、导入。查看标注卡、定位实例、缩放平移、切主题、导出照常。点锁定时正在编辑的文本先提交再锁，不丢字。

撤销 / 重做覆盖 frame 编排、图形、标注、孤儿四类内容，视图偏好（缩放 / 主题 / 锁定 / 分屏宽度）不算内容：
- `Cmd/Ctrl+Z` 撤销、`Cmd/Ctrl+Shift+Z` 或 `Ctrl+Y` 重做；dock 有对应按钮，栈空即灰
- 一次用户操作对应一步：移除带标注的 frame、整组删除、导入这类连写多次的操作合并成一步；连按方向键的一串微移、新建标注从落钉到写完正文，同样各算一步
- 焦点在标注编辑卡 / 图形文本里时是浏览器原生的文字撤销；焦点在原型 iframe 内时快捷键到不了画布
- 锁定态不可撤销；撤销后的结果照常落盘

### 站点默认视图

`pages.json` 的 `viewDefaults` 声明这份包默认长什么样，随包分发给每个查看者：

| 字段 | 写入方式 | 取值顺序 |
|------|---------|---------|
| `theme` | `--theme light\|dark` | 查看者本机偏好 > `viewDefaults.theme` > `light` |
| `locked` | `--locked` / `--no-locked`，或画布右上的锁定开关 | `viewDefaults.locked` > 未锁定 |

主题是个人偏好，查看者自己切过色就以他的为准；锁定是这份副本的属性，不记本机偏好，刷新回到站点默认。构建时两个参数都不传则沿用上一次构建的值。

画布右上的锁定开关在服务模式下直接写进 `viewDefaults.locked`：本地锁上，整个站点目录上传到任意静态托管，别人打开就是锁着的。构建参数与这个开关写的是同一个字段，发只读评审副本用哪条路都行。

落盘依赖写服务，与贴图同一条判定：静态模式、或站点里的 `canvas_server.py` 是不含该端点的旧版时，切锁定只在本次浏览有效并给出提示。锁定不进「导出」的 `canvas-state.json`——它是站点属性不是画布内容，所以云端查看者随手解锁改不到发出去的那份，刷新即回锁定。

### 静态模式、导出 / 导入与发布

画布启动时探测本地写 API：探到即服务模式，探不到（任意静态托管、`file://`、纯静态服务）即静态模式——顶部横幅提示「静态副本」，改动只在内存，不落任何本机存储。

顶部「导出」产出 `canvas-state.json`，含标注 / 孤儿 / frame 实例 / 图形四部分，是画布内容的整份快照。「导入」把画布整体换成那一份，不做按 id 合并——合并的结果是两份状态的并集，演示时删掉 / 挪走的东西还留在原地。

点「导入」或把 `.json` 拖进画布都会打开导入弹窗：拖入或选择文件后先出报告——四类内容的「当前 → 导入后」条数、导出时间、在本站点找不到对应页面的卡片清单（它们的注释点会进孤儿抽屉）、找不到宿主的箭头条数，核对无误再确认落盘。误导入按 `Cmd/Ctrl+Z` 整体撤回。

评审者在托管副本上的反馈就是这样回流：导出文件发给维护者，维护者在本地画布导入。静态副本上也能导入，但结果只在内存、刷新即丢，弹窗里会提示。

发布前先导出干净静态包：

```bash
python3 <skill-dir>/scripts/export_site.py --site ./prototypes --out ./dist/prototypes --clean
```

它剔除写服务、启动器、备份与缓存，校验相对引用存在且大小写一致，并打印文件数与体积统计；有缺失引用或数据文件解析失败时退出码非 0，报告里 `missingRefs` / `errors` 说明是哪一类。把 `./dist/prototypes/` 交给任意静态托管即可。

若用户需要把 PRD、原型与画布作为可移动的业务/研发交付包交接，使用 `lon-product-delivery`；该 skill 负责交付中心、预渲染文档与跨目录链接校验，本 skill 只负责画布本身。

## 存量原型补丁

build_canvas.py 扫描时已对每个源 HTML 幂等补丁，无需手动跑。仅在不走画布生成、只想单独升级存量原型的 bootstrap 时：

```bash
python3 <skill-dir>/scripts/patch_prototype.py ./prototypes/pages/
```

stdout JSON 含 `patched` / `skipped` 计数；同版本跳过，旧版本剥旧注新。`demo.html` / `index.html` 自动排除。

## Resources

| 文件 | 说明 |
|------|------|
| `scripts/build_canvas.py` | 核心实现：扫描、合并、渲染、备份 |
| `scripts/layout.py` | layout.json 的生成、合并与标注宿主绑定 |
| `scripts/canvas_server.py` | 本地写服务，build 时拷入站点目录 |
| `scripts/export_site.py` | 导出干净静态包 |
| `scripts/vendor_assets.py` | 把 `references/vendor/` 种子复制到 `assets/vendor/`（本地 copy，零网络） |
| `scripts/refresh_vendor_seed.py` | 升级 vendor 依赖时手动跑：从 npm 重下种子到 `references/vendor/` |
| `references/vendor/` | 内置前端库种子（FontAwesome 6.7.2 仅 woff2、mermaid 11.x），随 skill 仓库分发 |
| `scripts/update_dev_prd_index.py` | 刷新 dev-prd-index.json（+ js 镜像）与各篇 PRD 正文镜像，并扫掉无对应 md 的孤儿镜像 |
| `scripts/update_refs_index.py` | 建 `refs/` 并刷新 refs-index.json（扫描实现共用 `canvas_server.scan_refs`） |
| `scripts/test_canvas_persistence.mjs` | `findFrameMetaIn` / `deadInstanceIds` / `danglingArrowEnds` / `rescueLegacyLocalStorage` / `historyPush` / `historyShift` 行为测试：`node scripts/test_canvas_persistence.mjs`。改了导入对账、旧数据救援或撤销栈逻辑后必跑 |
| `references/output-contract.md` | stdout JSON schema + 复述格式规范 |
| `references/input-manifest-spec.md` | 源 HTML manifest 块结构 |
| `references/scan-rules.md` | 扫描规则细则 + 手工补 manifest 指南 |
| `references/annotation-spec.md` | 标注交互 + 持久化实现规范 |
| `references/canvas-scaffold-guide.md` | 产物装配指南：壳 / 画布资产 / 数据文件与镜像 / 写服务拷贝 / 备份 |
| `references/canvas-template.html` | 画布壳（HTML 结构） |
| `references/canvas.css` | 画布样式，build 拷进 `assets/` |
| `references/canvas.js` | 画布逻辑，build 拷进 `assets/` |
