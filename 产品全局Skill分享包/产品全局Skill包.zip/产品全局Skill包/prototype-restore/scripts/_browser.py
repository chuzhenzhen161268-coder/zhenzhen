#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""无头浏览器发现与调用（prototype-restore 内部共享模块）

为什么单独抽出来：三个校验脚本（smoke / check_deeplink / audit_computed_values）
原先各自实现了一份浏览器发现与调用，行为已经漂移过一次 —— 其中一份只找完整版浏览器，
而完整版浏览器在全新用户目录下首次启动可能超过 2 分钟（首启初始化），
直接把渲染级检查拖成超时。这里统一成一份，三条约定：

  1. **优先轻量无头内核**：playwright 缓存里的 chromium_headless_shell 启动快、不依赖首启流程；
     找不到再退回系统安装的 Chrome / Chromium / Edge。
  2. **用户目录按轮隔离**：同一轮检查复用一份临时用户目录，避免多次调用复用到尚未退出的
     上一次实例 —— 那会导致拿回上一条地址的渲染结果（症状是「两次快照完全相同」，
     正常的直达会被误报成未接线）。
  3. **调用参数集中**：headless / 禁 GPU / 禁沙箱 / 禁首启等基础开关只在这里维护。

对外接口：
    find(explicit=None)               -> 浏览器可执行文件路径（找不到返回 None）
    run(url, **kw)                    -> CompletedProcess（stdout 已捕获）
    dump(url, **kw)                   -> 渲染后的 DOM 文本
    shoot(url, out, window=..., **kw) -> 截图到 out
"""
from __future__ import annotations

import os
import subprocess
import tempfile

CACHE_ROOTS = ["~/Library/Caches/ms-playwright", "~/.cache/ms-playwright"]
SHELL_NAMES = ("chrome-headless-shell", "headless_shell")
CHROMIUM_NAMES = ("Chromium", "chrome", "Google Chrome")
APP_BUNDLES = ["Google Chrome.app", "Chromium.app", "Microsoft Edge.app", "Brave Browser.app"]
LINUX_BINS = [
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/microsoft-edge",
]
BASE_FLAGS = [
    "--headless",
    "--disable-gpu",
    "--no-sandbox",
    "--no-first-run",
    "--disable-extensions",
    "--disable-sync",
]

_EXE = None
_PROFILE = None


def _walk_for(root, names):
    for dirpath, _dirs, files in os.walk(root):
        for f in sorted(files):
            if f in names:
                p = os.path.join(dirpath, f)
                if os.access(p, os.X_OK):
                    return p
    return None


def _from_cache(prefer_prefix, names):
    for base in CACHE_ROOTS:
        root = os.path.expanduser(base)
        if not os.path.isdir(root):
            continue
        for name in sorted(os.listdir(root), reverse=True):
            if not name.startswith(prefer_prefix):
                continue
            p = _walk_for(os.path.join(root, name), names)
            if p:
                return p
    return None


def find(explicit=None):
    """返回可用的浏览器可执行文件；优先级：轻量无头内核 > 缓存里的完整内核 > 系统安装。"""
    global _EXE
    if explicit:
        return explicit
    if _EXE:
        return _EXE
    for prefix, names in (("chromium_headless_shell", SHELL_NAMES), ("chromium", CHROMIUM_NAMES)):
        p = _from_cache(prefix, names)
        if p:
            _EXE = p
            return p
    for app in APP_BUNDLES:
        p = os.path.join("/Applications", app, "Contents/MacOS", app[:-4])
        if os.access(p, os.X_OK):
            _EXE = p
            return p
    for p in LINUX_BINS:
        if os.path.exists(p):
            _EXE = p
            return p
    return None


def run_profile():
    """本轮检查共用的用户目录（惰性创建，进程内复用）。"""
    global _PROFILE
    if _PROFILE is None:
        _PROFILE = tempfile.mkdtemp(prefix="proto-browser-")
    return _PROFILE


def run(url, chrome=None, budget=2500, profile=None, hide_scrollbars=False,
        window=None, screenshot=None, timeout=300):
    """打开 url 取回结果。

    screenshot 给定时为截图模式，否则 dump-dom。返回 CompletedProcess，
    stdout 已捕获为文本（stderr 丢弃，避免日志噪音）。
    """
    exe = chrome or find()
    if not exe:
        raise RuntimeError("未找到可用的浏览器内核（可用 --chrome 指定）")
    cmd = [exe] + BASE_FLAGS
    if hide_scrollbars:
        cmd.append("--hide-scrollbars")
    cmd.append("--user-data-dir=" + (profile or run_profile()))
    if window:
        cmd.append("--window-size=" + window)
    cmd.append("--virtual-time-budget=%d" % budget)
    if screenshot:
        cmd.append("--screenshot=" + screenshot)
    else:
        cmd.append("--dump-dom")
    cmd.append(url)
    # 注意：capture_output 与 stdout/stderr 不能同时给，这里用 PIPE + 丢弃 stderr
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, timeout=timeout)


def dump(url, **kw):
    """取回渲染后的 DOM 文本。"""
    return run(url, **kw).stdout


def shoot(url, out, window="1060x900", **kw):
    """截图到 out。"""
    kw.setdefault("profile", run_profile())
    return run(url, screenshot=out, window=window, hide_scrollbars=True, **kw)
