#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""样式取值抽样对账（prototype-restore / Step 8 新增项）

背景：Step 4 抽取阶段必须产出「样式取值表」（逐页逐区域的尺寸、间距、圆角、
字号、字重、颜色、行高）。本脚本把这张表与原型里的实际取值做对账，把
「看起来像」变成「取值对得上」。这是防止"结构像、像素不像"的收口动作。

取值表格式（JSON）:

    {
      "screen": "mini-program",
      "scale": {"designWidth": 750, "unit": "rpx", "pxPerRpx": 0.5},
      "values": [
        {"page": "全部商品", "area": "商品卡片", "prop": "border-radius",
         "value": "0", "source": "all.wxss .product-card"},
        {"page": "全部商品", "area": "商品名称", "prop": "font-size",
         "value": "26rpx", "source": "all.wxss .product-name"},
        {"page": "选品单", "area": "价格文字", "prop": "color",
         "value": "#E65100", "source": "selection.wxss .item-price-text"}
      ]
    }

判定规则:
    一条取值算「已落实」，当且仅当原型文本中能找到该取值本身，或其换算后的等价写法：
      · 带 rpx 的值 —— 同时接受原值与按 pxPerRpx 换算出的 px 值（如 26rpx / 13px）
      · 十六进制颜色 —— 忽略大小写
      · 其余值 —— 按字面匹配
    可选的 "required": false 表示该条仅提示、不阻断。

用法:
    python3 audit_visual_values.py --spec styles.json --html 端-prd.html
    python3 audit_visual_values.py --spec styles.json --html 端-prd.html --warn-only
    python3 audit_visual_values.py --spec styles.json --html 端-prd.html --min-hit 0.95

退出码: 0 = 达标; 1 = 存在未落实的取值（warn-only 时始终为 0）
"""
from __future__ import annotations

import argparse
import json
import re
import sys


def read(path):
    return open(path, encoding="utf-8", errors="replace").read()


def variants(entry, scale):
    """一条取值在原型文本中的所有可接受写法。

    带单位的值只接受「原单位写法」与「换算后的等价写法」两种，
    不再回退到裸数字 —— 否则 99rpx 会被原型里任意出现的 "99" 蒙混过关。
    """
    raw = str(entry.get("value", "")).strip()
    out = {raw}
    if not raw:
        return set()
    low = raw.lower()
    # 「4rpx 14rpx」「calc(40rpx + 10rpx)」这类多值写法必须逐个数字换算，
    # 只取末尾数字会得到 "414" 这种荒谬值，把正确还原误判成未落实
    if "rpx" in low:
        per = float(scale.get("pxPerRpx") or 0)
        if per:
            def _conv(m):
                return ("%g" % (float(m.group(1)) * per)) + "px"
            def _conv2(m):
                return ("%.4f" % (float(m.group(1)) * per)).rstrip("0").rstrip(".") + "px"
            # 用 raw 而不是 low：translateX(24rpx) 转成 translateX(12px)，
            # 大小写必须与原型一致，否则把正确还原判成未落实
            out.add(re.sub(r"([0-9.]+)\s*rpx", _conv, raw, flags=re.I))
            out.add(re.sub(r"([0-9.]+)\s*rpx", _conv2, raw, flags=re.I))
    elif re.fullmatch(r"[0-9.]+px", low):
        pass
    elif re.fullmatch(r"[0-9.]+", raw):
        out.add(raw)                       # 无单位的数值：只能做弱校验
    if re.fullmatch(r"#[0-9a-fA-F]{3,8}", raw):
        out.add(raw.upper())
    # 单文件样式表里没有优先级竞争，源码带的 !important 在原型里可以不写
    if "!important" in low:
        out.add(re.sub(r"\s*!important\s*", "", low))
    # 复合值里的十六进制色值大小写不敏感（border: 1px solid #E8EEF3）
    for v in list(out):
        if "#" in v:
            out.add(re.sub(r"#[0-9a-fA-F]{3,8}", lambda m: m.group(0).upper(), v))
            out.add(re.sub(r"#[0-9a-fA-F]{3,8}", lambda m: m.group(0).lower(), v))
    return out


def is_weak(entry):
    """无单位的裸数值属于弱校验：原型里任意位置出现同名数字即算命中。"""
    raw = str(entry.get("value", "")).strip()
    return bool(re.fullmatch(r"[0-9.]+", raw))


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--spec", required=True, help="样式取值表 JSON")
    ap.add_argument("--html", required=True, help="原型 HTML")
    ap.add_argument("--warn-only", action="store_true", help="未落实只提示，不阻断")
    ap.add_argument("--min-hit", type=float, default=1.0, help="达标比例，默认 1.0")
    args = ap.parse_args()

    try:
        spec = json.loads(read(args.spec))
    except json.JSONDecodeError as exc:
        print("错误: 取值表不是合法 JSON -> %s" % exc)
        return 1
    entries = spec.get("values") or []
    if not entries:
        print("错误: 取值表中没有 values 条目")
        return 1
    scale = spec.get("scale") or {}
    html = read(args.html)

    by_page = {}
    missing = []
    optional_missing = []
    weak = []
    for e in entries:
        page = e.get("page", "(未标注页面)")
        if is_weak(e):
            weak.append((page, e.get("area", ""), e.get("prop", ""), e.get("value", ""), e.get("source", "")))
        ok = False
        for v in variants(e, scale):
            if not v:
                continue
            if re.fullmatch(r"#[0-9a-fA-F]{3,8}", v):
                if re.search(re.escape(v), html, re.I):
                    ok = True
                    break
            elif v in html:
                ok = True
                break
        slot = by_page.setdefault(page, [0, 0])
        slot[1] += 1
        if ok:
            slot[0] += 1
        else:
            row = (page, e.get("area", ""), e.get("prop", ""), e.get("value", ""), e.get("source", ""))
            if e.get("required", True):
                missing.append(row)
            else:
                optional_missing.append(row)

    total = len(entries)
    hit = total - len(missing) - len(optional_missing)
    rate = hit / total if total else 0.0

    print("=" * 68)
    print("取值表: %s" % args.spec)
    print("原型  : %s" % args.html)
    print("规模  : 取值 %d 条（换算口径 %s）" % (total, "1%s = %s px" % (scale.get("unit", "rpx"), scale.get("pxPerRpx", "?"))))
    print("=" * 68)
    for page, (ok, cnt) in sorted(by_page.items(), key=lambda kv: -kv[1][1]):
        print("  %-16s %d/%d" % (page, ok, cnt))
    print()

    if missing:
        print("[ERROR] 未在原型中落实的取值: %d 条" % len(missing))
        print("        这些取值在原型里找不到对应写法，说明该处仍按印象还原")
        for page, area, prop, value, source in missing:
            print("   %-14s %-16s %-14s %-10s  来源: %s" % (page, area, prop, value, source))
        print()
    if optional_missing:
        print("[WARN ] 非必查取值未落实: %d 条" % len(optional_missing))
        for page, area, prop, value, source in optional_missing:
            print("   %-14s %-16s %-14s %-10s  来源: %s" % (page, area, prop, value, source))
        print()
    if weak:
        print("[INFO ] 弱校验取值: %d 条 —— 数值未带单位，原型里任意位置出现同名数字即算命中" % len(weak))
        print("        建议在取值表中记录带单位的原值（如 26rpx），弱校验项只作辅助")
        for page, area, prop, value, source in weak[:6]:
            print("   %-14s %-16s %-14s %-10s  来源: %s" % (page, area, prop, value, source))
        if len(weak) > 6:
            print("   … 其余 %d 条" % (len(weak) - 6))
        print()

    print("落实率: %.1f%%（阈值 %.1f%%）" % (rate * 100, args.min_hit * 100))
    print("=" * 68)
    if missing and rate < args.min_hit:
        if args.warn_only:
            print("结果: 未达标，但按 --warn-only 放行 —— 请人工补齐")
            return 0
        print("结果: 未落实 —— 按取值表补齐原型样式后重跑")
        return 1
    print("结果: 达标 —— 通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
