#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""覆盖度对账（prototype-restore / Step 8）

把 Step 1 产出的页面清单与原型 HTML 中实际注册的视图做对账，报出：
  [缺失] 清单有、原型无 —— 阻断，必须补齐或在交付说明中逐条写明
  [多余] 原型有、清单无 —— 提示，确认是否为合法子状态（如"已下架"）

用法:
    python3 audit_coverage.py --pages app.json --html mini-program-prd.html
    python3 audit_coverage.py --pages pages.txt --html admin-prd.html
    python3 audit_coverage.py --html x.html --views index,detail,user

--pages 支持:
    *.json              小程序 app.json（自动读 pages + subPackages）
    其他文本文件         每行一个页面标识，支持 "键" / "键|中文名" / "pages/index/index"
    （也可用 --views 直接内联传逗号分隔的清单）

退出码: 0 = 无缺失; 1 = 存在缺失页面

设计取向：宁可多报，不可漏报。
页面标识会展开成多个候选键（末段 / 全段拼接）去匹配原型视图，命中任一即算覆盖，
因此命名别名（如路由 product/add 对应视图 productForm）会被报为「缺失 + 近似项」，
而非静默通过——由人工据近似项裁定，避免真实漏页被命名差异掩盖。
"""
from __future__ import annotations

import argparse
import difflib
import json
import os
import re
import sys

CJK = r"一-鿿"

# 原型中"注册一个视图"的各种写法。命中越多越可靠，多余项只是提示。
VIEW_PATTERNS = [
    # ['index','首页 · Banner 分组轮播']  —— 二元组，第二项含中文
    re.compile(r"\[\s*'([A-Za-z][\w-]*)'\s*,\s*'[^']*[" + CJK + r"][^']*'\s*\]"),
    # {id:'product', n:'商品管理', i:'🛍️'}
    re.compile(r"\bid\s*:\s*'([A-Za-z][\w-]*)'"),
    # PAGES.dashboard / PAGES['dashboard']
    re.compile(r"PAGES(?:\.|\[\s*['\"])([A-Za-z][\w-]*)"),
    # data-view="detail" / data-page="detail"
    re.compile(r"data-(?:view|page|screen)\s*=\s*[\"']([\w-]+)[\"']"),
    # id="view-detail"
    re.compile(r"\bid\s*=\s*[\"'](?:view|page|screen)-([\w-]+)[\"']"),
    # go('product') / switchView('detail') / registerView('x')
    re.compile(r"\b(?:go|switchView|showView|registerView|navigate)\s*\(\s*'([\w-]+)'"),
]

# 目录层级中属于"容器"而非页面名的段
ROOT_SEGMENTS = {"pages", "src", "app", "views", "screens", "components", "routes"}
EXT_RE = re.compile(r"\.(js|jsx|ts|tsx|vue|wxml|html|json|java)$", re.I)


def canon(value):
    """归一化：只保留字母数字并小写，消除 detail-comments / detailComments 的差异。"""
    return re.sub(r"[^a-z0-9]", "", value.lower())


def candidates(raw):
    """一个页面标识可能对应多种原型命名，全部作为候选键。"""
    raw = raw.split("|")[0].strip().strip("'\"")
    if not raw:
        return set()
    segs = [s for s in re.split(r"[/\\]", raw) if s and not s.startswith(":")]
    segs = [EXT_RE.sub("", s) for s in segs]
    segs = [s for s in segs if s and s.lower() not in ROOT_SEGMENTS]

    out = {canon(raw)}
    if segs:
        out.add(canon(segs[-1]))
        out.add(canon("".join(segs)))
        if len(segs) > 1 and segs[-1] == segs[-2]:
            out.add(canon(segs[-1]))
    return {c for c in out if c}


def load_pages(path):
    """读回页面清单，返回 [(原始标识, 候选键集合)]。"""
    if not path:
        return None
    if not os.path.exists(path):
        sys.exit("错误: 页面清单不存在 -> %s" % path)

    if path.lower().endswith(".json"):
        text = open(path, encoding="utf-8").read()
        data = None
        try:
            data = json.loads(text)
        except ValueError:
            # app.json 常带注释，退化为抽取 "pages": [...] 里的字符串
            block = re.search(r'"(?:pages|subPackages)"\s*:\s*\[(.*?)\n\s*\]', text, re.S)
            found = re.findall(r'"([^"]+)"', block.group(1)) if block else []
            return [(p, candidates(p)) for p in found if "/" in p]
        raw = list(data.get("pages") or [])
        for sub in (data.get("subPackages") or data.get("subpackages") or []):
            root = (sub.get("root") or "").strip("/")
            for p in sub.get("pages") or []:
                raw.append("%s/%s" % (root, p) if root else p)
        return [(p, candidates(p)) for p in raw]

    lines = [ln.strip() for ln in open(path, encoding="utf-8")]
    entries = []
    for ln in lines:
        if not ln or ln.startswith("#"):
            continue
        entries.append((ln, candidates(ln)))
    return entries


def extract_views(html_path):
    """从原型 HTML 抽取实际注册的视图键 -> 原始写法。"""
    text = open(html_path, encoding="utf-8").read()
    found = {}
    for pat in VIEW_PATTERNS:
        for name in pat.findall(text):
            found.setdefault(canon(name), name)
    return found


def main():
    ap = argparse.ArgumentParser(description="原型覆盖度对账")
    ap.add_argument("--pages", help="页面清单：app.json 或每行一个标识的文本文件")
    ap.add_argument("--views", help="内联页面清单，逗号分隔（与 --pages 二选一）")
    ap.add_argument("--html", required=True, help="待检查的原型 HTML")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出，便于 CI 消费")
    args = ap.parse_args()

    if not os.path.exists(args.html):
        sys.exit("错误: 原型文件不存在 -> %s" % args.html)

    if args.views:
        entries = [(v.strip(), candidates(v)) for v in args.views.split(",") if v.strip()]
        source = "--views"
    else:
        entries = load_pages(args.pages)
        source = args.pages
    if not entries:
        sys.exit("错误: 未取得任何基准页面，请检查 --pages / --views（--pages 是必填项之一）")

    views = extract_views(args.html)
    if not views:
        sys.exit("错误: 未从 %s 抽取到任何已注册视图。\n"
                 "请确认原型通过可见方式注册页面，或在交付说明中改用 --views 并人工核对。" % args.html)

    missing, extra = [], []
    for raw, cands in entries:
        if not (cands & set(views)):
            near = difflib.get_close_matches(
                sorted(cands)[-1] if cands else canon(raw), list(views), n=2, cutoff=0.5)
            missing.append({"page": raw, "candidates": sorted(cands), "near": near})
    page_keys = set()
    for _, cands in entries:
        page_keys |= cands
    for key, raw in sorted(views.items()):
        if key not in page_keys:
            extra.append(raw)

    if args.json:
        print(json.dumps({"missing": missing, "extra": extra,
                          "pages": len(entries), "views": len(views)},
                         ensure_ascii=False, indent=2))
        return 1 if missing else 0

    print("基准页面: %d 项（来源 %s）" % (len(entries), source))
    print("原型视图: %d 项（来源 %s）" % (len(views), args.html))
    print()

    if missing:
        print("[缺失 %d] 清单有、原型无 —— 必须补齐，或在交付说明中逐条写明理由" % len(missing))
        for m in missing:
            hint = "近似: %s" % "、".join(m["near"]) if m["near"] else "无近似项"
            print("  %-34s %s" % (m["page"], hint))
        print()

    if extra:
        print("[多余 %d] 原型有、清单无 —— 确认是否为合法子状态（如\"已下架\"）" % len(extra))
        for e in extra:
            print("  %s" % e)
        print()

    if missing:
        print("结果: 缺失 %d 项 —— 返工" % len(missing))
        return 1
    print("结果: 无缺失 —— 通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
