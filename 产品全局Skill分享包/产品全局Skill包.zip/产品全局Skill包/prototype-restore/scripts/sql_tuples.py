#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 SQL 里的 INSERT 值行解析成结构化数据（供原型取真实数据用）。

为什么需要它：原型里的示例数据常常来自 PRD/设计稿等文档，与代码不一致。
正确做法是直接解析后端的种子 SQL（如 resources/db/data.sql）逐列取值。
难点是 desc / specs 这类列里既含中文逗号也含 ASCII 逗号和引号，
朴素 split(',') 会把一行切碎。

用法：
    python3 sql_tuples.py data.sql                 # 列出所有 INSERT 的表名与行数
    python3 sql_tuples.py data.sql --table biz_product          # 输出该表所有行(JSON)
    python3 sql_tuples.py data.sql --table biz_product --fields id,name,price,sort_order
    python3 sql_tuples.py data.sql --table biz_banner --where "group_no=1"
"""
import argparse
import json
import re
import sys


def split_tuple(s):
    """按顶层逗号切分 SQL 值元组，尊重单引号字符串与 '' 转义。"""
    out, cur, q, i = [], "", False, 0
    while i < len(s):
        c = s[i]
        if q:
            if c == "'":
                if i + 1 < len(s) and s[i + 1] == "'":
                    cur += "'"; i += 2; continue
                q = False
            cur += c
        else:
            if c == "'":
                q = True; cur += c
            elif c == ",":
                out.append(cur); cur = ""
            else:
                cur += c
        i += 1
    out.append(cur)
    return [x.strip() for x in out]


def unquote(v):
    v = v.strip()
    if v.upper() == "NULL":
        return None
    if len(v) >= 2 and v[0] == "'" and v[-1] == "'":
        return v[1:-1].replace("''", "'")
    try:
        return int(v)
    except ValueError:
        return v


def parse_sql(text):
    """返回 {表名: {'columns': [...], 'rows': [[...], ...]}}"""
    text = re.sub(r"--[^\n]*", "", text)
    tables = {}
    for m in re.finditer(
        r"INSERT\s+INTO\s+`?(\w+)`?\s*(?:\(([^)]*)\))?\s*VALUES\s*(.*?);",
        text, re.S | re.I):
        name, cols, values = m.group(1), m.group(2), m.group(3)
        columns = [c.strip().strip("`") for c in cols.split(",")] if cols else None
        rows = []
        for rm in re.finditer(r"\(((?:[^()']|'(?:[^']|'')*')*)\)", values, re.S):
            rows.append([unquote(v) for v in split_tuple(rm.group(1))])
        entry = tables.setdefault(name, {"columns": columns, "rows": []})
        entry["rows"].extend(rows)
        if entry["columns"] is None:
            entry["columns"] = columns
    return tables


def main():
    ap = argparse.ArgumentParser(description="解析 SQL 的 INSERT 数据")
    ap.add_argument("sql")
    ap.add_argument("--table")
    ap.add_argument("--fields", default="", help="要输出的列名，逗号分隔")
    ap.add_argument("--where", default="", help="简单过滤，形如 group_no=1")
    a = ap.parse_args()
    tables = parse_sql(open(a.sql, encoding="utf-8", errors="ignore").read())
    if not a.table:
        for k, v in tables.items():
            print("%-28s %3d 行  列: %s" % (k, len(v["rows"]), ",".join(v["columns"] or []) or "（未声明）"))
        return
    t = tables.get(a.table)
    if not t:
        sys.exit("未找到表 %s（可用：%s）" % (a.table, ", ".join(tables)))
    cols = t["columns"]
    if a.fields:
        want = [f.strip() for f in a.fields.split(",")]
    else:
        want = cols
    idx = {c: i for i, c in enumerate(cols)} if cols else {}
    out = []
    for row in t["rows"]:
        if not cols:
            out.append(row); continue
        rec = {c: (row[idx[c]] if idx[c] < len(row) else None) for c in want}
        if a.where:
            k, _, v = a.where.partition("=")
            if str(rec.get(k.strip())) != v.strip():
                continue
        out.append(rec)
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
