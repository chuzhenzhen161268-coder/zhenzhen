#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""视图直达能力检查（prototype-restore / Step 8 新增项）

背景：原型必须支持通过地址片段直达任意一屏（如 端-prd.html#选品单对应视图名）。
这条要求在流程里的权重很高 —— 没有直达能力时，核对一屏要点四五下，
核对成本被抬高后，**逐屏核对一定会被压缩**，视觉缺陷就会成批漏检。

本脚本做两级检查：
  静态级（默认）  原型是否具备地址片段直达的入口；可达视图名与页面清单是否一一对应
  渲染级（--render）用无头浏览器实际打开 #视图名，确认渲染结果与默认首页不同
                    —— 用于抓「接线漏了、点了没反应」这类问题

用法:
    python3 check_deeplink.py --html 端-prd.html
    python3 check_deeplink.py --html 端-prd.html --pages pages.txt
    python3 check_deeplink.py --html 端-prd.html --pages app.json --render
    python3 check_deeplink.py --html 端-prd.html --render --render-limit 6

--pages 支持与 audit_coverage.py 相同的两种格式（页面清单文本 / 小程序 app.json）
--registry 指定视图注册表变量名；同页存在多组「英文 + 中文」二元组（导航类型映射、
           标题映射…）时自动探测可能多算视图名，进而对不存在的视图误报「直达未接线」
--default-view 填「不带地址片段时实际打开的那一屏」。填错会让该屏被当成
           「与默认页一致」而误报（它本来就是默认页）
--same-ok 声明「本来就会收敛到默认页」的视图（如启动页自动进入首页）。
           这类视图与默认页的最终渲染必然相同，属实现属性而非接线缺陷
--render 渲染级检查需要本机可用的 Chrome；--render-limit 限制抽查数量（默认全部）

退出码: 0 = 通过; 1 = 存在阻断问题
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
import re
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _browser  # noqa: E402  共享的浏览器发现与调用

HASH_RE = re.compile(r"location\s*\.\s*hash|location\.hash")
# 视图名 -> 地址片段 的常见接线写法
WIRE_PATTERNS = [
    re.compile(r"VIEWS\s*\[\s*(?:hash|key)\s*\]"),
    re.compile(r"PAGES\s*\[\s*(?:hash|key)\s*\]"),
    re.compile(r"\{\s*\[?\s*(?:hash|key)\s*\]?\s*:\s*\w+\s*\}"),
    re.compile(r"(?:hash|key)\s*(?:&&|in)\s*"),
]
VIEW_PATTERNS = [
    re.compile(r"\[\s*'([A-Za-z][\w-]*)'\s*,\s*'[^']*[一-鿿][^']*'\s*\]"),
    re.compile(r"\bid\s*:\s*'([A-Za-z][\w-]*)'"),
    re.compile(r"PAGES(?:\.|\[\s*['\"])([A-Za-z][\w-]*)"),
    re.compile(r"data-(?:view|page|screen)\s*=\s*[\"']([\w-]+)[\"']"),
]
CJK = r"一-鿿"
ROOT_SEGMENTS = {"pages", "src", "app", "views", "screens", "components", "routes"}
EXT_RE = re.compile(r"\.(js|jsx|ts|tsx|vue|wxml|html|json|java)$", re.I)



def read(path):
    return open(path, encoding="utf-8", errors="replace").read()


def array_body(text, start):
    """从 start 处的 '[' 起按方括号配平截取数组字面量（跳过字符串）。"""
    i = text.index("[", start)
    depth = 0
    q = None
    while i < len(text):
        c = text[i]
        if q:
            if c == "\\":
                i += 2
                continue
            if c == q:
                q = None
        elif c in "'\"":
            q = c
        elif c in "[{(":
            depth += 1
        elif c in "]})":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
        i += 1
    return text[start:start + 4000]


PAIR_RE = VIEW_PATTERNS[0]
ARR_RE = re.compile(r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\[")


def detect_views(html, prefer=None):
    """探测视图注册点。

    只取「数组字面量内部」的二元组 —— 页面里常另有导航类型映射、标题映射等
    同样是「英文 + 中文」的对象字面量，全局扫描会把它们的值也当成视图名，
    进而对不存在的视图报「直达未接线」。多组候选时取二元组最多者，
    可用 prefer 指定注册表变量名。
    """
    cands = []
    for m in ARR_RE.finditer(html):
        body = array_body(html, m.end() - 1)
        pairs = PAIR_RE.findall(body)
        if pairs:
            cands.append((m.group(1), pairs))
    if not cands:
        keys = [k for pat in VIEW_PATTERNS for k in pat.findall(html)]
        return sorted(set(keys)), None
    if prefer:
        chosen = [c for c in cands if c[0] == prefer] or [max(cands, key=lambda c: len(c[1]))]
    else:
        chosen = [max(cands, key=lambda c: len(c[1]))]
    keys = [k for _, ps in chosen for k in ps]
    for pat in VIEW_PATTERNS[1:]:
        keys += pat.findall(html)
    return sorted(set(keys)), chosen[0][0]


def canon(v):
    return re.sub(r"[^a-z0-9]", "", v.lower())


def candidates(raw):
    raw = raw.split("|")[0].strip().strip("'\"")
    if not raw:
        return set()
    segs = [s for s in re.split(r"[/\\]", raw) if s and not s.startswith(":")]
    segs = [EXT_RE.sub("", s) for s in segs]
    segs = [s for s in segs if s and s.lower() not in ROOT_SEGMENTS]
    out = {canon(raw)}
    if segs:
        out.add(canon(segs[-1]))
        out.add(canon("".join(segs)))
    return {c for c in out if c}


def load_pages(path):
    if not path:
        return []
    if path.lower().endswith(".json"):
        data = json.loads(read(path))
        pages = list(data.get("pages") or [])
        for sub in data.get("subPackages") or []:
            root = sub.get("root", "")
            for p in sub.get("pages") or []:
                pages.append("%s/%s" % (root, p))
        return [p for p in pages if p]
    return [ln.strip() for ln in read(path).splitlines() if ln.strip() and not ln.strip().startswith("#")]


def find_chrome():
    """浏览器发现统一走共享模块（优先轻量无头内核，见 _browser.py）。"""
    return _browser.find()


def dump_dom(chrome, url):
    """取回渲染后的 DOM（用户目录按轮隔离，见 _browser.py）。"""
    return _browser.dump(url, chrome=chrome, budget=2500, hide_scrollbars=True, timeout=300)


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--html", required=True)
    ap.add_argument("--pages", default="")
    ap.add_argument("--render", action="store_true")
    ap.add_argument("--render-limit", type=int, default=0)
    ap.add_argument("--default-view", default="", help="默认视图名（其渲染结果本就等于不带片段的默认页）")
    ap.add_argument("--registry", default="", help="指定视图注册表变量名（默认自动挑选二元组最多者）")
    ap.add_argument("--same-ok", default="",
                    help="声明「最终渲染结果与默认页相同」的视图名（逗号分隔）。"
                         "典型场景：启动页/引导页会自动进入默认页，两者最终渲染必然相同")
    ap.add_argument("--chrome", default="")
    args = ap.parse_args()

    html = read(args.html)
    print("=" * 68)
    print("文件: %s" % args.html)
    print("=" * 68)

    errors = 0

    # ---- 静态级 1：是否具备地址片段直达入口 ----
    if HASH_RE.search(html):
        print("[ OK  ] 直达入口: 已读取地址片段")
    else:
        print("[ERROR] 直达入口: 未发现读取地址片段的代码，原型无法直达指定页面")
        print("        影响：核对一屏需多次点击，逐屏核对会被压缩，视觉缺陷成批漏检")
        errors += 1

    wired = any(p.search(html) for p in WIRE_PATTERNS)
    if wired:
        print("[ OK  ] 接线: 地址片段已用于选择视图")
    else:
        print("[WARN ] 接线: 未识别到「地址片段 -> 视图」的选择逻辑，请人工确认")

    # ---- 静态级 2：可达视图名与页面清单对账 ----
    keys, regvar = detect_views(html, args.registry)
    if not keys:
        print("[WARN ] 视图注册: 未识别到视图注册点，跳过可达性对账")
    else:
        print("[ OK  ] 视图注册: 识别到 %d 个视图（注册表：%s）" % (len(keys), regvar or "自动"))
    keys = set(keys)
    pages = load_pages(args.pages)
    if pages:
        unknown = []
        for raw in pages:
            cand = candidates(raw)
            if cand and not (cand & {canon(k) for k in keys}):
                best = difflib.get_close_matches(canon(raw), [canon(k) for k in keys], n=1)
                unknown.append((raw, best[0] if best else ""))
        if unknown:
            print("[WARN ] 页面清单中这些页面未找到同名可达视图（人工确认命名对应关系）: %d 个" % len(unknown))
            for raw, near in unknown:
                print("   %-32s 近似视图: %s" % (raw, near or "无"))
        else:
            print("[ OK  ] 可达性: 页面清单 %d 项全部有同名可达视图" % len(pages))
    print()

    # ---- 渲染级：实际打开 #视图名，确认渲染结果变化 ----
    if args.render:
        chrome = args.chrome or find_chrome()
        if not chrome:
            print("[WARN ] 渲染级检查: 未找到可用的 Chrome，跳过")
        else:
            base = "file://" + os.path.abspath(args.html)
            keys_sorted = sorted(keys)
            if args.render_limit:
                keys_sorted = keys_sorted[:args.render_limit]
            print("渲染级检查（共 %d 个视图）: 打开 #视图名，确认页面确实切换" % len(keys_sorted))
            try:
                plain = dump_dom(chrome, base)
            except Exception as exc:                       # noqa: BLE001
                print("[WARN ] 渲染级检查失败: %s" % exc)
                sys.exit(0)
            base_hash = hashlib.md5(plain.encode("utf-8", "replace")).hexdigest()
            unchanged = []
            for k in keys_sorted:
                try:
                    dom = dump_dom(chrome, "%s#%s" % (base, k))
                except Exception:                           # noqa: BLE001
                    unchanged.append((k, "渲染超时"))
                    continue
                if hashlib.md5(dom.encode("utf-8", "replace")).hexdigest() == base_hash:
                    unchanged.append((k, "与不带片段的默认页渲染结果完全一致"))
            converge = {canon(v) for v in args.same_ok.replace("；", ",").split(",") if v.strip()}
            if args.default_view:
                converge.add(canon(args.default_view))
            if converge:
                unchanged = [x for x in unchanged if x[0] not in converge]
            # 只有一个视图与默认页相同时，它极可能本身就是默认视图；
            # 若有两个以上相同，则说明地址片段没有被用于切换视图。
            if unchanged and converge:
                print("[info] 已按声明忽略与默认页一致的视图: %s" % ", ".join(sorted(converge)))
            if len(unchanged) >= 2:
                print("[ERROR] 以下视图名没有切换页面，直达接线可能有遗漏: %d 个" % len(unchanged))
                for k, why in unchanged:
                    print("   #%-28s %s" % (k, why))
                errors += 1
            elif len(unchanged) == 1:
                k, why = unchanged[0]
                print("[WARN ] #%s %s" % (k, why))
                print("        若它就是默认视图，属正常；否则说明该视图的直达接线没生效。")
                print("        确认后可用 --default-view %s 消除本提示。" % k)
            else:
                print("[ OK  ] 渲染级: 抽查的视图名全部成功切换到对应页面")
        print()

    print("=" * 68)
    if errors:
        print("结果: 存在阻断问题 —— 修复后重跑")
        return 1
    print("结果: 无阻断问题 —— 通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
