#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""类名与样式定义齐全性检查（prototype-restore / Step 8 新增项）

背景：原型里引用了类名、但样式区没有定义该类的规则时，元素会**静默退化**
（例如 flex 行退化为块级、被拆成两行）。这类缺陷不会报错、不会中断渲染，
肉眼扫截图极易漏掉，必须用差集检查兜住。

用法:
    python3 check_style_coverage.py 端-prd.html
    python3 check_style_coverage.py 端-prd.html --ignore tx on off active
    python3 check_style_coverage.py 端-prd.html --allow-missing known.txt

采集口径: url(data:...) 内联资源整段剥离后再采集，避免把资源内部字样当成类名
--ignore        追加忽略的类名（空格分隔），用于样式表之外真正无定义需求的类
--allow-missing 从文件读取允许缺失的类名（每行一个，# 开头为注释）

退出码: 0 = 无缺失; 1 = 存在引用但未定义样式的类

判定口径:
    引用来源 —— 标记区 class 属性，以及脚本区字符串字面量里的 class 片段
    定义来源 —— <style> 区里的 .类名 选择器
    只保留形如 [a-z][a-z0-9-]* 的类名，避免把脚本拼接片段误当类名
"""
from __future__ import annotations

import argparse
import re
import sys

STYLE_RE = re.compile(r"<style\b[^>]*>(.*?)</style\s*>", re.S | re.I)
CLASS_ATTR_RE = re.compile(r"""class\s*=\s*(?:"([^"]*)"|'([^']*)')""", re.I)
CLASSNAME_RE = re.compile(r"""className\s*=\s*(?:"([^"]*)"|'([^']*)')""", re.I)
CLASSLIST_RE = re.compile(r"""classList\s*\.\s*(?:add|toggle|remove)\s*\(\s*'([^']*)'""", re.I)
SETATTR_RE = re.compile(r"""setAttribute\s*\(\s*['"]class['"]\s*,\s*['"]([^'"]*)['"]""", re.I)
CLASS_TOKEN_RE = re.compile(r"^[a-z][a-z0-9-]*$")
DYN_RE = re.compile(r"[+()\[\]?:]")
DEF_RE = re.compile(r"\.(-?[A-Za-z_][A-Za-z0-9_-]*)")


URL_ASSET_RE = re.compile(r"""url\(\s*(?:"[^"]*"|'[^']*'|[^)]*)\)""", re.I)


def read(path):
    return open(path, encoding="utf-8", errors="replace").read()


def strip_assets(html):
    """剥离内联资源（url(data:...)）后再采集类名。

    内联的矢量图常被网站图标工具导出成「URL 编码的 SVG 源码」，其中可能
    带着 class='...' 之类的字样。不剥离就会把资源内部的名字当成原型里
    引用的类名，报出一批永远无法补齐的假缺失（误报会让人不再看报告）。
    """
    return URL_ASSET_RE.sub("url()", html)


def defined_classes(style_text):
    return set(DEF_RE.findall(style_text))


def _norm_tokens(raw):
    """把类属性里的值切成类名。

    类属性的值有两种形态：
      · 静态：class="product-card list-item"        —— 整串都是类名
      · 拼接：class="tb' + (x ? ' on' : '') + '"    —— 只有两处是类名：
          1) 紧随属性起始引号的静态片段（tb）
          2) 作为三元或拼接操作数的字符串字面量（' on'）
        穿插其中的 JS 变量、运算符、以及用作比较值的字面量（如 x === 'on'）
        都不是类名，必须排除，否则会把状态值当成类名产生大量误报。
    """
    out = []
    if not DYN_RE.search(raw):
        return [t for t in raw.split() if CLASS_TOKEN_RE.match(t)]
    lead = re.match(r"[a-z0-9\s-]*", raw)
    for tok in (lead.group(0) if lead else "").split():
        if not tok.endswith("-") and CLASS_TOKEN_RE.match(tok):   # 尾随 - 说明是动态前缀
            out.append(tok)
    for m in re.finditer(r"[?:+]\s*'([^']*)'", raw):
        for tok in m.group(1).split():
            if CLASS_TOKEN_RE.match(tok):
                out.append(tok)
    return out


def used_classes(html):
    """只从「类名出现的地方」采集：类属性、类名赋值、classList 操作。

    刻意不从脚本的普通字符串字面量里采集 —— 那样会把状态值、函数名
    一并当成类名，产生大量误报，反而让人不再看这份报告。
    """
    used = {}

    def note(name, where):
        used.setdefault(name, where)

    for m in CLASS_ATTR_RE.finditer(html):
        raw = m.group(1) if m.group(1) is not None else m.group(2)
        for tok in _norm_tokens(raw):
            note(tok, "类属性")
    for rx, where in ((CLASSNAME_RE, "类名赋值"), (CLASSLIST_RE, "类名增删"), (SETATTR_RE, "类名写入")):
        for m in rx.finditer(html):
            raw = (m.group(1) or "") if m.lastindex else m.group(0)
            for tok in _norm_tokens(raw):
                note(tok, where)
    return used


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("file")
    ap.add_argument("--ignore", default="", help="追加忽略的类名（空格分隔）")
    ap.add_argument("--allow-missing", default="", help="允许缺失的类名清单文件")
    args = ap.parse_args()

    html = strip_assets(read(args.file))
    if not STYLE_RE.search(html):
        print("错误: 未找到 <style> 区，无法判定已定义的类名")
        return 1

    style = "\n".join(m.group(1) for m in STYLE_RE.finditer(html))
    defined = defined_classes(style)
    used = used_classes(html)

    ignore = {t for t in args.ignore.split() if t}
    if args.allow_missing:
        for line in read(args.allow_missing).splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                ignore.add(line)

    missing = sorted(k for k in used if k not in defined and k not in ignore)

    print("=" * 68)
    print("文件: %s" % args.file)
    print("=" * 68)
    print("已定义类名: %d 个" % len(defined))
    print("被引用类名: %d 个" % len(used))
    print()
    if missing:
        print("[ERROR] 引用了但没有样式定义的类名: %d 个" % len(missing))
        print("        表现：这些元素会退化为浏览器的默认样式（常见是块级布局、无内边距）")
        for name in missing:
            print("   .%-28s 引用位置: %s" % (name, used[name]))
        print()
        print("结果: 存在缺失 —— 补齐样式或从原型中移除引用")
        return 1
    print("结果: 无缺失 —— 通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
