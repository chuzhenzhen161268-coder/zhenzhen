#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""样式取值对账（原型 ↔ 源样式）

把「源码里的样式取值」与「原型在浏览器里的计算值」逐条对账，报出差异。
目测截图只能发现大偏差；取值对账能抓住 1px 级差异，且可反复回归。

用法:
    # 1) 从源码样式表机械提取候选取值（rpx 自动换算为 px，1rpx=0.5px）
    python3 audit_computed_values.py --extract <样式文件或目录> [--rpx-to-px] > spec.json

    # 2) 用取值表对账原型
    python3 audit_computed_values.py --spec spec.json --html proto.html --nav go

# 把提取结果直接写成取值表，供 audit_visual_values.py 使用（两个脚本的表结构不同，
# 这条通道用于「先机械提取、再做落实率校验」的连贯流程）
    python3 audit_computed_values.py --extract src/index.css --rpx-to-px --emit-styles styles.json --screen 管理后台

spec 格式:
    {"<视图id或*>: [["<选择器>", "<css属性>", "<期望值>"], ...], ...}
    "*" 表示不切视图直接检查（用于外壳等常驻元素）。

退出码: 0 = 全部命中; 1 = 存在差异/缺失
适用范围: 单文件自包含 HTML 原型（依赖内联脚本里的视图注册表与导航函数）。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _browser  # noqa: E402  共享的浏览器发现与调用

CJK = r"一-鿿"


def find_chrome(explicit=None):
    """浏览器发现统一走共享模块（优先轻量无头内核，见 _browser.py）。"""
    return _browser.find(explicit)


def rpx(v):
    m = re.fullmatch(r"(-?[\d.]+)rpx", v.strip())
    if m:
        return "%gpx" % (float(m.group(1)) / 2)
    return v


def conv(value):
    return " ".join(rpx(p) for p in value.split())


def extract(paths, to_px):
    """机械提取样式规则，返回（{选择器: {属性: 值}}, 文件清单, {选择器: 来源文件}）。"""
    files = []
    for p in paths:
        if os.path.isdir(p):
            for dirpath, _d, fs in os.walk(p):
                files += [os.path.join(dirpath, f) for f in fs if f.endswith((".css", ".wxss"))]
        else:
            files.append(p)
    out = {}
    origin = {}
    for f in sorted(files):
        t = open(f, encoding="utf-8", errors="ignore").read()
        t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
        for m in re.finditer(r"([^{}]+)\{([^{}]*)\}", t):
            sel = " ".join(m.group(1).split())
            if not sel or sel.startswith("@"):
                continue
            rule = out.setdefault(sel, {})
            origin.setdefault(sel, os.path.basename(f))
            for d in m.group(2).split(";"):
                if ":" not in d:
                    continue
                k, v = d.split(":", 1)
                k, v = k.strip(), v.strip()
                rule[k] = conv(v) if to_px else v
    return out, files, origin


def build_harness(spec, nav):
    return """
setTimeout(function(){
 var SPEC=__SPEC__, NAV='__NAV__', out=[];
 Object.keys(SPEC).forEach(function(view){
  try{ if(view!=='*') window[NAV](view); }catch(e){ out.push('VIEWFAIL '+view+' '+e.message); return; }
  SPEC[view].forEach(function(it){
   var el=document.querySelector(it[0]);
   if(!el){ out.push('MISSING '+view+' '+it[0]); return; }
   var got=String(getComputedStyle(el)[it[1]]).replace(/\\s+/g,' ').trim(), exp=String(it[2]);
   var ok=(got===exp)||(got.indexOf(exp)===0)||(parseFloat(got)===parseFloat(exp));
   out.push((ok?'OK ':'DIFF ')+view+' '+it[0]+' '+it[1]+' exp['+exp+'] got['+got+']');
  });
 });
 document.title='VAL::'+JSON.stringify(out);
},300);
"""


def main():
    ap = argparse.ArgumentParser(description="原型样式取值对账")
    ap.add_argument("--spec", help="取值表 JSON")
    ap.add_argument("--html", help="待检查的原型 HTML")
    ap.add_argument("--nav", default="go", help="视图导航函数名（默认 go）")
    ap.add_argument("--extract", nargs="+", help="从样式文件/目录提取候选取值")
    ap.add_argument("--rpx-to-px", action="store_true", help="提取时把 rpx 换算为 px（1rpx=0.5px）")
    ap.add_argument("--chrome", default="")
    ap.add_argument("--emit-styles", metavar="OUT.json",
                    help="与 --extract 连用：把提取结果写成取值表（供 audit_visual_values.py 使用）")
    ap.add_argument("--screen", default="", help="与 --emit-styles 连用：端名称")
    ap.add_argument("--emit-strict", action="store_true",
                    help="与 --emit-styles 连用：把自动提取的取值也标为必检（默认只提示）")
    args = ap.parse_args()

    if args.extract:
        rules, files, origin = extract(args.extract, args.rpx_to_px)
        if args.emit_styles:
            values = []
            for sel, decls in rules.items():
                for prop, value in decls.items():
                    values.append({
                        "page": "", "area": sel, "prop": prop, "value": value,
                        "source": "%s %s" % (origin.get(sel, ""), sel),
                        # 自动提取的是**候选**取值（含大量本端未实现的选择器/伪类），
                        # 因此默认只提示（required=false）；把要作为门禁的关键项改成 true，
                        # 或另写一份人工确认过的取值表。
                        "required": bool(args.emit_strict),
                    })
            doc = {"screen": args.screen or "auto", "values": values}
            if args.rpx_to_px:
                doc["scale"] = {"designWidth": 750, "unit": "rpx", "pxPerRpx": 0.5}
            json.dump(doc,
                      open(args.emit_styles, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            sys.stderr.write("已写出取值表 %s（%d 条）\n" % (args.emit_styles, len(values)))
        else:
            print(json.dumps(rules, ensure_ascii=False, indent=1))
        sys.stderr.write("提取自 %d 个样式文件，%d 条规则\n" % (len(files), len(rules)))
        return 0

    if not (args.spec and args.html):
        sys.exit("错误: 需要 --spec 与 --html（或使用 --extract）")
    spec = json.load(open(args.spec, encoding="utf-8"))
    html = open(args.html, encoding="utf-8").read()
    chrome = find_chrome(args.chrome)
    if not chrome:
        sys.exit("错误: 未找到无头浏览器，可用 --chrome 指定")

    harness = build_harness(spec, args.nav).replace("__SPEC__", json.dumps(spec, ensure_ascii=False))
    harness = harness.replace("__NAV__", args.nav)
    if "</script>" not in html:
        sys.exit("错误: 未找到内联脚本块")
    patched = html.replace("</script>", harness + "\n</script>", 1)
    tmp = "/tmp/valuecheck-" + os.path.basename(args.html)
    open(tmp, "w", encoding="utf-8").write(patched)

    dom = _browser.dump("file://" + tmp, chrome=chrome, budget=3500, window="390,850")
    m = re.search(r"<title>VAL::(.*?)</title>", dom, re.S)
    if not m:
        sys.exit("错误: 未取回结果（页面可能未执行脚本）")
    res = json.loads(m.group(1).replace("&quot;", '"').replace("&amp;", "&"))
    bad = [r for r in res if not r.startswith("OK ")]
    print("检查项 %d，差异 %d" % (len(res), len(bad)))
    for b in bad:
        print("  " + b)
    print("\n结果: %s" % ("全部命中 —— 通过" if not bad else "存在差异 —— 修复后重跑"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
