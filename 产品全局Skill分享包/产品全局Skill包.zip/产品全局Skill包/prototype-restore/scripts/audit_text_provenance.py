#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""文案与数据正向溯源（prototype-restore / Step 8 第 9 项）

判定「产物里的每一段可见文案 / 业务数据，是否都能追到实现源码」：

  命中源码（表 A：有出处）
  或在声明清单里（表 B：代码确无数据，已披露）
  —— 二者都不在 => 臆造，阻断。

这是 Step 3「数据与文案取证」的机器化收口：表 A 由脚本从源码生成，
表 B 落盘为每行一条的机器可读清单，本脚本消费二者完成闭环。
「数据像不像」是印象问题，「数据是不是」由本脚本判定。

产物侧扫描口径（与 selfcheck.py 的「产品可见文案」一致）：
  · 标记区 —— 只取标签之外的文本节点（属性不参与）
  · 脚本区 —— 只取**可执行** script 块的字符串字面量（'...' / "..." / `...`），
    用小型词法器提取，正确跳过正则字面量、行/块注释与模板内插 ${...}
    （内插里的字符串照常提取）
  · 不可执行块整块跳过（见下「注解隔离」）
  · 字符串字面量本身是 HTML 片段的，取其文本节点（拼接渲染的产物全是这类）
  · 样式区、HTML 注释整段排除

**注解隔离**：还原者自述（完成度说明、页面注解、盘点提示）不是产品文案，
不受溯源判定约束，但必须在产物里**结构隔离** —— 放进不可执行块，例如：

    <script type="application/json" id="prd-notes">{"detail":"…注解…"}</script>

运行时 `JSON.parse(document.getElementById('prd-notes').textContent)` 读取，
功能不受影响；本脚本依据 type 判定为不可执行并**整块跳过**。
`type` 为空、module、javascript / text/javascript / babel 一律视为可执行。
同理，标记区的 `data-prd-note="…"` 属性整条剔除（行内的简短注解用这个）。

**交付外壳豁免**：预览壳自身的话术（产物标题、图例、页面清单、画布标注、
控制面板、"样例数据" 披露标记等）不是被还原的内容，名单由 `--exempt` 给出。
**豁免清单必须有上限** —— 豁免占候选的比例超过 `--max-exempt-ratio`（默认 15%）
即判 FAIL，否则豁免会退化成兜底垃圾桶，门禁形同虚设。

不参与判定的片段（歧义大、噪声高，靠人工抽查兜底）：
  纯数字 / 颜色与 CSS 函数值 / 尺寸单位 / URL / 标识符形态（键名、视图名、
  类名、函数名）/ 纯符号 / 无空格的拉丁词（多为键名或品牌缩写）。
匹配时对源码与片段各做一次「去空白」等价形，并把片段两端的引号、emoji、
标点修剪后再比对（标题加 emoji 前缀这类真实写法不算漂移）。

用法：
    python3 audit_text_provenance.py --html 端-prd.html --source <实现源码目录>
    python3 audit_text_provenance.py --html 端-prd.html --source <源码目录> \
        --declared 表B.txt --exempt 外壳豁免.txt [--min-hit 1.0] [--json]

    --source 可多次（多端工程先合并成一个目录，或分别指定）
    --declared / --exempt 可多次；每行一条，`#` 之后为注释

退出码： 0 = 全部有出处或已声明； 1 = 存在未声明缺失 / 覆盖率不足 / 豁免超限；
        2 = 参数 / IO 错误
"""

import argparse
import json
import os
import re
import sys

# ---------------------------------------------------------------- 常量

# 依赖与版本控制目录：无论如何都跳过（它们不是本项目的实现）
SKIP_DIRS = {"node_modules", "miniprogram_npm", ".git", "svn", "__pycache__",
             ".idea", ".vscode", "coverage"}
# 构建产物目录：**只在同时存在源码目录时才跳过**。
# 只有构建产物可读的项目（技能说明里明确允许的一类）若一律跳过，
# 会把唯一的事实来源整份排除掉，产出一片假未覆盖。
BUILD_DIRS = {"dist", "build", "target", "out", ".next", "bin", "obj"}
SOURCE_DIRS = ("src", "app", "pages", "miniprogram", "packages", "lib", "Sources")

TEXT_EXT = {".js", ".ts", ".jsx", ".tsx", ".vue", ".wxml", ".wxss", ".wxs",
            ".json", ".css", ".less", ".scss", ".sass", ".styl",
            ".html", ".htm", ".java", ".kt", ".xml", ".yml", ".yaml",
            ".properties", ".sql", ".gradle", ".swift", ".m", ".h", ".c",
            ".cpp", ".cs", ".go", ".php", ".rb", ".py", ".txt", ".cfg",
            ".conf", ".ini", ".env", ".lst"}

CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
HAS_ALNUM = re.compile(r"[A-Za-z0-9]")
HAS_LETTER = re.compile(r"[A-Za-z]")
HAS_DIGIT = re.compile(r"\d")
PURE_NUM = re.compile(r"^[\d.,\s%]+$")
DATETIME = re.compile(r"^\d{4}[-/年]\d{1,2}([-/月]\d{1,2}([日]?\s*\d{1,2}[:：]\d{2}(:\d{2})?)?)?$")
HEXISH = re.compile(r"^#?[0-9a-fA-F]{3,8}$")
UNIT_TAIL = re.compile(r"\d\s*(px|rpx|em|rem|vh|vw|pt|s|ms|%)$", re.I)
CSS_FUNC = re.compile(r"^(rgba?|hsla?|var|calc|url|linear-gradient|rgb)\(", re.I)
URLISH = re.compile(r"(https?:|data:|file:|ftp:|//|www\.)", re.I)
IDENT = re.compile(r"^[A-Za-z_$][\w$.-]*$")
RES_KEY = re.compile(r"\|\d+x\d+[cf]$", re.I)
# 内联样式声明串（border-color:#EF4444 / border-right:1px solid var(--gray-100)）：
# 渲染层用 style="..." 拼出来的，不是面向用户的文案
CSS_DECL = re.compile(r"^[a-z-]+\s*:\s*(?:var\(|#[0-9a-fA-F]{3,8}|[\d.])", re.I)      # 图片资源键：<地址>|<宽>x<高><c|f>
CALLISH = re.compile(r"^[A-Za-z_$][\w$]*\([^()]*\)$")
# 类名列表（至少含一个连字符，纯小写），如 "detail-tab-bar show"
CLASSLIST = re.compile(r"^[a-z][a-z0-9-]*(?:\s+[a-z][a-z0-9-]*)*$")
LOOKS_LIKE_MARKUP = re.compile(r"<[a-zA-Z/!]")

STYLE_BLOCK = re.compile(r"<style\b[^>]*>.*?</style\s*>", re.S | re.I)
SCRIPT_BLOCK = re.compile(r"<script\b([^>]*)>(.*?)</script\s*>", re.S | re.I)
HTML_COMMENT = re.compile(r"<!--.*?-->", re.S)
TYPE_ATTR = re.compile(r"\btype\s*=\s*['\"]([^'\"]+)['\"]", re.I)
# 可执行脚本的 MIME：type 为空或下列之一才参与扫描，其余（application/json
# 等承载注解的块）整块跳过
EXEC_TYPES = {"", "module", "text/javascript", "javascript", "text/babel",
              "babel", "text/jsx", "jsx", "js"}
NOTE_ATTR = re.compile(r"\sdata-prd-note\s*=\s*(['\"]).*?\1", re.S | re.I)
# 标签（含未闭合的残片，如字符串在标签中间断开）+ 引号，都视为文本边界：
# 拼接渲染的产物里，字符串常在属性中间断开（data-id="' + id + '"），
# 不把引号当边界的话，属性残片会整段混进候选
TEXT_SPLIT = re.compile(r"<[^>]*>?|[\"']")
WS = re.compile(r"\s+")
EDGE = re.compile(r"^[^\u3400-\u4dbf\u4e00-\u9fffA-Za-z0-9]+|[^\u3400-\u4dbf\u4e00-\u9fffA-Za-z0-9]+$")

# 词法器：正则字面量前若出现这些「上一个有意义字符」之一，则 / 视为正则开头
REGEX_PRECEDERS = set("=([{,;:!&|?+-*%~^<>./")

# ---------------------------------------------------------------- 源码侧


def skip_set(root):
    """构建产物目录只在「同根下也存在源码目录」时才跳过。"""
    if os.path.isdir(root):
        if any(os.path.isdir(os.path.join(root, d)) for d in SOURCE_DIRS):
            return SKIP_DIRS | BUILD_DIRS
        return SKIP_DIRS
    return SKIP_DIRS | BUILD_DIRS


def collect_source(roots):
    """把多个根目录下的全部文本类源文件拼成一个大字符串。"""
    files, seen = [], set()
    for root in roots:
        if os.path.isfile(root):
            cand = [root]
        else:
            cand = []
            skip = skip_set(root)
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [d for d in dirnames if d not in skip]
                for fn in filenames:
                    cand.append(os.path.join(dirpath, fn))
        for fp in cand:
            if os.path.splitext(fp)[1].lower() not in TEXT_EXT:
                continue
            rp = os.path.realpath(fp)
            if rp in seen:
                continue
            seen.add(rp)
            files.append(fp)
    chunks = []
    for fp in files:
        try:
            with open(fp, encoding="utf-8", errors="ignore") as f:
                chunks.append(f.read())
        except OSError:
            pass
    return "\n".join(chunks), len(files)


def read_declared(paths):
    out = []
    for p in paths:
        for line in open(p, encoding="utf-8").read().splitlines():
            line = line.split("#", 1)[0].strip()
            if line:
                out.append(line)
    return out


# ---------------------------------------------------------------- 词法器


def lex_strings(code):
    """提取 JS 代码中的全部字符串字面量内容（含模板字面量的静态部分）。

    关键正确性：正则字面量（可能含 ' 或 "）与注释必须被跳过，
    否则引号配对漂移、整段代码被当成文案 —— 那是这类脚本最常见的系统性误报。
    """
    out = []
    state = "code"
    buf = []
    last_sig = ""
    i, n = 0, len(code)
    while i < n:
        ch = code[i]
        nxt = code[i + 1] if i + 1 < n else ""

        if state == "code":
            if ch == "/" and nxt == "/":
                state = "line"
                i += 2
                continue
            if ch == "/" and nxt == "*":
                state = "block"
                i += 2
                continue
            if ch == "'":
                state, buf, q = "str", [], "'"
                i += 1
                continue
            if ch == '"':
                state, buf, q = "str", [], '"'
                i += 1
                continue
            if ch == "`":
                state, buf = "tpl", []
                i += 1
                continue
            if ch == "/" and (last_sig == "" or last_sig in REGEX_PRECEDERS):
                state, q, re_start = "regex", ch, i
                i += 1
                continue
            if not ch.isspace():
                last_sig = ch
            i += 1
            continue

        if state == "line":
            if ch == "\n":
                state = "code"
            i += 1
            continue

        if state == "block":
            if ch == "*" and nxt == "/":
                state = "code"
                i += 2
            else:
                i += 1
            continue

        if state == "regex":
            # 正则字面量不允许跨行：换行说明这个 / 其实是除法
            if ch == "\n":
                i = re_start + 1          # 回退，把 / 当除法重新处理
                state = "code"
                continue
            if ch == "\\":
                i += 2
                continue
            if ch == "[":
                j = i + 1
                while j < n and code[j] != "]":
                    if code[j] == "\\":
                        j += 1
                    j += 1
                i = j + 1
                continue
            if ch == "/":
                state = "code"
                last_sig = "/"
                i += 1
                continue
            i += 1
            continue

        if state == "str":          # '...' 或 "..."（只被同种引号闭合）
            if ch == "\\":
                if i + 1 < n:
                    buf.append({"n": "\n", "t": "\t", "r": "\r"}.get(nxt, nxt))
                i += 2
                continue
            if ch == q:
                out.append("".join(buf))
                state = "code"
                last_sig = "'"
                i += 1
                continue
            buf.append(ch)
            i += 1
            continue

        if state == "tpl":          # `...`
            if ch == "\\":
                if i + 1 < n:
                    buf.append({"n": "\n", "t": "\t", "r": "\r"}.get(nxt, nxt))
                i += 2
                continue
            if ch == "$" and nxt == "{":
                out.append("".join(buf))
                buf = []
                # 跳过内插表达式：找到配对的 } （跳过其中的引号串）
                j, depth = i + 2, 1
                while j < n and depth:
                    cj = code[j]
                    if cj in "'\"`":
                        j = skip_quoted(code, j)
                        continue
                    if cj == "{":
                        depth += 1
                    elif cj == "}":
                        depth -= 1
                    j += 1
                i = j
                continue
            if ch == "`":
                out.append("".join(buf))
                state = "code"
                last_sig = "'"
                i += 1
                continue
            buf.append(ch)
            i += 1
            continue

    return out


def skip_quoted(code, i):
    """i 指向引号；返回该引号串结束后的下标（含转义处理）。"""
    q = code[i]
    j = i + 1
    n = len(code)
    while j < n:
        if code[j] == "\\":
            j += 2
            continue
        if code[j] == q:
            return j + 1
        j += 1
    return n


# ---------------------------------------------------------------- 产物侧


def markup_text_nodes(markup):
    """取标记区里标签之外的文本节点。

    边界取「标签（含未闭合残片）或引号」：拼接渲染的产物里字符串常在
    标签 / 属性中间断开，不这样切会把属性残片当成文案。
    """
    markup = HTML_COMMENT.sub(" ", markup)
    out = []
    for piece in TEXT_SPLIT.split(markup):
        for line in piece.split("\n"):
            p = line.strip()
            if p:
                out.append(p)
    return out


def extract_fragments(html):
    """返回 [(片段, 来源)]：来源为 markup（文本节点）或 script（字符串字面量）。"""
    html = HTML_COMMENT.sub(" ", html)
    html = NOTE_ATTR.sub("", html)          # 行内注解属性整条剔除
    html = STYLE_BLOCK.sub(" ", html)

    shell_parts, bodies, n_skipped = [], [], 0
    last = 0
    for m in SCRIPT_BLOCK.finditer(html):
        shell_parts.append(html[last:m.start()])
        last = m.end()
        typ = TYPE_ATTR.search(m.group(1) or "")
        if typ and typ.group(1).strip().lower() not in EXEC_TYPES:
            n_skipped += 1                   # 不可执行块（注解）整块跳过
            continue
        bodies.append(m.group(2))
    shell_parts.append(html[last:])

    frags = []

    def push_text(text, origin):
        # 一律按「标签/引号为边界」取文本节点：拼接渲染的产物里，字符串
        # 经常在标签或属性中间断开（'<div ... data-id="' + id + '">'），
        # 残片不切掉会把属性串当成文案
        for p in markup_text_nodes(text):
            frags.append((p, origin))

    for part in shell_parts:
        for p in markup_text_nodes(part):
            frags.append((p, "markup"))
    for body in bodies:
        for lit in lex_strings(body):
            push_text(lit, "script")
    return frags, n_skipped


def meaningful(frag):
    """是否参与判定：见文件头的「不参与判定」清单。"""
    f = frag.strip()
    if len(f) < 2:
        return False
    # 资源定位串先判掉：路径里常带汉字（工程目录名），不能先按「含汉字即文案」放行，
    # 否则 base64 资源表里的每个键都会变成候选，把真正的臆造淹没掉
    if URLISH.search(f):
        return False
    if RES_KEY.search(f):
        return False          # 图片资源键：<地址>|<宽>x<高><c|f>
    if CALLISH.match(f):
        return False          # 生成出来的 class="..." / onclick="fn()" 之类，不是文案
    if "-" in f and CLASSLIST.match(f):
        return False          # 纯小写连字符词构成的类名列表（大写英文文案不受影响）
    cjk = CJK.findall(f)
    if cjk:
        if len(cjk) >= 2:
            return True
        # 单个汉字：除非还混有字母数字（如型号），否则当噪声
        return bool(HAS_ALNUM.search(f)) and len(f) >= 3
    if CSS_DECL.match(f):
        return False
    if PURE_NUM.match(f):
        return False
    if DATETIME.match(f):
        return False  # 日期/时间戳：歧义同纯数字，靠人工抽查
    if HEXISH.match(f):
        return False
    if UNIT_TAIL.search(f):
        return False
    if CSS_FUNC.match(f):
        return False
    if ";" in f:
        return False  # 无汉字且含分号：CSS 声明串 / 代码片段，非用户文案
    if IDENT.match(f):
        return False
    if f[0] in ".#[" or f.endswith("="):
        return False  # CSS 选择器 / 查询串 / 属性残片形态
    if not HAS_ALNUM.search(f):
        return False  # 纯符号 / 表情
    # 无汉字的候选：要求「含空格的多词」或「字母+数字的型号形态」，
    # 否则多半是键名 / 类名 / CSS 值，噪声大于信号
    if " " in f:
        return True
    return bool(HAS_LETTER.search(f) and HAS_DIGIT.search(f))


# 占位符归一化：数字、模板插值、单字母占位符（N / M / D）视为「可变位」。
# 目的 —— 拼接生成的展示值（「3小时前」 vs 源码里的「N小时前」、
# 「共 3 件商品」 vs 「共 {totalCount} 件商品」）不该被判成臆造；
# 但这只放开「可变位怎么填」，文字模板本身仍必须在源码里，门禁不失守。
#
# 用通配匹配而不是字符串脱敏：源码里 `{t:"N小时前"}` 这种写法，
# 花括号会把内层文案整段吞掉，脱敏后反而对不上。
NUM = re.compile(r"\d+")
PLACEHOLDER = re.compile(r"\d+|\{[^{}]*\}|\$\{[^{}]*\}|%[sdif]|(?<![A-Za-z])[A-Za-z](?![A-Za-z])")
WILD = r"[^\s]{0,20}"

_pattern_cache = {}


def pattern_of(frag):
    """把片段里可变位换成有限长通配，得到可搜索正则（去空白口径）。"""
    f = WS.sub("", frag)
    p = _pattern_cache.get(f)
    if p is not None:
        return p
    parts, pos = [], 0
    for m in PLACEHOLDER.finditer(f):
        parts.append(re.escape(f[pos:m.start()]))
        parts.append(WILD)
        pos = m.end()
    parts.append(re.escape(f[pos:]))
    p = re.compile("".join(parts))
    _pattern_cache[f] = p
    return p


def variants(frag):
    """片段的等价匹配形式：原样 / 去空白 / 修剪两端装饰符。"""
    f = frag.strip()
    core = EDGE.sub("", f)
    out = [f, WS.sub("", f)]
    if core and core != f:
        out += [core, WS.sub("", core)]
    return out


# ---------------------------------------------------------------- 判定


def where(frag, hay, hay_ns, declared_ns, exempt_ns):
    for v in variants(frag):
        if v in hay or WS.sub("", v) in hay_ns:
            return "source"
    # 占位符归一化后再比一次：放开可变位，卡住文字模板
    if NUM.search(frag):
        if pattern_of(frag).search(hay_ns):
            return "source"
    fns = WS.sub("", frag)
    for d in declared_ns:
        if d in fns or fns in d:
            return "declared"
    for e in exempt_ns:
        if e in fns or fns in e:
            return "exempt"
    return None


def main():
    ap = argparse.ArgumentParser(
        description="产物文案与数据的正向溯源（表A命中源码或表B已声明，否则视为臆造）")
    ap.add_argument("--html", required=True, help="待检查的原型 HTML")
    ap.add_argument("--source", required=True, action="append", help="实现源码目录（可多次）")
    ap.add_argument("--declared", action="append", default=[],
                    help="表 B 声明清单文件，每行一条（可多次）")
    ap.add_argument("--exempt", action="append", default=[],
                    help="交付外壳豁免清单文件，每行一条（可多次）")
    ap.add_argument("--max-exempt-ratio", type=float, default=0.15,
                    help="豁免占候选比例上限，默认 0.15；超限即判 FAIL（防止豁免变兜底垃圾桶）")
    ap.add_argument("--min-hit", type=float, default=1.0, help="覆盖比例达标线，默认 1.0")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出")
    args = ap.parse_args()

    if not os.path.isfile(args.html):
        print("产物不存在: %s" % args.html)
        return 2
    for p in args.source:
        if not os.path.exists(p):
            print("源码目录不存在: %s" % p)
            return 2

    html = open(args.html, encoding="utf-8").read()
    hay, nfiles = collect_source(args.source)
    hay_ns = WS.sub("", hay)
    declared = read_declared(args.declared) if args.declared else []
    declared_ns = [WS.sub("", d) for d in declared]
    exempt = read_declared(args.exempt) if args.exempt else []
    exempt_ns = [WS.sub("", e) for e in exempt]

    # 去重（按去空白形式），保留首次出现
    uniq = {}
    frags, n_skipped = extract_fragments(html)
    for frag, origin in frags:
        if not meaningful(frag):
            continue
        key = WS.sub("", frag)
        if key not in uniq:
            uniq[key] = (frag, origin)

    missing = []
    n_src = n_dec = n_exm = 0
    for key, (frag, origin) in uniq.items():
        r = where(frag, hay, hay_ns, declared_ns, exempt_ns)
        if r == "source":
            n_src += 1
        elif r == "declared":
            n_dec += 1
        elif r == "exempt":
            n_exm += 1
        else:
            missing.append((frag, origin))

    total = len(uniq)
    # 覆盖率以「扣除外壳豁免后的候选」为分母：外壳不是被还原的内容，
    # 不该拉高小数。豁免本身另有一道占比上限把关。
    judged = total - n_exm
    ratio = (n_src + n_dec) / judged if judged else 1.0
    exm_ratio = n_exm / total if total else 0.0
    over_exempt = total and exm_ratio > args.max_exempt_ratio
    missing.sort(key=lambda x: -len(x[0]))
    ok = (not missing) and ratio >= args.min_hit and not over_exempt

    if args.json:
        print(json.dumps({
            "html": args.html, "source_files": nfiles,
            "note_blocks_skipped": n_skipped,
            "candidates": total, "source_hit": n_src, "declared_hit": n_dec,
            "exempt_hit": n_exm, "exempt_ratio": round(exm_ratio, 4),
            "judged": judged, "missing": [f for f, _ in missing],
            "ratio": round(ratio, 4), "min_hit": args.min_hit,
            "max_exempt_ratio": args.max_exempt_ratio, "pass": ok,
        }, ensure_ascii=False, indent=2))
        return 0 if ok else 1

    print("=" * 64)
    print("文案与数据正向溯源")
    print("=" * 64)
    print("产物: %s" % os.path.basename(args.html))
    print("源码: %d 个根 / %d 个文本文件" % (len(args.source), nfiles))
    if n_skipped:
        print("注解块: %d 个（不可执行 script，已整块跳过）" % n_skipped)
    print()
    print("[候选片段] %d 条（去重后）" % total)
    print("  源码命中（表A）   %d" % n_src)
    print("  声明命中（表B）   %d" % n_dec)
    print("  外壳豁免          %d   占候选 %.1f%%（上限 %.0f%%%s）"
          % (n_exm, exm_ratio * 100, args.max_exempt_ratio * 100,
             "，超限" if over_exempt else ""))
    print("  参与判定          %d" % judged)
    print("  未覆盖            %d   %s" % (len(missing), "← 必须处理" if missing else ""))
    print("  覆盖率            %.1f%%（达标线 %.0f%%）" % (ratio * 100, args.min_hit * 100))
    print()
    if missing:
        print("---- 未覆盖明细（按长度降序，前 60 字，至多列 120 条）----")
        for i, (frag, origin) in enumerate(missing[:120], 1):
            print("%3d. [%s] %s" % (i, origin, frag[:60]))
        if len(missing) > 120:
            print("      …… 其余 %d 条略" % (len(missing) - 120))
        print()
        print("处置：真有代码出处的 → 检查归一化口径（去空白/修剪两端）后仍不中说明确实不在源码；")
        print("      代码确无数据的 → 进表 B 声明清单并在交付说明披露；")
        print("      属预览外壳的   → 进豁免清单，但豁免占比不得超限；")
        print("      其余           → 臆造，删除或改回真实内容。")
    if over_exempt:
        print("豁免超限：占比 %.1f%% > 上限 %.0f%%。"
              % (exm_ratio * 100, args.max_exempt_ratio * 100))
        print("          豁免是为预览外壳准备的，不是给臆造兜底的垃圾桶 —— "
              "超限说明有内容被塞进了豁免，把它们改回真实内容或走表 B。")
    print("-" * 64)
    if ok:
        print("判定: PASS")
        return 0
    if missing:
        print("判定: FAIL（存在既无代码出处、也未声明的文案/数据 => 视为臆造）")
    else:
        print("判定: FAIL（覆盖率不足或豁免超限）")
    return 1


if __name__ == "__main__":
    sys.exit(main())
