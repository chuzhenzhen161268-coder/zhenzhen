#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""单文件 HTML 原型冒烟校验（prototype-restore / Step 8 第 3 项）

把原型复制到临时目录，注入自检 harness，用无头 Chromium 执行后读回结果：
  · 逐视图：目标容器渲染出的文本长度（0 = 渲染中断）
  · 逐交互：window.onerror + 逐条 try/catch 捕获的报错
  · 标签配平：每个视图输出 <div 与 </div> 的差值（非 0 = 布局会被吞）
  · 样式规则落地率：源码 <style> 顶层规则的选择器 × 浏览器实际解析结果，
    对不上的即为**被静默丢弃**的规则（症状是「某处样式莫名不生效」且无报错）

用法:
    python3 smoke.py proto.html
    python3 smoke.py proto.html --nav switchView --container "#pgc"
    python3 smoke.py proto.html --call "openQty();confirmQty()" --call "toggleFav()"
    python3 smoke.py proto.html --shots
    python3 smoke.py proto.html --only detail --rect ".detail-bar,.screen,.content"
    python3 smoke.py proto.html --registry VIEWS        # 视图注册表自动探测不准时指定

退出码: 0 = 无报错且各视图均有内容; 1 = 存在报错或空视图
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _browser  # noqa: E402  共享的浏览器发现与调用

VIEWS_RE = re.compile(r"\[\s*'([A-Za-z][\w-]*)'\s*,\s*'([^']*[\u4e00-\u9fff][^']*)'\s*\]")
REG_RE = re.compile(r"const\s+([A-Za-z_$][\w$]*)\s*=\s*\[")


def find_chrome(explicit=None):
    """浏览器发现统一走共享模块（优先轻量无头内核，见 _browser.py）。"""
    return _browser.find(explicit)


def _array_body(text, start):
    """从 start 处的 '[' 起，按方括号配平截取数组字面量（跳过字符串）。"""
    i = text.index('[', start)
    depth = 0
    q = None
    while i < len(text):
        c = text[i]
        if q:
            if c == '\\':
                i += 2
                continue
            if c == q:
                q = None
        elif c in "'\"":
            q = c
        elif c in '[{(':
            depth += 1
        elif c in ']})':
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
        i += 1
    return text[start:start + 4000]


def detect_views(html, prefer=None):
    """探测形如 [['id','中文名'],...] 的视图注册表。

    只取该数组字面量内部（按方括号配平截断），避免把后续页面标题映射等
    其它 "latin + 中文" 二元组混进来；多组候选时取二元组最多者。
    """
    cands = []
    for m in REG_RE.finditer(html):
        body = _array_body(html, m.end() - 1)
        pairs = VIEWS_RE.findall(body)
        if pairs:
            cands.append((m.group(1), pairs))
    if not cands:
        return None, VIEWS_RE.findall(html)
    if prefer:
        for var, pairs in cands:
            if var == prefer:
                return var, pairs
    cands.sort(key=lambda x: -len(x[1]))
    return cands[0]


def style_text(html):
    """取出页面内联 <style> 的文本（跳过 data URI 里的 'style' 字样干扰）。"""
    out = []
    i = 0
    while True:
        i = html.find("<style", i)
        if i < 0:
            break
        j = html.find(">", i)
        k = html.find("</style>", j)
        if j < 0 or k < 0:
            break
        out.append(html[j + 1:k])
        i = k
    return "\n".join(out)


def source_selectors(html):
    """机械列出样式表顶层规则的选择器（用于核对浏览器是否全部解析生效）。

    背景：文案/注释里一个孤立的 '.' 会把下一条规则的选择器变成 '..foo'，
    浏览器直接丢弃整条规则，页面上表现为「某个图标/样式莫名不生效」且不报错。
    """
    css = re.sub(r"/\*.*?\*/", "", style_text(html), flags=re.S)
    depth = 0
    cur = ""
    sels = []
    for ch in css:
        if ch == "{":
            if depth == 0:
                sels.append(" ".join(cur.split()))
            depth += 1
            cur = ""
        elif ch == "}":
            depth -= 1
            cur = ""
        else:
            if depth == 0:
                cur += ch
    return [_canon_selector(s) for s in sels if s]


def _canon_selector(sel):
    """把选择器归一成可跨端比较的形式。

    浏览器会把 `.a,.b` 回写成 `.a, .b`，@keyframes 的 selectorText 为空而只有 name，
    因此两侧统一成：分组选择器按逗号拆分去空白，@keyframes 归一到 `@name`。
    """
    sel = " ".join(sel.split())
    if sel.startswith("@"):
        m = re.match(r"@(?:-\w+-)?keyframes\s+(\S+)", sel)
        if m:
            return "@" + m.group(1)
        return sel
    sel = re.sub(r"\s*([+>~])\s*", r"\1", sel)
    # 浏览器会把 "*::before" 归一化成 "::before"（省略通配前缀），两侧必须同样处理
    sel = re.sub(r"\*(?=:)", "", sel)
    return ",".join(part.strip() for part in sel.split(","))


def build_harness(args, sels=None):
    calls = args.call or []
    calls_js = "".join(
        " T('call%d',function(){%s});" % (i + 1, c) for i, c in enumerate(calls)
    )
    only = args.only or ""
    rect = args.rect or ""
    return """
/* ===== smoke harness (injected) ===== */
(function(){
 var ERRS=[]; window.onerror=function(m){ERRS.push(String(m));};
 function T(n,f){try{f();}catch(e){ERRS.push(n+':'+e.message);}}
 var VIEWS_JS = __VIEWS__;
 var NAV='__NAV__', CONT='__CONT__', ONLY='__ONLY__', RECT='__RECT__';
 var rows=[], bal=[], missing=[];
 function content(){
   var sels=CONT?[CONT]:['.content-area','#pgc','.content','main','body'];
   for(var i=0;i<sels.length;i++){var e=document.querySelector(sels[i]);if(e)return e;}
   return document.body;
 }
 VIEWS_JS.forEach(function(v){
   var id=v[0];
   if(ONLY && id!==ONLY) return;
   try{
     if(typeof window[NAV]==='function') window[NAV](id); else window[NAV](id);
     var c=content();
     var len=c?c.innerText.replace(/\\s+/g,'').length:0;
     var hlen=c?c.innerHTML.length:0;
     rows.push(id+':'+len+'/html'+hlen);
     if(len<1 && hlen<50) missing.push(id);
     try{
       var html=(typeof R!=='undefined'&&R[id])?R[id]():'';
       if(html){bal.push(id+':'+((html.match(/<div/g)||[]).length-(html.match(/<\\/div>/g)||[]).length));}
     }catch(e2){}
   }catch(e){rows.push(id+':THROW('+e.message+')');missing.push(id);}
 });
 __CALLS__
 var parsed=[];
 function canonSel(s){if(s.charAt(0)==='@')return s;s=s.replace(/\\s*([+>~])\\s*/g,'$1');s=s.replace(/\\*(?=:)/g,'');var ps=s.split(',');for(var i=0;i<ps.length;i++)ps[i]=ps[i].replace(/\\s+/g,' ').trim();return ps.join(',');}
 for(var si=0;si<document.styleSheets.length;si++){
   var sheet=document.styleSheets[si]; var rules=null;
   try{rules=sheet.cssRules;}catch(e){continue;}
   for(var ri=0;ri<rules.length;ri++){var r=rules[ri];
     if(r.selectorText){parsed.push(canonSel(r.selectorText));}
     else if(r.name){parsed.push('@'+r.name);}
     else{parsed.push('@'+((r.conditionText||'at')));}}
 }
 var want=__SELS__;
 var atmap={};parsed.forEach(function(s){if(s.charAt(0)==='@'&&s.indexOf('(')>0){atmap[s.slice(s.indexOf('('))]=1;}});
 want=want.filter(function(s){if(s.charAt(0)==='@'&&s.indexOf('(')>0){return !atmap[s.slice(s.indexOf('('))];}return true;});
 var has={};parsed.forEach(function(s){has[s]=(has[s]||0)+1;});
 var dropped=[];
 want.forEach(function(s){if(has[s]){has[s]--;}else dropped.push(s);});
 var rectOut={};
 if(RECT){RECT.split(',').forEach(function(s){var e=document.querySelector(s.trim());if(e){var b=e.getBoundingClientRect();rectOut[s.trim()]=Math.round(b.top)+'..'+Math.round(b.bottom)+'(h'+Math.round(b.height)+')';}else{rectOut[s.trim()]='MISSING';}});}
 document.title='SMOKE::'+JSON.stringify({views:rows,balance:bal,missing:missing,errors:ERRS,rect:rectOut,dropped:dropped,parsed:parsed,page:(window.__smokeErr||[])});
})();
"""


def main():
    ap = argparse.ArgumentParser(description="单文件 HTML 原型冒烟校验")
    ap.add_argument("html")
    ap.add_argument("--nav", default="go", help="视图导航函数名（默认 go）")
    ap.add_argument("--container", default="", help="内容容器选择器（默认自动探测 .content-area / #pgc / .content）")
    ap.add_argument("--call", action="append", help="追加交互，可多次；值为 JS 表达式串")
    ap.add_argument("--only", default="", help="只跑某一个视图 id")
    ap.add_argument("--rect", default="", help="输出指定选择器的布局矩形，逗号分隔")
    ap.add_argument("--shots", action="store_true", help="顺带逐视图截图到 /tmp/<name>-shots/")
    ap.add_argument("--registry", default="", help="指定视图注册表变量名（默认自动挑选二元组最多者）")
    ap.add_argument("--chrome", default="", help="指定浏览器可执行文件")
    ap.add_argument("--window", default="1500,940", help="截图窗口尺寸")
    ap.add_argument("--timeout", type=int, default=8000, help="虚拟时间预算（毫秒）")
    args = ap.parse_args()

    if not os.path.exists(args.html):
        sys.exit("错误: 文件不存在 -> %s" % args.html)
    chrome = find_chrome(args.chrome)
    if not chrome:
        sys.exit("错误: 未找到可用的无头浏览器。请用 --chrome 指定，或安装 Playwright 缓存。")

    html = open(args.html, encoding="utf-8").read()
    var, pairs = detect_views(html, args.registry)
    if not pairs:
        sys.exit("错误: 未探测到视图注册表（形如 [['id','中文名'],...]）。可用 --only 配合 --rect 做单页布局检查。")

    harness = build_harness(args)
    harness = harness.replace("__VIEWS__", json.dumps(pairs, ensure_ascii=False))
    harness = harness.replace("__SELS__", json.dumps(source_selectors(html), ensure_ascii=False))
    harness = harness.replace("__NAV__", args.nav).replace("__CONT__", args.container)
    harness = harness.replace("__ONLY__", args.only).replace("__RECT__", args.rect)
    harness = harness.replace("__CALLS__", "".join(
        " T('call%d',function(){%s});" % (i + 1, c) for i, c in enumerate(args.call or [])))

    if "</script>" not in html:
        sys.exit("错误: 未找到内联脚本块，本工具只适用于自包含 HTML。")
    # 自检代码放在**独立的脚本块**里，并在主脚本之前挂一个错误捕获器。
    # 原因：主脚本一旦整块中断（例如注册表声明顺序写反），同一块里的自检代码
    # 也不会执行，结果是「取不回自检结果」，看不到真正原因。
    patched = html.replace("</script>", "\n</script>\n<script>\n" + harness + "\n</script>", 1)
    patched = patched.replace(
        "<script>",
        '<script>window.__smokeErr=[];window.addEventListener("error",function(e){'
        'window.__smokeErr.push(String((e&&e.message)||e));},true);</script>\n<script>',
        1)

    tmp = os.path.join(tempfile.gettempdir(), "smoke-" + os.path.basename(args.html))
    open(tmp, "w", encoding="utf-8").write(patched)

    proc = _browser.run("file://" + tmp, chrome=chrome, budget=args.timeout)
    m = re.search(r"<title>SMOKE::(.*?)</title>", proc.stdout, re.S)
    if not m:
        sys.exit("错误: 未取回自检结果（页面脚本可能整块中断，或产物不是自包含页面）。"
                 "原始输出前 400 字：\n%s" % (proc.stdout or proc.stderr)[:400])

    data = json.loads(m.group(1).replace("&quot;", '"').replace("&amp;", "&"))
    print("文件: %s" % args.html)
    print("视图: %d 项（注册表变量 %s）" % (len(pairs), var or "未命名"))
    print()
    print("逐视图内容长度：")
    for row in data["views"]:
        print("   %s" % row)
    if data.get("rect"):
        print("\n布局矩形：")
        for k, v in data["rect"].items():
            print("   %-22s %s" % (k, v))
    bad_bal = [b for b in data.get("balance", []) if not b.endswith(":0")]
    if bad_bal:
        print("\n[标签不配平 %d] 差值非 0 —— 底部栏/弹窗可能被吞进内容区" % len(bad_bal))
        for b in bad_bal:
            print("   %s" % b)
    page_errs = data.get("page") or []
    if page_errs:
        print("\n[运行时异常 %d] 页面脚本自身抛错（这才是根因，先修这里）" % len(page_errs))
        for e in page_errs[:8]:
            print("   %s" % e)
    dropped = data.get("dropped") or []
    if dropped:
        print("\n[样式未生效 %d] 源码选择器在浏览器中被丢弃（通常是被前一条非法选择器带崩）" % len(dropped))
        for d in dropped[:12]:
            print("   %s" % d)
        print("   提示：检查该规则前一条选择器/注释附近是否有多余的 . 或未配平的括号")
    if data["missing"]:
        print("\n[渲染中断 %d] 内容为空或抛错" % len(data["missing"]))
        for x in data["missing"]:
            print("   %s" % x)
    if data["errors"]:
        print("\n[运行时报错 %d]" % len(data["errors"]))
        for e in data["errors"]:
            print("   %s" % e)

    if args.shots:
        outdir = "/tmp/%s-shots" % os.path.splitext(os.path.basename(args.html))[0]
        os.makedirs(outdir, exist_ok=True)
        for vid, _name in pairs:
            if args.only and vid != args.only:
                continue
            shot = os.path.join(outdir, vid + ".png")
            p2 = patched.replace("</script>", "\nsetTimeout(function(){%s('%s');},80);\n</script>" % (args.nav, vid), 1)
            t2 = os.path.join(tempfile.gettempdir(), "shot-%s-%s" % (vid, os.path.basename(args.html)))
            open(t2, "w", encoding="utf-8").write(p2)
            _browser.shoot("file://" + t2, shot, window=args.window, chrome=chrome)
        print("\n截图输出目录: %s" % outdir)

    fail = (bool(data["missing"]) or bool(data["errors"]) or bool(bad_bal)
            or bool(data.get("dropped")) or bool(data.get("page")))
    print()
    print("结果: %s" % ("存在阻断问题 —— 修复后重跑" if fail else "通过（各视图均有内容、无报错、标签配平、样式全部生效）"))
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
