#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交付物自检（prototype-restore / Step 8）

检查项:
  1. 自包含    —— 是否存在外链 src/href（原型必须单文件、无外部依赖）
  2. JS 语法   —— 每个内联 <script> 块用 node --check 校验
  3. 占位禁词  —— demo / 示例 / 字段1 / lorem / TODO / FIXME 等
  4. 技术泄漏  —— 面向用户的文案中出现 接口 / 数据库 / 路由 / API 等技术痕迹
  5. emoji 点  —— 按字符归并列出现位置，供人工按 Step 7 裁决规则确认（不作为错误）

扫描对象严格限定为"产品可见文案"：
  · 脚本区（<script>）—— 只扫字符串字面量，JS 语句与 DOM 句柄不参与
  · 标记区（HTML）    —— 只扫标签之外的文本节点，属性不参与
样式区与各类注释整段排除。因此原型用 JS 渲染不影响检出，
而 CSS 类名里的 bar、属性里的 id="demo"、变量名 getBar 都不会误报。

用法:
    python3 selfcheck.py <文件> [<文件> ...]
    python3 selfcheck.py <文件> --source <实现源码目录>

--source 的作用（强烈建议带上）:
    禁词命中时，回到实现源码里反查该词是否真实存在。若存在，说明它是被还原的
    真实业务文案，**不得为了过检而改写**，应在《界面与业务特征盘点》的差异项中
    登记冲突并保留原文。避免"用改名换过检"造成的信息损失。

退出码:
    0 = 无阻断问题（-h 也是 0）; 1 = 存在 ERROR; 2 = 未给出文件

适用范围：只用于**产品交付物**。对方法论 / 技能文档、设计说明、技术方案等非交付物
运行，命中是必然的且属正常——那类文档需要点名规则与被禁止的词（引用的反例会被算作
命中），不应据此判定其有问题。
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import tempfile

# ---------- 预处理：把非文案区整段抹掉，但保留行号 ----------

BLANK_PATTERNS = [
    re.compile(r"<style\b.*?</style\s*>", re.S | re.I),   # 样式区
    re.compile(r"<!--.*?-->", re.S),                       # HTML 注释
    re.compile(r"/\*.*?\*/", re.S),                        # 块注释（CSS / JS 通用）
]
LINE_COMMENT = re.compile(r"(?<!:)//[^\n]*")               # 行注释，放行 https://

# ---------- 提取工具 ----------

STRING_RE = re.compile(r"""'((?:[^'\\\n]|\\.)*)'|"((?:[^"\\\n]|\\.)*)"|`((?:[^`\\\n]|\\.)*)`""")
TAG_RE = re.compile(r"<[^>]+>")
ATTR_RE = re.compile(r"""\b(?:src|href)\s*=\s*["']([^"']*)["']""", re.I)
SCRIPT_RE = re.compile(r"<script\b(?![^>]*\bsrc=)[^>]*>(.*?)</script>", re.S | re.I)
SCRIPT_OPEN_RE = re.compile(r"<script\b(?![^>]*\bsrc=)", re.I)
SCRIPT_CLOSE_RE = re.compile(r"</script\s*>", re.I)
ALLOWED_REF = ("#", "javascript:", "data:", "mailto:", "tel:", "blob:", "about:")

# 不含变体选择符 U+FE0F —— 它是 emoji 的修饰位，单独统计只会产生噪音
EMOJI_RE = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿←-⇿]")

PARTIAL_TAG_RE = re.compile(r"<[^>]*$")                    # 被字符串拼接截断的标签片段
ATTR_PAIR_RE = re.compile(r"""\b[\w:-]+\s*=\s*("[^"]*"|'[^']*')""")   # 属性键值对

# ---------- 规则表 ----------

def _latin(word):
    """ASCII 专属词边界：bar-slot / getBar 不算命中，中文相邻（如 套餐demo）仍算命中。"""
    return r"(?<![A-Za-z0-9_-])%s(?![A-Za-z0-9_-])" % word


PLACEHOLDER_ERROR = [
    _latin("TODO"), _latin("FIXME"), _latin("demo"), _latin("Demo"), _latin("DEMO"),
    r"示例", r"字段1", r"字段一", _latin("test1"), r"测试数据",
    r"lorem", r"ipsum", _latin("foo"), _latin("bar"), _latin("baz"), _latin("xx+"),
]

TECH_ERROR = [
    r"接口", r"后端", r"前端", r"数据库", r"路由", r"组件", r"变量名",
    r"函数", r"表结构", r"主键", r"外键", r"服务端", r"代码", r"编译",
    r"\bAPI\b", r"\bapi\b", r"/api/", r"\btoken\b", r"\bToken\b", r"\bJWT\b",
    r"\bEntity\b", r"\bModel\b", r"\bSQL\b", r"\bwx\.",
    r"\.js\b", r"\.wxml\b", r"\.vue\b", r"\.jsx\b", r"\.json\b", r"\.java\b",
    r"\bsrc/", r"\bHTTP\b", r"\bGET\b", r"\bPOST\b",
]

TECH_WARN = [r"字段", r"测试", r"参数", r"配置", r"\bprops\b", r"\bstate\b"]

PLACEHOLDER_RE = [(p, re.compile(p)) for p in PLACEHOLDER_ERROR]
TECH_ERROR_RE = [(p, re.compile(p)) for p in TECH_ERROR]
TECH_WARN_RE = [(p, re.compile(p)) for p in TECH_WARN]

MAX_LINES_PER_GROUP = 12
MAX_EMOJI_LINES = 10

# ---------- 源码反查（--source） ----------
SOURCE_TEXT = ""
SRC_EXTS = (".wxml", ".wxss", ".js", ".jsx", ".ts", ".tsx", ".vue", ".html", ".htm",
            ".json", ".css", ".scss", ".less", ".java", ".xml", ".yml", ".yaml", ".md",
            ".sql")  # 种子数据与迁移脚本常落在 .sql，是 Step 3 取证的第一来源，反查必须覆盖
SRC_SKIP_DIRS = {"node_modules", ".git", "dist", "build", "unpackage", "miniprogram_npm", ".idea"}
SRC_MAX_BYTES = 60 * 1024 * 1024


def load_source(path, append=False):
    """把实现源码读成一段文本，用于禁词命中的反查。

    append=True 时把新目录的文本追加到已有内容之后 —— `--source` 可多次传入，
    多端工程需要同时覆盖前端与后端，否则会造出一片假「源码里没有」。
    """
    global SOURCE_TEXT
    if not path:
        return 0
    chunks = [SOURCE_TEXT] if append else []
    total = 0
    if os.path.isfile(path):
        try:
            chunks.append(open(path, encoding="utf-8", errors="replace").read())
        except OSError:
            return 0
        SOURCE_TEXT = "\n".join(chunks)
        return 1
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in SRC_SKIP_DIRS]
        for name in files:
            if not name.lower().endswith(SRC_EXTS):
                continue
            fp = os.path.join(root, name)
            try:
                if os.path.getsize(fp) > 4 * 1024 * 1024:
                    continue
                chunks.append(open(fp, encoding="utf-8", errors="replace").read())
                total += 1
            except OSError:
                continue
            if total > 20000:
                break
    SOURCE_TEXT = "\n".join(chunks)
    if len(SOURCE_TEXT) > SRC_MAX_BYTES:
        SOURCE_TEXT = SOURCE_TEXT[:SRC_MAX_BYTES]
    return total


def in_source(label, cand=""):
    """禁词是否**带着上下文**出现在源码里（决定按 C1 判 WARN 还是 ERROR）。

    只比对裸词会大面积误判：源码里的说明文档、注释里几乎必然出现「接口 / 组件 / 路由」，
    于是任何自拟文案都能被判成「真实文案」，门禁直接失效。
    所以取命中处前后各 6 个字符组成片段再查 —— 片段命中才说明这处话术真的是从代码里来的。
    """
    if not SOURCE_TEXT:
        return False
    token = label.strip("^$").replace("\\b", "").replace("\\", "")
    token = re.sub(r"[()\[\]?+*|]", "", token).strip()
    if len(token) < 2:
        return False
    if not cand:
        return False
    # 脚本里的字符串字面量常带 \" 之类的转义，去掉后再比对，否则永远对不上源码
    raw = re.sub(r"\\(.)", r"\1", cand)
    # 相邻文案被拼在一起时（表格里两个单元格、模板字符串拼接），整窗永远对不上源码，
    # 因此再退一步只取单侧上下文：只要有一侧能带着相邻文字在源码里命中，就说明这处话术有出处。
    flat = CONTENT_ONLY_RE.sub("", raw)
    for text_ in (raw, flat):
        i = text_.find(token)
        if i < 0:
            continue
        cands = [text_[max(0, i - 6): i + len(token) + 6]]
        cands.append(_ctx(text_[:i], 4, True) + token)
        cands.append(token + _ctx(text_[i + len(token):], 4, False))
        for w in cands:
            if len(w) >= len(token) + 2 and re.search(re.escape(w), SOURCE_TEXT):
                return True
    return False


def _ctx(s, n, from_left):
    """取一侧的连续内容字符（跳过标点与标签碎片），不足 2 个则返回空。"""
    chars = [c for c in (s if from_left else s) if CONTENT_ONLY_RE.sub("", c)]
    if from_left:
        chars = chars[-n:]
    else:
        chars = chars[:n]
    return "".join(chars) if len(chars) >= 2 else ""


def source_hint(label):
    """禁词命中后回到源码反查，给出「是否为真实文案」的提示后缀。"""
    if not SOURCE_TEXT:
        return ""
    token = label.strip("^$").replace("\\b", "").replace("\\", "")
    token = re.sub(r"[()\[\]?+*|]", "", token).strip()
    if len(token) < 2:
        return ""
    if re.search(re.escape(token), SOURCE_TEXT):
        return "（源码中确实存在该词，属被还原的真实文案：保留原文并在盘点文档登记冲突）"
    return "（源码中未出现该词，属自拟文案：请替换为真实业务表达）"


def preprocess(text):
    """抹掉样式区与各类注释，保留行号，供文案扫描使用。"""
    for pat in BLANK_PATTERNS:
        text = pat.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    return LINE_COMMENT.sub(" ", text)


def strip_tags(text):
    return TAG_RE.sub(" ", text)


def strip_markup_noise(text):
    """去掉标签、被拼接截断的半截标签、以及属性键值对，只留面向用户的文本。"""
    return ATTR_PAIR_RE.sub(" ", PARTIAL_TAG_RE.sub(" ", strip_tags(text)))


# 只保留「内容字符」：数字、字母、汉字。标点与标签碎片不参与上下文比对
CONTENT_ONLY_RE = re.compile(r"[^0-9A-Za-z\u4e00-\u9fff]+")

# 不可执行脚本块（注解 / 数据载体）：type 不是 JS 的都算
NON_EXEC_TYPE_RE = re.compile(r"""\btype\s*=\s*["']([^"']+)["']""", re.I)
EXEC_TYPES = ("text/javascript", "application/javascript", "module", "text/ecmascript",
              "application/ecmascript", "text/babel", "text/jsx")


def is_exec_script_tag(tag):
    m = NON_EXEC_TYPE_RE.search(tag)
    return True if not m else m.group(1).strip().lower() in EXEC_TYPES


def non_exec_lines(text):
    """返回不可执行脚本块覆盖的行号集合 —— 这些块是注解与数据载体，不参与任何扫描。"""
    out = set()
    for m in re.finditer(r"<script\b(?![^>]*\bsrc=)([^>]*)>(.*?)</script\s*>", text, re.S | re.I):
        if is_exec_script_tag(m.group(1)):
            continue
        a = text.count("\n", 0, m.start()) + 1
        b = text.count("\n", 0, m.end()) + 1
        out.update(range(a, b + 1))
    return out


def build_line_kinds(text):
    """逐行标记 script / markup，决定该行扫字符串还是扫文本节点。"""
    kinds = []
    in_script = False
    for line in text.splitlines():
        opens = bool(SCRIPT_OPEN_RE.search(line))
        closes = bool(SCRIPT_CLOSE_RE.search(line))
        if in_script:
            kinds.append("script")
            if closes:
                in_script = False
        elif opens:
            kinds.append("script")
            if not closes:
                in_script = True
        else:
            kinds.append("markup")
    return kinds


def candidates_for(line, kind):
    """一行里的"面向用户的文案"。"""
    if kind == "script":
        out = []
        for groups in STRING_RE.findall(line):
            for g in groups:
                if g and g.strip():
                    out.append(strip_markup_noise(g))
        return out
    return [strip_markup_noise(line)]


def labels_for(line, rules):
    """返回该行命中的规则标签（同一行内去重）。"""
    found = set()
    for label, rx in rules:
        if rx.search(line):
            found.add(label)
    return found


def check_external(all_lines):
    hits = []
    for no, line in enumerate(all_lines, 1):
        for ref in ATTR_RE.findall(line):
            ref = ref.strip()
            if not ref or ref.lower().startswith(ALLOWED_REF):
                continue
            hits.append((no, line.strip()[:110]))
            break
    return hits


def check_js_syntax(text):
    """返回 (状态, 说明)，状态 ∈ {ok, fail, skip}"""
    blocks = SCRIPT_RE.findall(text)
    if not blocks:
        return "ok", "无内联脚本"
    node = None
    for cand in ("node", "nodejs"):
        try:
            subprocess.run([cand, "--version"], capture_output=True, check=True)
            node = cand
            break
        except (OSError, subprocess.CalledProcessError):
            continue
    if node is None:
        return "skip", "未找到 node，已跳过 %d 个脚本块的语法校验" % len(blocks)

    exec_blocks = [m.group(2) for m in
                   re.finditer(r"<script\b(?![^>]*\bsrc=)([^>]*)>(.*?)</script\s*>", text, re.S | re.I)
                   if is_exec_script_tag(m.group(1))]
    for idx, code in enumerate(exec_blocks, 1):
        fd, tmp = tempfile.mkstemp(suffix=".js")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(code)
            proc = subprocess.run([node, "--check", tmp], capture_output=True, text=True)
            if proc.returncode != 0:
                msg = (proc.stderr or "").strip().splitlines()
                return "fail", "第 %d 个脚本块语法错误: %s" % (idx, msg[-1] if msg else "未知")
        finally:
            os.unlink(tmp)
    return "ok", "%d 个可执行脚本块语法通过" % len(exec_blocks)


def report(title, hits, level):
    if not hits:
        return 0
    print("[%s] %s: %d 处" % (level, title, len(hits)))
    for no, snippet in hits[:MAX_LINES_PER_GROUP]:
        print("   %s: %s" % (no, snippet))
    if len(hits) > MAX_LINES_PER_GROUP:
        print("   … 其余 %d 处" % (len(hits) - MAX_LINES_PER_GROUP))
    print()
    return len(hits)


def check_html(path, text):
    raw_lines = text.splitlines()
    scan_lines = preprocess(text).splitlines()
    kinds = build_line_kinds(text)
    errors = warnings = 0

    errors += report("自包含（发现外链，原型必须单文件）", check_external(raw_lines), "ERROR")

    status, detail = check_js_syntax(text)
    if status == "fail":
        print("[ERROR] JS 语法: %s\n" % detail)
        errors += 1
    elif status == "skip":
        print("[WARN ] JS 语法: %s\n" % detail)
        warnings += 1
    else:
        print("[ OK  ] JS 语法: %s\n" % detail)

    ph, tech, warn, real = [], [], [], []
    emoji_stat = {}          # emoji 字符 -> [次数, 首次行号]
    emoji_order = []
    skip = non_exec_lines(text)   # 注解与数据载体块：不参与扫描
    for no, line in enumerate(scan_lines, 1):
        if no in skip:
            continue
        kind = kinds[no - 1] if no - 1 < len(kinds) else "markup"
        snippet = line.strip()[:110]
        hit_ph, hit_tech, hit_warn = {}, {}, set()
        for cand in candidates_for(line, kind):
            if not cand.strip():
                continue
            for lb in labels_for(cand, PLACEHOLDER_RE):
                hit_ph[lb] = cand
            for lb in labels_for(cand, TECH_ERROR_RE):
                hit_tech[lb] = cand
            hit_warn |= labels_for(cand, TECH_WARN_RE)
        # C1：带着上下文确实来自源码的词属被还原的真实文案，保留原文 + 登记冲突，不判 ERROR
        for label in sorted(hit_ph):
            (real if in_source(label, hit_ph[label]) else ph).append(
                (no, "%s  ← 命中 %s%s" % (snippet, label, source_hint(label))))
        for label in sorted(hit_tech):
            (real if in_source(label, hit_tech[label]) else tech).append(
                (no, "%s  ← 命中 %s%s" % (snippet, label, source_hint(label))))
        for label in sorted(hit_warn):
            warn.append((no, "%s  ← 命中 %s" % (snippet, label)))
        for ch in EMOJI_RE.findall(line):
            if ch not in emoji_stat:
                emoji_stat[ch] = [0, no]
                emoji_order.append(ch)
            emoji_stat[ch][0] += 1

    errors += report("占位禁词（必须替换为真实业务文案）", ph, "ERROR")
    errors += report("技术名词泄漏（面向用户的文案不得出现）", tech, "ERROR")
    warnings += report("疑似技术名词（人工确认）", warn, "WARN ")
    warnings += report("禁词命中但源码中确有该词（保留原文，须在盘点文档登记冲突）", real, "WARN ")

    if emoji_stat:
        total = sum(v[0] for v in emoji_stat.values())
        print("[INFO ] emoji 使用点: 共 %d 处, %d 个不同字符 —— 逐个人工裁决"
              % (total, len(emoji_stat)))
        print("        规则：实现本身使用的 emoji 保留；顶替了已有资产的替换；")
        print("              仅见于设计文档等非生效来源的不得还原。")
        for ch in emoji_order[:MAX_EMOJI_LINES]:
            cnt, first = emoji_stat[ch]
            print("   %s  ×%-3d 首次出现于第 %d 行" % (ch, cnt, first))
        if len(emoji_order) > MAX_EMOJI_LINES:
            print("   … 其余 %d 个字符" % (len(emoji_order) - MAX_EMOJI_LINES))
        print()

    return errors, warnings


def check_text(path, lines):
    """Markdown 等文字交付物：直接按行扫描。"""
    ph, tech, warn = [], [], []
    for no, line in enumerate(lines, 1):
        snippet = line.strip()[:110]
        if not snippet:
            continue
        for label in sorted(labels_for(line, PLACEHOLDER_RE)):
            ph.append((no, "%s  ← 命中 %s" % (snippet, label)))
        for label in sorted(labels_for(line, TECH_ERROR_RE)):
            tech.append((no, "%s  ← 命中 %s" % (snippet, label)))
        for label in sorted(labels_for(line, TECH_WARN_RE)):
            warn.append((no, "%s  ← 命中 %s" % (snippet, label)))
    errors = report("占位禁词", ph, "ERROR")
    errors += report("技术名词泄漏", tech, "ERROR")
    warnings = report("疑似技术名词（人工确认）", warn, "WARN ")
    return errors, warnings


def main():
    args = [a for a in sys.argv[1:]]
    if any(a in ("-h", "--help") for a in args):
        print(__doc__.strip())
        return 0
    sources = []
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--source" and i + 1 < len(args):
            sources.append(args[i + 1])
            i += 2
            continue
        if a.startswith("--source="):
            sources.append(a.split("=", 1)[1])
            i += 1
            continue
        rest.append(a)
        i += 1

    if not rest:
        sys.stderr.write(__doc__.strip() + "\n")
        return 2

    for n, src in enumerate(sources):
        cnt = load_source(src, append=(n > 0))
        print("源码反查已启用: %s（读取 %d 个文件）" % (src, cnt))
    if sources:
        print()

    total_errors = total_warnings = 0
    for path in rest:
        if not os.path.exists(path):
            print("错误: 文件不存在 -> %s\n" % path)
            total_errors += 1
            continue
        text = open(path, encoding="utf-8", errors="replace").read()
        print("=" * 68)
        print("文件: %s" % path)
        print("=" * 68)
        if path.lower().endswith((".html", ".htm")):
            e, w = check_html(path, text)
        else:
            e, w = check_text(path, text.splitlines())
        total_errors += e
        total_warnings += w
        print("小结: ERROR %d 类 / WARN %d 类\n" % (e, w))

    print("=" * 68)
    if total_errors:
        print("结果: 存在 ERROR —— 阻断交付，修复后重跑")
        return 1
    print("结果: 无 ERROR —— 通过（WARN %d 类待人工确认）" % total_warnings)
    return 0


if __name__ == "__main__":
    sys.exit(main())
