---
name: lon-lan-launcher
description: Use when 用户要在同 WiFi 设备间分享静态站点、手机预览原型、投屏演示，或说「让手机能看 / 给同事看 demo / 起个静态服务 / 局域网访问」；即使没明说「局域网」，只要涉及跨设备访问本地 HTML 也应触发
---

# 局域网静态站点启动器

## Overview

为静态站点目录生成跨平台双击启动器（mac `.command` + Windows `.bat`），自动处理防火墙兼容、IP 探测、端口降级三大陷阱。核心原则：用 `python3 -m http.server` 监听 `0.0.0.0`，让同 WiFi 设备通过局域网 IP 访问。

支持原型画布注释与编排保存 API（`--canvas-api` 参数）。启用后启动器调用站点目录里的 `canvas_server.py`（由画布生成步骤放进站点目录），提供 `/api/canvas/probe` / `annotations` / `layout` / `image` 端点，标注、编排与贴图落成站点目录里的文件。画布的贴图能力依赖这个模式——不带 `--canvas-api` 起的站点里，粘贴图片会被画布拦下并提示。

⚠️ **读路径契约**：画布启动时直接静态 GET `pages.json` / `annotations.json` / `layout.json`（不走 API）。改动本启动器或换服务实现时，**必须保证这三个文件能被静态 GET 到**。验证方式：`curl -s http://127.0.0.1:<port>/annotations.json | head -c 100`。

## When to Use

```dot
digraph when_to_use {
    "用户提到跨设备访问?" [shape=diamond];
    "有静态 HTML 目录?" [shape=diamond];
    "Use this skill" [shape=box];
    "Ask for directory" [shape=box];
    "Not this skill" [shape=box];

    "用户提到跨设备访问?" -> "有静态 HTML 目录?" [label="yes"];
    "用户提到跨设备访问?" -> "Not this skill" [label="no"];
    "有静态 HTML 目录?" -> "Use this skill" [label="yes"];
    "有静态 HTML 目录?" -> "Ask for directory" [label="no, but cwd has prototypes/"];
}
```

**Use when:**
- 手机预览原型 / demo
- 投屏到大屏展示
- 同事在自己电脑访问你的本地站点
- 公司内网临时分享 HTML 文档

**Don't use when:**
- 需要外网访问（用 ngrok 等内网穿透）
- 动态后端服务（不是静态 HTML）
- 长期部署（用真正的 web 服务器）

## Core Decisions

### 1. 用 `python3 -m http.server`，不用 node

macOS 应用防火墙默认拦截 node 入站连接——本机 `localhost` 通，但局域网 IP 自连不通。`python3` 是 Xcode 工具链自带，几乎所有 mac 已被授权放行。只有确认环境无 python 时才考虑替代。

### 2. 必须监听 `0.0.0.0`

绑 `127.0.0.1` 的服务外部访问不到（最常见新手错误）。显式指定：

```bash
python3 -m http.server PORT --bind 0.0.0.0
```

### 3. 启动器五要素

| 要素 | 目的 |
|------|------|
| 端口降级 | 7788 → 7789 → 7799 自动尝试 |
| IP 探测 | mac: `ipconfig getifaddr en0/en1` + `ifconfig` 兜底；Windows: `ipconfig` 解析 |
| 双地址打印 | 本机地址 + **局域网地址**（后者是分享用的） |
| 自动打开浏览器 | 启动 1 秒后 `open` 本机入口页 |
| `exec` 前台 | 关终端 = 关服务（避免僵尸进程） |

### 4. 跨平台双脚本

- **mac**: `.command` 文件 + `chmod +x`，双击开终端
- **Windows**: `.bat` 文件，双击启动
- 文件名用中文（`启动{产品名}-局域网.command`）便于识别

### 5. 站点目录必须自包含

`--canvas-api` 模式下启动器按**相对自身位置**引用站点目录里的 `canvas_server.py`（mac `"$DIR/canvas_server.py"`、Windows `"%~dp0canvas_server.py"`）；该文件由画布生成步骤放进站点目录，本 skill 不拷贝、不携带。

站点目录是要拷贝、打包、发给同事的交付物。任何指向 skill 安装目录的路径在别人机器上都不存在——Windows 上尤其致命（mac 风格绝对路径直接报错退出），而本机自测恰好命中该路径，会把问题完全掩盖。判据：启动器里不应出现 `Codex skill directory` 字样。

## Quick Reference

| Phase | 关键动作 | 产物 |
|-------|---------|------|
| 1. 确认入参 | 提取 site_dir / entry / product_name / port | - |
| 2. 中文路径检查 | Codex file search 扫描子目录，发现中文要**询问用户**是否重命名 | - |
| 3. 生成启动器 | 运行 `build_launcher.py` | 两个启动器文件 |
| 4. 自测 | curl 验证本机 + LAN IP 都通；grep 确认无 skill 绝对路径 | - |
| 5. 交付 | 输出用法 + 三大踩坑提醒 | - |

## Implementation

### Phase 1: 确认入参

从用户消息提取：

- **`site_dir`**（必填）：站点根目录绝对路径（如 `/Users/.../prototypes/`）
- **`entry`**（默认 `index.html`）：入口 HTML 相对路径
- **`product_name`**（从目录名推断）：banner 显示名
- **`port`**（默认 7788）：起始端口
- **`canvas_api`**（可选）：是否使用站点目录里的写服务（检测目录下是否有 `canvas_server.py`）

如果路径不明确，用 Codex file search 检查 cwd 有无 `prototypes/` 或 `demo/` 目录，找到就确认；否则询问。

**Canvas API 检测规则：**
- 目录下存在 `canvas_server.py` → 自动启用 `--canvas-api`
- 目录下没有 `canvas_server.py` 但用户提到「原型画布」「注释」「标注」→ 提示先运行画布生成，再起服务
- 其他场景 → 使用纯静态服务器

### Phase 2: 检查中文路径陷阱

用 Codex file search 扫描 `site_dir` 下是否有**中文命名的子目录**。Windows URL 编码差异会导致 iframe 加载失败。

发现中文目录时：

```
Windows 用户访问中文路径会乱码无法加载。
建议把这些目录改英文短名（连带改 index.html / 引用脚本）。

要我顺便处理吗？
```

**不要自作主张重命名**——有 blast radius，需用户确认。

### Phase 3: 运行生成器

用 Codex file search 定位脚本（skill 安装位置因环境而异）：

```bash
pattern: **/lon-lan-launcher/scripts/build_launcher.py
```

运行：

```bash
# 纯静态服务器（默认）
python3 <script_path> <site_dir> [--entry index.html] [--name "产品名"] [--port 7788]

# 带 Canvas 注释保存 API
python3 <script_path> <site_dir> --canvas-api [--entry index.html] [--name "产品名"] [--port 7788] [--annotations-file annotations.json]
```

产物：
- `启动{name}-局域网.command`（mac，已 `chmod +x`）
- `启动{name}-局域网.bat`（Windows）

启用 `--canvas-api` 后：
- 启动器调用 `./canvas_server.py` 而非 `http.server`，按相对自身位置解析；文件不存在时 `build_launcher.py` 报错退出
- 自动提供 `/api/canvas/probe`、`/api/canvas/annotations`、`/api/canvas/layout`、`/api/canvas/image`
- 注释保存到 `<site_dir>/<annotations_file>`（同时写 `.js` 镜像），编排保存到 `<site_dir>/layout.json`，贴图保存到 `<site_dir>/assets/canvas-images/`
- `--annotations-file` 保持默认值 `annotations.json`：画布的读路径是写死的静态 GET `annotations.json`，改成别的文件名会让写路径与读路径分家——保存看着成功，刷新后标注全空
- `/api/canvas/probe` 自报 `features`，画布据此判断能开哪些能力；站点里的写服务版本旧时，重跑一次画布生成即可覆盖

### Phase 4: 自测

后台启动服务，验证两个地址都通：

```bash
# 本机
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:<port>/<entry>

# LAN IP 自连（关键！）
curl -s -o /dev/null -w "%{http_code}\n" http://<LAN_IP>:<port>/<entry>
```

**LAN IP 自连失败 = 防火墙问题**（见故障诊断）。

`--canvas-api` 模式追加四项：

```bash
# 读路径契约（画布启动时静态 GET，不走 API）
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:<port>/annotations.json
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:<port>/layout.json
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:<port>/pages.json
# API 可用性
curl -s -X POST -o /dev/null -w "%{http_code}\n" http://127.0.0.1:<port>/api/canvas/probe
```

可移植性判据（不需要起服务）：

```bash
grep -c "\Codex skill directory" <site_dir>/启动*.command <site_dir>/启动*.bat   # 必须为 0
```

写入类自测（PUT annotations/layout）会**覆盖真实标注与编排文件**。要验证就先把站点目录拷到 `/tmp` 下操作，别对着真仓库 PUT。

测完 `kill` 自测进程。

### Phase 5: 交付提示

输出必须包含三大踩坑提醒（按优先级排序）：

1. **演示期间不要关黑色终端窗口**：关窗口 = 服务退出。自动弹出的浏览器只是"启动成功"信号，不是"可以收工"信号。
2. **公司 WiFi 常开客户端隔离**：同 WiFi 也互相不通，需换家里热点。
3. **别人打不开但本机能开**：先在自己 mac 用 LAN IP 浏览器自测，不通是防火墙。

## Common Mistakes

| 错误做法 | 为什么错 | 正确做法 |
|---------|---------|---------|
| 用 `node` + `http-server` / `npx serve` | 触发 mac 防火墙拦截 | `python3 -m http.server` |
| 不带 `--bind 0.0.0.0` | 默认行为有版本差异 | 显式指定 |
| `--bind 127.0.0.1` | 只本机能访问 | `0.0.0.0` |
| 打印的局域网地址写 `localhost` | 用户拷错地址发给同事 | 必须用真实 LAN IP |
| 后台运行（`&`）让用户 kill PID | 违反"关终端=关服务"直觉 | 用 `exec` 前台运行 |
| 启动器按绝对路径引用 `canvas_server.py` | 站点目录拷给别人就跑不起来，Windows 必崩，本机自测却全绿 | 站点目录里保留画布生成放进来的副本，用 `$DIR` / `%~dp0` 引用 |
| 对真仓库 PUT 测写入 API | 覆盖同事的真实标注 | 拷到 `/tmp` 下测 |

## Troubleshooting

用户说"打不开"时，两步快速分诊：

### Step 1: 服务是否还在运行（80% 的情况）

```bash
lsof -nP -iTCP:7788 -iTCP:7789 -iTCP:7799 -sTCP:LISTEN
```

无输出 → 用户关了终端窗口，让其重新双击启动器并强调演示完前别关。

### Step 2: 本机用 LAN IP 自连

```bash
curl -s -o /dev/null -w "%{http_code}\n" http://<LAN_IP>:<PORT>/
```

- 返回 200 → 对方网络问题（多半 WiFi 客户端隔离）
- 返回 000/超时 → 本机防火墙拦截

**REQUIRED:** 完整诊断流程（防火墙选项、Windows 特有问题、端口占用）见 `references/troubleshooting.md`。

## References

- 生成器脚本：`scripts/build_launcher.py`
- 故障诊断手册：`references/troubleshooting.md`
