# HTML 线框图规范（首版方案选型用）

本文档定义 `lon-page-design` 执行 3 版黑白 HTML 线框图选型的全部规则。「页面首次新建」必走 3 版选型；迭代更新既有页由用户选增量更新（在选定版上增量改单版，沿用本文灰阶 / 占位 / 技术约束）或页面重构（按最新需求重走本文完整 3 版选型流程），见 `references/iterate-existing-mode.md`。

---

## 触发条件

| 条件 | 行为 |
|---|---|
| 目标 `pages/{XX}-{页面名}.md` 文件**不存在** | 走 3 版线框选型 |
| 目标文件**已存在** | 迭代模式：用户选增量改单版 / 重构重做 3 版（见 `references/iterate-existing-mode.md`）；Phase 5S 入口页改动只落元素详单 + 跳转表，不碰线框 |

判定时机：Phase 3 / 3S 进入每页前 Codex terminal `ls` 检查。

---

## 差异化维度表

每页 3 版必须在 1-2 个维度上产生**真正可视化的差异**。主 Agent 在 Step 2 出图前必须告知用户「本页 3 版围绕 [X] / [Y] 两个维度发散」，让用户可校验。

| 维度 | A 极端 | B 中庸 | C 极端 |
|---|---|---|---|
| 信息密度 | 紧凑塞满，行高小、间距小 | 合理留白，主次区分 | 大留白，单元素聚焦 |
| 布局结构 | 单列垂直流（列表/feed） | 卡片网格 2-3 列 | 横滑模块 + 纵向堆叠混合 |
| 首屏重点 | 核心数据置顶（数字大字号） | 操作 CTA 置顶（fold 上方） | 状态摘要卡片置顶 |
| 操作入口位置 | 顶部右侧 icon | 底部 fixed 全宽按钮 | 行内挂在每条数据上 |
| 异常态可见性 | 首屏显式占位（即使无数据保留区块） | 折叠展开（次要异常折起来） | 异常进二级页（首屏只显示正常态） |
| 导航/筛选模式 | 顶部 Tab | 分段控件 Segment | 横滑芯片 Chip |
| 页面分段（中台特有） | 单页全展示长滚动 | 上下分块卡片堆叠 | 左锚点 + 右分区滚动 |
| 状态展示策略 | 图标 + 颜色块 | 文字标签 + 弱色 | 状态分组重排（同状态聚合） |

### 维度选型建议

| 页面类型 | 推荐维度组合 |
|---|---|
| 列表页 | 布局结构 + 信息密度 |
| 表单页 | 步骤组织（按维度表"页面分段"映射） + 操作入口位置 |
| 详情页 | 首屏重点 + 异常态可见性 |
| 首页/工作台 | 布局结构 + 首屏重点 |
| 设置页 | 导航/筛选模式 + 信息密度 |
| 数据看板（中台） | 页面分段 + 状态展示策略 |

### 与移动端 IA 的对接（仅 APP）

APP 页在 Step 1.5 已由 `mobile-ia.md` 推出 LATCH 主维度，按下表反查 3 版应发散的维度，与上方「页面类型」表二选一即可（LATCH 维度更贴内容本质时优先用本表）：

| LATCH 主维度 | 推荐发散维度组合 |
|---|---|
| 时间（Time，Feed） | 布局结构 + 信息密度 |
| 类别（Category，Tab/Nav） | 导航/筛选模式 + 首屏重点 |
| 层级（Hierarchy，钻取） | 首屏重点 + 异常态可见性 |
| 位置（Location，地图） | 布局结构 + 操作入口位置 |
| 字母/索引（Alphabet，搜索） | 操作入口位置 + 信息密度 |

内容优先级金字塔的「首屏」内容直接锚定「首屏重点」维度的取值——首屏放数据则数据置顶、首屏放操作则 CTA 置顶。

### 伪差异红线

以下情况判定为「伪 3 版」，必须重做：

- 三版同布局只改文案 ✗
- 三版只换图标位置 ✗
- 三版只换标题措辞 ✗
- 三版只字号变化 ✗
- 三版只换 chrome（状态栏 / 导航栏外观） ✗

自检方法：compare.html 顶部的差异表（见下文 E 节），三行写出来三列若内容一样，伪差异立刻暴露。

---

## 黑白线框 HTML 技术规范

### 画布

| 模式 | 宽度 | 起手骨架 |
|---|---|---|
| APP | `max-width: 375px` 居中 | `wireframe-template.html` 的 APP 变体 |
| 中台 | `min-width: 1440px` | `wireframe-template.html` 的中台变体 |

### 灰阶 Token（仅 5 级）

```css
:root {
  --w-bg: #FFFFFF;       /* 主背景 */
  --w-surface: #F5F5F5;  /* 卡片/区块背景 */
  --w-border: #D4D4D4;   /* 描边/分隔 */
  --w-text-2: #737373;   /* 次要文字 */
  --w-text-1: #171717;   /* 主文字 */
}
```

**禁止**引入任何彩色 / 品牌色 / design.md Token。

### 占位规则

| 元素 | 规则 |
|---|---|
| 图片 | 45° 斜线条纹 `background: repeating-linear-gradient(45deg, #E5E5E5 0 8px, #F5F5F5 8px 16px)` + 居中文字「图」 |
| 主按钮 | `border: 1px solid var(--w-text-1); background: transparent;`（纯描边） |
| 次按钮 | `background: var(--w-surface); border: 1px solid var(--w-border);` |
| 文字 | **用真实示例填充**（「订单已支付」「待发货 3 件」），禁「内容1」「占位标题」「Lorem」 |
| 图标 | Unicode 几何字符 `▢ △ ○ ≡ ✕ ✓ ←` 或单线 SVG 描边图标，禁引 Lucide / FontAwesome / Iconify |

### 字体

```css
font-family: system-ui, -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
```

禁止任何 webfont、品牌字、Google Fonts。

### 交互

- 零 JS / 零 hover / 零 active
- 纯静态 HTML：`<html><head><style>...</style></head><body>...</body></html>` 自包含
- 不引入任何外部 CSS / JS 资源

### chrome 预置

| 模式 | 必备 chrome |
|---|---|
| APP | 44px 状态栏 + 44px 导航栏（顶部，灰底）；底部如有 Tab 栏 49px |
| 中台 | 220px 侧边栏 + 48px 顶栏（灰底） |

chrome 保留是为了让 compare 页能看到完整的页面外框。

### 结构性约束（APP）

黑白线框层也须遵守以下结构指标（属尺寸/布局约束，非视觉 Token，不违反「禁碰 design.md Token」）：

- 可点击元素最小高度 ≥ 44px（与下游 design.md §6.0 同口径）
- 相邻可点击元素间距 ≥ 8px
- 默认单列；双列仅在对比型内容时允许，须在 compare 差异表中写明理由（判定见 `mobile-ia.md` B 节）

### 大小约束

- 单页 HTML（含 inline CSS）< 30 KB
- 单页 + compare 总 < 150 KB
- 超出说明在堆视觉细节，违反线框图本质，必须删

---

## compare.html 形态

### APP 模式

3 iframe 横排，外层 `transform: scale(0.75); transform-origin: top center;` 缩到 ~280px 宽，1440px 屏同屏可见三版。

```html
<section class="compare-grid">
  <article>
    <h3>v1 · 紧凑列表 + 顶部操作</h3>
    <iframe src="v1.html"></iframe>
  </article>
  <article>
    <h3>v2 · 卡片网格 + 底 fixed</h3>
    <iframe src="v2.html"></iframe>
  </article>
  <article>
    <h3>v3 · 横滑模块 + 行内</h3>
    <iframe src="v3.html"></iframe>
  </article>
</section>
```

### 中台模式

3 iframe 纵向堆叠（每段 600px 可滚动）+ 顶部锚点跳转（`<a href="#v1">v1</a> <a href="#v2">v2</a> <a href="#v3">v3</a>`）。

### 顶部差异表（必有）

compare.html 必须在 iframe 之前展示差异表，让用户不点开 iframe 就能看出区别：

```markdown
| 维度 | v1 | v2 | v3 |
|---|---|---|---|
| 布局结构 | 单列列表 | 卡片网格 | 横滑模块 |
| 操作入口 | 顶部右侧 icon | 底部 fixed 按钮 | 行内挂在每条 |
| 首屏重点 | 数据置顶 | CTA 置顶 | 状态摘要置顶 |
```

差异表写到 HTML `<table>` 形态，灰阶配色与 iframe 内容一致。

### 主动拉起浏览器

compare.html 写盘后、Codex confirmation 之前，主 Agent **立即** Codex terminal 执行 `open {compare.html 路径}` 自动拉起浏览器，不让用户手动找路径。选 D 重画的 `v-final.html`、跳过分支的单版 `v-only.html` 同理，生成后立即 `open` 对应文件。

### 回流信号

唯一稳定信道 = 主 Agent 在 Step 2 末尾的 Codex confirmation 选项点击（A/B/C/D）。compare.html **不带选择按钮**，纯展示用。用户口述「我选 v2」也接受，但必须由主 Agent 用 Codex confirmation 二次确认才能进 Step 3。

---

## Codex confirmation 4 选 1 模板

主 Agent 在 Step 2 出完 3 版 + compare 并 `open` 拉起浏览器后调用：

```
question: 本页 3 版线框已就绪，请开 compare.html 对比后选型。
options:
  A. 选 v1：{方向命名 A，如「紧凑列表 + 顶部操作」}
  B. 选 v2：{方向命名 B，如「卡片网格 + 底 fixed 操作」}
  C. 选 v3：{方向命名 C，如「横滑模块 + 行内操作」}
  D. 综合多版（请在 Other 描述，如「v1 的布局 + v2 的操作位 + v3 的异常态」）
```

每个选项的「方向命名」由主 Agent 基于实际差异化维度组合生成，**不能用占位符**。

### 选 D 综合分支

用户选 D 时，主 Agent 解析 Other 描述，重画 `v-final.html`，路径同目录，**立即** `open v-final.html` 拉起浏览器。然后调用二选一确认：

```
question: 综合方案 v-final 已就绪（{综合描述}），是否确认？
options:
  A. 确认 v-final，进入写入 PRD
  B. 还需要调整（请在 Other 描述）
```

选 B 进入调整循环（重画 → 再确认）直到选 A。

---

## 落 page PRD 线框图字段映射

选定后，主 Agent 在写入 page PRD 时填充第 4 章「线框图（首版选定）」字段：

| 字段 | 取值规则 |
|---|---|
| 选定版本 | `v{N}（{方向命名}）`，如 `v2（卡片网格 + 底 fixed 操作）`；综合方案填 `v-final（综合 v1 布局 + v2 操作位）` |
| HTML 路径 | 相对路径，从 page PRD 文件位置算起：`../../wireframes/{XX}-{页面名}/v{N}.html` |
| 差异化维度 | 本页 3 版围绕的 1-2 个维度名称，与 Step 2 开头告知用户的一致 |
| 选型理由 | 用户原话（若有）或主 Agent 总结，1-2 句话，避免空话 |
| 3 版备份 | `../../wireframes/{XX}-{页面名}/compare.html` |

---

## 跳过 3 版的判断

主 Agent 在 Step 2 前自动识别可跳过场景，提议跳过 → Codex confirmation 二选一（确认跳过 / 仍要 3 版）：

| 跳过场景 | 例子 |
|---|---|
| 纯展示页（无交互/表单/决策） | 协议页、关于我们、版权说明 |
| 单元素页 | Loading 页、纯 Toast 占位页 |
| 与已确认页强同构 | 第 5 个详情页（前 4 个已用同模板） |

### 进入 3 版的硬条件

满足以下任一即必须走 3 版（不允许跳过）：

- 页面包含表单、决策、列表、操作组
- 异常态超过 1 种
- 模块数 ≥ 3

### 跳过后的输出

跳过时主 Agent 出单版 `v-only.html`（不画 compare）后 `open v-only.html` 拉起浏览器，线框图「选定版本」字段填 `单版定稿（XX 跳过 3 版发散）`，XX 为跳过原因（纯展示页 / 单元素页 / 与 0X-页面名 同构）。

---

## 与其他规范的关系

| 规范 | 关系 |
|---|---|
| `page-prd-template.md` 第 4 章 线框图 | 本规范输出的位置 |
| `lon-proto-builder` SKILL.md | 下游读取线框图 HTML 路径作布局权威，不做 DOM 复用 |
| `mobile-ia.md` | APP 页 Step 1.5 的上游：产出 LATCH 主维度 + 内容优先级，作为本文档差异化维度选型的输入 |
| `pm-skills/CLAUDE.md` HTML 线框图通用规范 | 跨技能引用入口，指向本文档 |
