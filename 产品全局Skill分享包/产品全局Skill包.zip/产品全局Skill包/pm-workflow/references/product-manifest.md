# 产品项目清单规范

产品工作流在项目根目录使用 `product-manifest.json` 保存跨阶段稳定事实。它是产品名称、正式版本和页面清单的唯一来源，不替代 Spec、PRD 或原型。

## 最小结构

```json
{
  "schemaVersion": "1.0",
  "product": {
    "name": "产品名称",
    "formalVersion": "1.0",
    "author": "作者",
    "status": "prototype-confirmed"
  },
  "workflow": {
    "currentStage": "prototype",
    "completedStages": ["discovery", "prd", "page-design"]
  },
  "pages": [
    {"id": "resource-overview", "order": 1, "name": "资源总览", "file": "prototypes/pages/01-资源总览.html", "status": "confirmed"}
  ],
  "terminology": {
    "preferred": {"旧名称": "新名称"},
    "forbidden": ["不得再次出现的旧名称"]
  },
  "decisions": [
    {"date": "2026-09-15", "topic": "版本", "decision": "首次研发交付保持 v1.0", "status": "confirmed"}
  ],
  "deliverables": {}
}
```

## 读写规则

- 文件存在时，所有下游 Skill 开始前先读取并复述与本阶段有关的字段。
- 产品名称、正式版本、作者和确认术语不得由下游文件反向覆盖。
- 用户确认新的跨页规则、改名、版本或范围后，在本阶段落盘时同步追加 `decisions`；同一主题以后写的新决策覆盖旧决策，旧项可保留用于追溯。
- 新增、删除或改名页面时同步维护 `pages`；顺序以 `order` 为准。
- `formalVersion` 不因原型迭代次数、线框版本或交付包内部构建次数自动升级。
- 文件缺失时不阻塞当前任务；在首次产生正式文件前，展示拟创建的关键字段并取得用户确认。

## 阶段状态建议

`idea`、`spec-approved`、`prd-approved`、`page-design`、`prototype`、`prototype-confirmed`、`dev-prd`、`delivery-ready`、`delivered`。

## 冲突处理

1. 用户当次明确指令。
2. `product-manifest.json` 中最新已确认决策。
3. 当前 HTML 原型的页面事实。
4. 当前阶段正式文档。
5. 历史文件和目录名。

发现冲突时，不静默选择：在输出中列出冲突和采用结果；版本冲突必须在交付前清零。
