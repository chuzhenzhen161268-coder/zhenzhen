#!/usr/bin/env python3
"""Audit cross-stage product artifacts for naming, versions, pages and links."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from urllib.parse import unquote


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def html_links(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    return [unquote(value.split("#", 1)[0]) for value in re.findall(r'href=["\']([^"\']+)', text)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--delivery", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = load_json(root / "product-manifest.json") or {}
    product = manifest.get("product", {})
    pages = manifest.get("pages", [])
    errors, warnings = [], []

    for page in pages:
        file_path = root / page.get("file", "")
        if not file_path.is_file():
            errors.append(f"页面文件不存在: {page.get('name')} -> {file_path}")

    forbidden = set(manifest.get("terminology", {}).get("forbidden", []))
    preferred = manifest.get("terminology", {}).get("preferred", {})
    files = []
    ignored_parts = {"assets", "vendor", ".git", "node_modules"}
    scan_roots = [root / "prototypes" / "pages", root / "prototypes" / "dev-prd"]
    if args.delivery:
        delivery_root = args.delivery.resolve()
        scan_roots.extend([delivery_root / "pages", delivery_root / "dev-prd", delivery_root / "文档"])
        if (delivery_root / "交付中心.html").is_file():
            files.append(delivery_root / "交付中心.html")
    for scan_root in scan_roots:
        if scan_root.exists():
            files.extend(
                path for path in scan_root.rglob("*")
                if path.suffix.lower() in {".md", ".html", ".json"}
                and ".bak." not in path.name
                and not ignored_parts.intersection(path.parts)
            )
    for path in files:
        text = path.read_text(encoding="utf-8", errors="replace")
        for term in forbidden:
            if term and term in text:
                errors.append(f"禁用术语仍存在: {term} -> {path}")
        for old, new in preferred.items():
            comparable = text.replace(new, "") if new else text
            if old and old in comparable:
                warnings.append(f"建议术语替换: {old} -> {new} ({path})")

    formal_version = str(product.get("formalVersion", "")).lstrip("v")
    if formal_version and args.delivery:
        delivery = args.delivery.resolve()
        version_files = [delivery / "交付中心.html"]
        version_files.extend((delivery / "dev-prd").glob("*-PRD-v*.md"))
        version_files.extend((delivery / "文档").glob("*-PRD-v*.html"))
        for path in version_files:
            if not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            head = "\n".join(text.splitlines()[:35])
            candidates = re.findall(r"\bv(\d+\.\d+(?:\.\d+)?)\b", path.name, re.I)
            candidates += re.findall(
                r"(?:正式版本|版本|version)[^\n]{0,20}?v(\d+\.\d+(?:\.\d+)?)",
                head,
                re.I,
            )
            for version in candidates:
                if version != formal_version:
                    errors.append(f"正式版本冲突: v{version} -> {path}")

    if args.delivery:
        center = args.delivery.resolve() / "交付中心.html"
        if not center.is_file():
            errors.append(f"缺少交付中心: {center}")
        else:
            for href in html_links(center):
                if not href or re.match(r"^(?:https?:|mailto:|javascript:)", href):
                    continue
                if not (center.parent / href).resolve().exists():
                    errors.append(f"交付中心失效链接: {href}")

    result = {
        "product": product.get("name"),
        "formalVersion": formal_version or None,
        "manifestPages": len(pages),
        "errors": sorted(set(errors)),
        "warnings": sorted(set(warnings)),
        "passed": not errors,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
